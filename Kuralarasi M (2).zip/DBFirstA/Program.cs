﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
namespace DBFirstA
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //using (var context= new EmployeeEntities())
            //{


            //    if (connection.State == ConnectionState.Closed)
            //        connection.Open();

            //    var emp = connection.Query<Employee>("select * from Employee").ToList();
            //    foreach (var i in emp)
            //    {
            //        Console.WriteLine($"{i.EmployeeName} -   {i.DepartmentId}");
            //    }
            //    //var empDetails = context.EmployeeDetails().ToList();
            //}
            using (var context = new EmployeeContext())
            {
                var empDetails = context.EmployeeDetails().ToList();

                foreach (var e in empDetails)
                {
                    Console.WriteLine($"{e.EmployeeName} - {e.DepartmentName} - {e.Salary}");
                }
            }
            Show();
        }
        static void Show()
        {
            using (var a = new EmployeeContext())
            {

                //var list = a.Employees.Include(i => i.Department).ToList();
                //foreach (var i in list)
                //{
                //    Console.WriteLine(i.EmployeeName + i.EmployeeId+i.Department.DepartmentName);
                //}
                var list1 = a.Employees.Include(s => s.Department).ToList();
                foreach (var i in list1)
                {
                    Console.WriteLine(i.EmployeeName + "  " + i.EmployeeId + "  " + i.Department.DepartmentName + "  " + i.Department.DepartmentId);
                }
            }
        }
        static void Insert()
        {

            Boolean isWantContinue = false;
            List<Employee> employees = new List<Employee>();
            while (!isWantContinue)
            {
                employees.Add(Add());

                Console.WriteLine("Do you want to Stop?(y/n)");
                string answer = Console.ReadLine();
                if (answer.ToLower() == "y")
                {
                    isWantContinue = true;
                }
            }
            using (var context = new EmployeeContext())
            {

                context.Employees.AddRange(employees);
                context.SaveChanges();
            }
            Console.WriteLine("Inserted Successfully");
            Console.WriteLine("Hellooo");

        }
        static Employee Add()
        {
            Console.Write("Enter your Name: ");
            string name = Console.ReadLine();
            Console.Write("Enter your Email: ");
            string Email = Console.ReadLine();
            Console.Write("Enter your PhoneNo: ");
            string Phone = Console.ReadLine();
            Console.Write("Enter your Date: ");
            String Date = Console.ReadLine();
            DateTime JDate = Convert.ToDateTime(Date);
            Console.Write("Enter your Salary: ");
            String sal = Console.ReadLine();
            int salary = int.TryParse(sal, out int m) ? m : 0;
            Console.Write("Enter your DeptId: ");
            String Id = Console.ReadLine();
            int DeptId = int.TryParse(Id, out int n) ? n : 0;
            Employee emp = new Employee
            {
                EmployeeName = name,
                Email = Email,
                Phone = Phone,
                HireDate = JDate,
                Salary = salary,
                DepartmentId = DeptId


            };
            return emp;

        }
    }
}

        
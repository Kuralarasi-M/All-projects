﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace SMS_CodeFirst
{
    public partial class Student
    {
        public int StudentId { get; set; }

        public string? Name { get; set; }

        public string? Email { get; set; }

        public string? Phone { get; set; }

        public DateOnly? DateOfBirth { get; set; }

        public int? DepartmentId { get; set; }

        public virtual Department? Department { get; set; }

     
    }
    public partial class Department
    {
        public int DepartmentId { get; set; }

        public string? DepartmentName { get; set; }

        public virtual ICollection<Student> Students { get; set; } = new List<Student>();
    }
    public partial class SmsContext : DbContext
    {
        public SmsContext()
        {
        }

        public SmsContext(DbContextOptions<SmsContext> options)
            : base(options)
        {
        }

      

        public virtual DbSet<Department> Departments { get; set; }

       

        public virtual DbSet<Student> Students { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var configBuilder = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

            var configSection = configBuilder.GetSection("ConnectionStrings");

            var connectionString = configSection["DefaultConnection"] ?? null;

            optionsBuilder.UseSqlServer(connectionString);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            using (var db = new SmsContext())
            {
                db.Students.Add(new Student
                {
                    Name = "Arasi",
                    Email = "arasi@gmail.com",
                    Phone = "9123456780",
                    DateOfBirth = new DateOnly(2001, 8, 21),
                    DepartmentId = 1
                });
                db.SaveChanges();
            }
            Console.WriteLine("Success");
        }
    }
}

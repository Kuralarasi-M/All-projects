﻿using Dapper;
using Microsoft.EntityFrameworkCore;
using TestPractice1.Models;

namespace TestPractice1
{
    class uspGetEmpMan
    {
        public int RecursionLevel { get; set; }
        public int BusinessEntityId { get; set; }
        public string FirstName {  get; set; }
        public string LastName { get; set; }
        public string OrganizationNode { get; set; }
        public string ManagerFirstName { get; set; }
        public string ManagerLastName { get; set; }

    }
    internal class Program
    {
        static void Main(string[] args)
        {
            using (var a = new AdventureWorks2019Context())
            {
                var list = a.Products.OrderBy(s => s.Name).Take(20).ToList();
                foreach (var i in list)
                {
                    Console.WriteLine(i.Name + " = "+i.ProductId);
                }
                string query = @"
       SELECT 
        Name,
        ProductId,
        ProductNumber,
        AVG(ListPrice) OVER (PARTITION BY ProductSubCategoryId) AS AvgPrice
    FROM Production.Product";
                var con = a.Database.GetDbConnection();
                con.Open();
                var list1 = con.Query(query).ToList();
                foreach (var i in list1)
                {
                    Console.WriteLine(i.ProductId + " - "+i.ProductNumber+" - "+i.AvgPrice);
                }
                // 11.Get the average list price of products in each subcategory.
                var avgQuery = a.Products.GroupBy(p => p.ProductSubcategoryId).Select(g => new{
                      ProductSubcategoryId = g.Key,
                      AvgPrice = g.Average(x => x.ListPrice)
                 });

                var list2 = from p in a.Products
                            join avg in avgQuery
                                on p.ProductSubcategoryId equals avg.ProductSubcategoryId
                            select new
                            {
                                p.ProductId,
                                p.Name,
                                p.ProductSubcategoryId,
                                avg.AvgPrice
                            };

                var result = list2.ToList();

                foreach (var i in result)
                {
                    Console.WriteLine("|{0,-20}|{1,-30}|{2,-30}",i.ProductId,i.Name,i.ProductSubcategoryId,i.AvgPrice);
                }
                //12.Find the best-selling product by total quantity sold.
                var Best = a.SalesOrderDetails.GroupBy(a => a.ProductId).Select(g => new
                {
                    ProductId = g.Key,
                TotalQty = g.Sum(x => x.OrderQty)

                }).OrderByDescending(p => p.TotalQty).FirstOrDefault();
                Console.WriteLine(Best.TotalQty + " = "+Best.ProductId);
                var connect= a.Database.GetDbConnection();
                int price= 1000;
                var productList = a.Products.FromSqlRaw($"select * from Production.Product where ListPrice>{price}");
                int Id = 3;
                foreach (var i in productList)
                {
                    Console.WriteLine(i.ProductId+ " - "+i.ListPrice+ " - "+i.Name);
                }
                var SpList = a.Database.SqlQueryRaw<uspGetEmpMan>($"Exec uspGetEmployeeManagers @BusinessEntityId={Id}").ToList();
                foreach (var item in SpList)
                {
                    Console.WriteLine($"{item.FirstName} {item.LastName} → Manager: {item.ManagerFirstName} {item.ManagerLastName}");
                }

            }
            Console.WriteLine("Hello, World!");
            
        }
    }
}

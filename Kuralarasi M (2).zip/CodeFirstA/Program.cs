﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data.Entity.Migrations.Model;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstA
{
    public class Employee
    {
        public int Id { get; set; }
        [Required]
        [MinLength(3)]
        public string Name { get; set; }
      
        public string Email { get; set; }
        
        public int DepartmentId { get; set; }
        [Column("Salary")]
        public int Salary { get; set; }
        public virtual Employee Department { get; set; }
    }
    public class Department
    {
        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; }
        public virtual ICollection<Employee> Employees { get; set; }
    }
    public class TableDBContext : DbContext{
       public  TableDBContext() : base("TableDBContext")
        {
           
        }
  
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments{ get; set; }


}
    internal class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Menu\n1 --- Add\n2 --- Update\n3 --- Delete\n4 --- Show\n Enter Your Option:");
            string str=Console.ReadLine();
            int option=Convert.ToInt32(str);
            switch (option)
            {
                case 1:
                    AddData();
                    break;
                case 2:
                    Update();
                    break;
                case 3:
                    Delete();
                    break;
                case 4:
                    Show();
                    break;
            }
        }
        static void AddData()
        {
            Console.WriteLine("Enter Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Email");
            string Email = Console.ReadLine();
            Console.WriteLine("Enter DeptID");
            string Id = Console.ReadLine();
            int DepartmentId = Convert.ToInt32(Id);
             Console.WriteLine("Enter Salary");
            string Sal = Console.ReadLine();
            int Salary = Convert.ToInt32(Sal);
            using (var a = new TableDBContext())
            {
                try
                {
                    var post = new Employee { Name = name, Email = Email, DepartmentId = DepartmentId, Salary = Salary };
                    a.Employees.Add(post);
                    a.SaveChanges();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
               
            }
            Show();
        }
        static void Update()
        {
            Console.Write("Enter Id : ");
            string str = Console.ReadLine();
            int Id = Convert.ToInt32(str);
            Console.Write("Enter Salary : ");
            string Sal = Console.ReadLine();
            int Salary = Convert.ToInt32(Sal);
            using (var a = new TableDBContext())
            {
                try
                {
                    var post = a.Employees.FirstOrDefault(s => s.Id == Id);
                    if (post != null)
                    {
                        post.Salary = Salary;
                        a.SaveChanges();
                    }
                    else
                    {
                        Console.WriteLine("Id not Exist");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                
            }
            Show();
        }
        static void Delete()
        {
            Console.Write("Enter Id");
            string str = Console.ReadLine();
            int Id = Convert.ToInt32(str);
            using (var a = new TableDBContext())
            {
                try
                {
                    var post = a.Employees.FirstOrDefault(p => p.Id == Id);
                    if (post != null)
                    {
                        a.Employees.Remove(post);
                        a.SaveChanges();
                    }
                    else
                    {
                        Console.WriteLine("Id not Exist");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
               
            }
            Show();
        }
        static void Show()
        {
            using (var a = new TableDBContext())
            {
                try
                {
                    var post = a.Employees.ToList();
                    foreach (var i in post)
                    {
                        Console.WriteLine($"ID : {i.Id} Name : {i.Name} Email : {i.Email} Salary : {i.Salary}  DepaertmentId : {i.DepartmentId}");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
               
            }
        }
    }
}

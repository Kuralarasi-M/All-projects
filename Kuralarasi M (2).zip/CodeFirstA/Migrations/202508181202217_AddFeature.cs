﻿namespace CodeFirstA.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddFeature : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.Employees", name: "DeptId", newName: "Salary");
            AlterColumn("dbo.Employees", "Name", c => c.String(nullable: false));
            AlterColumn("dbo.Employees", "Email", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Employees", "Email", c => c.String(nullable: false));
            AlterColumn("dbo.Employees", "Name", c => c.String());
            RenameColumn(table: "dbo.Employees", name: "Salary", newName: "DeptId");
        }
    }
}

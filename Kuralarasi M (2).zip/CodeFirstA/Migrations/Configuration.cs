﻿namespace CodeFirstA.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<CodeFirstA.TableDBContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(CodeFirstA.TableDBContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method
            //  to avoid creating duplicate seed data.
            if (!context.Departments.Any(d => d.DepartmentName == "IT"))
            {
                context.Departments.Add(new Department {DepartmentName = "IT" });
            }
            if (!context.Departments.Any(s => s.DepartmentName=="Finance"))
            {
                context.Departments.Add(new Department { DepartmentName = "Finance" });
            }
            if(!context.Departments.Any(s => s.DepartmentName == "Marketing"))
            {
                context.Departments.Add(new Department { DepartmentName = "Marketing" });
            }
            if (!context.Employees.Any(d => d.Name == "John"))
            {
                context.Employees.Add(new Employee { Name = "John", Email = "john@gmail.com", DepartmentId = 1 });
            }
        }
    }
}

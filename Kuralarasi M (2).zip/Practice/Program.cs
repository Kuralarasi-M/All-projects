﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Services;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
namespace Practice
{
    public class ShowDetail
    {
       
       public string EmployeeName { get;set; }
       public string Email { get; set; }
        public  string Phone { get; set; }
        public DateTime HireDate { get; set; }
        public int Salary { get; set; }
        public int DepartmentId { get; set; }

    }
    internal class Program
    {
        static  void Main(string[] args)
        {
            Console.WriteLine("Menu\n1 --- Add\n2 --- Update\n3 --- Delete\n4 --- Show\nEnter your Option");
            string str = Console.ReadLine();
            int option = Convert.ToInt32(str);
            switch (option)
            {
                case 1:
                    AddData();
                    break;
                case 2:
                    UpdateData();
                    break;
                case 3:
                    DeleteData();
                    break;
                case 4:
                    ShowData();
                    break;


            }

            //using (var a = new EmployeeDBContext())
            //{
            //    var list = a.EmployeeDetails().ToList();
            //    foreach (var i in list)
            //    {
            //        Console.WriteLine(i.EmployeeName + " - " + i.DepartmentName);
            //    }
            //}
            
        }
        static  void ShowData()
        {
            using(var con=new EmployeeDBContext())
            {
                var connection=con.Database.Connection;
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                // Get the data from Table
                //var (sal ,Id)= (45000,6);
                //var list = (await connection.QueryAsync<Employee>("select * from Employee where Salary>@sal and EmployeeId<@Id", new {sal,Id})).ToList();
                //foreach (var i in list)
                //{
                //   Console.WriteLine(i.EmployeeName + " " + i.EmployeeId+" "+i.Salary);
                //}
                //var tables = connection.QueryMultiple("select * from Employee;select * from Department");
                //var emp=tables.Read<Employee>().ToList();
                //var dep = tables.Read<Department>().ToList();
                //foreach (var i in emp)
                //{
                //    Console.WriteLine(i.EmployeeName +"  -  "+i.DepartmentId);
                //}
                //foreach (var j in dep)
                //{
                //    Console.WriteLine(j.DepartmentName + "  -  " + j.DepartmentId);
                //}
                string query = "select e.EmployeeId,e.EmployeeName,e.Salary,d.DepartmentId,d.DepartmentName from Employee e inner join Department d on e.DepartmentId=d.DepartmentId ";
                var Details = connection.Query<Employee, Department, Employee>(query, (emp, dept) =>
                {
                    emp.Department = dept;return emp;
                },
                splitOn: "DepartmentId").ToList();
                foreach (var i in Details)
                {
                    Console.WriteLine(i.EmployeeName + "-" + i.EmployeeId + "-" + i.Salary+" - "+i.Department.DepartmentName);
                }
            }
        }
        public static void TvpAddData()
        {
            var table = new DataTable();
            table.Columns.Add("EmployeeName", typeof(string));
            table.Columns.Add("Email", typeof(string));
            table.Columns.Add("Phone", typeof(string));
            table.Columns.Add("HireDate", typeof(DateTime));
            table.Columns.Add("Salary", typeof(decimal));
            table.Columns.Add("DepartmentId", typeof(int));
            
            // Add multiple rows
            table.Rows.Add("Kural", "kural123@gmail.com","333333",DateTime.Parse("2025-09-09"),39000, 1);
            table.Rows.Add("Arasi", "arasi@gmail.com", "333333", DateTime.Parse( "2025-09-09"), 39000, 2);
            var parameters = new DynamicParameters();
            parameters.Add("@InsertedData", table.AsTableValuedParameter("EmpTable"));
            // Pass as parameter
           
            var connection = new EmployeeDBContext();
            var constr = connection.Database.Connection;
            constr.Execute("InsertData", parameters, commandType: CommandType.StoredProcedure);
       
        }
        public static void AddData()
        {
            try
            {
                Boolean isContinue= false;
                List<ShowDetail> empList=new List<ShowDetail>();
                while (!isContinue)
                {
                    Console.WriteLine("Enter your Name");
                    String Name = Console.ReadLine();
                    Console.WriteLine("Enter your Email");
                    String Email = Console.ReadLine();
                    Console.WriteLine("Enter your PhoneNo");
                    string Phone = Console.ReadLine();
                    Console.WriteLine("Enter your joiningDate");
                    String d = Console.ReadLine();
                    DateTime date = DateTime.TryParse(d, out DateTime m) ? m : DateTime.Today;

                    Console.WriteLine("Enter your Salary");
                    string str = Console.ReadLine();
                    int Sal = Convert.ToInt32(str);
                    Console.WriteLine("Enter your DeptId");
                    string str1 = Console.ReadLine();

                    int DeptId = Convert.ToInt32(str1);
                    var Emp = new ShowDetail
                    {

                        EmployeeName = Name,
                        Email = Email,
                        Phone=Phone,
                        HireDate=date,
                        Salary=Sal,
                        DepartmentId=DeptId

                    };
                    empList.Add(Emp);
                    Console.WriteLine("Do you want to Continue?(y/n)");
                    string s= Console.ReadLine().ToLower();
                    if (s != "y")
                    {
                        isContinue= true;
                    }
                }
                // insert the data into Table

                using (var connection = new EmployeeDBContext())
                {
                    var Constr = connection.Database.Connection;
                   
                    string query = "Insert into Employee(EmployeeName, Email, Phone, HireDate, Salary, DepartmentId) values(@EmployeeName,@Email,@Phone,@HireDate,@Salary,@DepartmentId);";
                    
                    int row = Constr.Execute(query,empList);
                    

                    if (row > 0)
                    {
                        Console.WriteLine($"{row}UserId, Added Successfully");
                    }

                }

            }
            catch(Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }

        }
        static void DeleteData()
        {
            try
            {
                var connection = new EmployeeDBContext();
                var Constr = connection.Database.Connection;
                Console.WriteLine("Enter the Id");
                string str = Console.ReadLine();
                int Id = Convert.ToInt32(str);
                string query = "Delete employee where EmployeeId=@Id";
                int affectedRow=Constr.Execute(query, new { Id });
                if (affectedRow > 0)
                {
                    Console.WriteLine($"{affectedRow} deleted Successfully");
                }
                else
                {
                    Console.WriteLine("UserId not Exist!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static async Task UpdateData()
        {
            var connection=new EmployeeDBContext();
            var constr=connection.Database.Connection;
            Console.WriteLine("Enter the Id");
            string str = Console.ReadLine();
            int Id = Convert.ToInt32(str);
            Console.WriteLine("Enter your DeptId");
            string str1 = Console.ReadLine();
            int deptId = Convert.ToInt32(str1);
            string Query = "Update employee set DepartmentId=@deptId where EmployeeId=@Id";
            int row = await (constr.ExecuteAsync(Query, new { Id, deptId }));
            if(row > 0) {
                Console.WriteLine($"{row} row Updated Successfully");
            }
            else
            {
                Console.WriteLine("UserId not Exist!");
            }
        }
    }
}

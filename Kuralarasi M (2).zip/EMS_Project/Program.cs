﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_Project
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using(var a=new EmployeeEntities())
            {
                //a.Employees.Add(new Employee
                //{
                //    EmployeeName = "kural",
                //    Email = "kural@gmail.com",
                //    Phone = "9087654321",
                //    HireDate = DateTime.Parse("2025-04-21"),
                //    Salary = 45000,
                //    DepartmentId = 1
                //});
                //a.SaveChanges();
                var list = a.Employees.Include(i => i.Department).ToList();
                foreach (var i in list)
                {
                    Console.WriteLine(i.EmployeeName + i.EmployeeId+i.Department.DepartmentName);
                }
            }
            Console.WriteLine("Inserted Successfully");
        }
    }
}

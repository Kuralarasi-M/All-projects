﻿using Dapper;
using EFCore_Assessment_1.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace EFCore_Assessment_1
{
    class History
    {
        public string ProductName {  get; set; }
        public int Total {  get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            var context = new NorthwndContext();
           
            Boolean isContinue = true;
            while (isContinue)
            {
                Console.Write("Enter your Option : ");
                string str = Console.ReadLine();
                int option = int.TryParse(str, out int value) ? value : 0;
               
                switch (option)
                {
                    case 1:
                        Add(context);
                        break;
                    case 2:
                        DisplayCustOrder(context);
                        break;
                    case 3:
                        Expensive(context);
                        break;
                    case 4:
                        NoOrderedCus(context);
                        break;
                    case 5:
                        EmpOrder(context);
                        break;
                    case 6:
                        CustOrderHist(context);
                        break;
                    case 7:
                        DisplayAllPro(context);
                        break;
                    case 8:
                        Update(context);
                        break;
                    default:
                        break;
                }
                Console.WriteLine("Do you Want Continue?(y/n)");
                string s=Console.ReadLine();
                if (s.ToLower() != "y")
                {
                    isContinue = false;
                }
            
            }

        }
        static void Add(NorthwndContext context)
        {
            Console.Write("Enter your CustomerId : ");
            Boolean isRight = false;
            string Id = null;
            while (!isRight)
            {
                Id= Console.ReadLine();
                if (Id.Length==5)
                {
                    isRight = true;
                }
                else
                {
                    Console.Write("Enter your CustomerId : ");
                }
                
            }
            Console.Write("Enter your CompanyName : ");
            string CompanyName = Console.ReadLine();
            Console.Write("Enter your ContactName : ");
            string ContactName= Console.ReadLine();
            Console.Write("Enter your ContactTitle : ");
            string ContactTitle=Console.ReadLine();
            Console.Write("Enter your Addresss : ");
            string Address= Console.ReadLine();
            Console.Write("Enter your City: ");
            string City= Console.ReadLine();
            Console.Write("Enter your Regoin : ");
            string Region= Console.ReadLine();
            Console.Write("Enter your PostalCode : ");
            string PostalCode = Console.ReadLine();
            Console.Write("Enter your Country : ");
            string Country= Console.ReadLine();
            Console.Write("Enter your Phone : ");
            string Phone= Console.ReadLine();
            Console.Write("Enter your Fax : ");
            string Fax= Console.ReadLine();
            var object1 = new
            {
                
                CompanyName=CompanyName,
                ContactName=ContactName,
                ContactTitle=ContactTitle,
                Address=Address,
                City=City,
                Region=Region,
                PostalCode=PostalCode,
                Country=Country,
                Phone=Phone,
                Fax=Fax,
            };
            List<object> list = new List<object>(); 
            list.Add(object1);
            string query = "insert into dbo.Employees values(@CompanyName,@ContactName,@ContactTitle,@Address,@City,@Region,@PostalCode,@Country,@Phone,@Fax)";
            var connection = context.Database.GetDbConnection();
            connection.Execute(query, list);


            context.SaveChanges();
            
        }
        static void DisplayCustOrder(NorthwndContext context)
        {
           
            string query = "select CustomerID,Count(OrderId) over(partition by CustomerID ) as CustomerCount from Dbo.Orders";
            var connection = context.Database.GetDbConnection();

            var list = context.Orders.GroupBy(a => a.CustomerId).Select(g => new
            {
                CustomerId = g.Key,
                TotalOrder = g.Count(),
               
            }).ToList();
            var list2 = from p in list
                        join c in context.Customers
                            on p.CustomerId equals c.CustomerId
                        select new
                        {
                            c.CustomerId,
                            c.CompanyName,
                            p.TotalOrder
                        };

            var result = list2.ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}|", "CustomerID", "CompanyName", "TotalOrder");
            foreach (var i in result)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}|",i.CustomerId,i.CompanyName, i.TotalOrder);
            }
           

        }
        static void Expensive(NorthwndContext context)
        {
            
            var list = context.Products.OrderByDescending(s => s.UnitPrice).Take(5).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}|","ProductId","ProductName","Price");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}|",i.ProductId,i.ProductName,i.UnitPrice);
            }
        }
        static void  NoOrderedCus(NorthwndContext context)
        {
            string query = "select CustomerID from dbo.Customers where not Exists (select CustomerId from dbo.Orders)";
            var connection = context.Database.GetDbConnection();
            var list = connection.Query<Customer>(query).ToList();
            
            foreach (var i in list)
            {
                Console.WriteLine(i.CustomerId+i.CompanyName);
            }


        }
        static void CustOrderHist(NorthwndContext context)
        {
            Console.WriteLine("Enter CustomerId");
            String Id=Console.ReadLine();
            Console.WriteLine("|{0,-50}|{1,-40}|","ProductName","Total");
            var SpList = context.Database.SqlQueryRaw<History>($"Exec CustOrderHist @CustomerId={Id}").ToList();
            foreach (var item in SpList)
            {
                Console.WriteLine("|{0,-50}|{1,-40}|",item.ProductName,item.Total);
            }
        }
        static void DisplayAllPro(NorthwndContext context)
        {
            Console.WriteLine("Enter Product Name");
            string ProductStr=Console.ReadLine().ToLower();
            string query = "select ProductName from dbo.Products where ProductName like '%ProductStr%'";
            var connection = context.Database.GetDbConnection();
            var list = connection.Query<Product>(query).ToList();
            foreach (var i in list)
            {
                Console.WriteLine(i.ProductId + " - "+i.ProductName);
            }
        }
        static void EmpOrder(NorthwndContext context)
        {
            //string query = "select EmployeeIdID,Count(OrderID) over(partition by EmployeeID ) as EmpCount from Dbo.Orders";
            //var connection = context.Database.GetDbConnection();

            var list = context.Orders.GroupBy(a => a.EmployeeId).Select(g => new
            {
               EmployeeId = g.Key,
                TotalOrder = g.Count(),

            }).ToList();
            var list2 = from p in list
                        join c in context.Employees
                            on p.EmployeeId equals c.EmployeeId
                        select new
                        {
                            c.EmployeeId,
                            c.FirstName,
                            c.LastName,
                            p.TotalOrder
                        };

            var result = list2.ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}||{3,-20}|", "EmployeeIdID", "FirstName","LastName", "TotalOrder");
            foreach (var i in result)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}||{3,-20}|",i.EmployeeId,i.FirstName,i.LastName,i.TotalOrder);
            }
        }
        static void Update(NorthwndContext context)
        {
            Console.WriteLine("Enter CustomerId");
            string IdStr = Console.ReadLine();
            int Id =int.TryParse(IdStr, out var id) ? id : 0;
            var list = context.Employees.FirstOrDefault(s => s.EmployeeId == Id);
            if(list == null)
            {
                Console.WriteLine("Employee Not Exist");
            }
            else
            {
                Console.WriteLine("Enter Address");
                string Str = Console.ReadLine();
                list.Address = Str;
                context.SaveChanges();
            }

               
        }
        
    }
}

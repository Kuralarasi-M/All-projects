﻿using Dapper;
using Microsoft.EntityFrameworkCore;
using Northwind_Exercise.Models;
using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Northwind_Exercise
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var context = new NorthwndContext();
           
            Console.Write("Enter your Option: ");
            Console.WriteLine("Menu : \n1 --- Place new order\n2 --- Create new category with multiple productslyee to new manager \n3 --- Find customers who placed orders in 1997 but not in 1998." +
                "\n4 --- List customers and their most recent order date.\n5 --- Show all customers whose total order value exceeds 50000.\n6 --- List each category with the average unit price of products.\n7 --- Show products that have never been ordered.\n8 --- Find the top 3 most ordered products (by total quantity sold). \n9 --- List products along with their supplier name and category name. " +
                "\n10 --- Display all products where UnitPrice > Category Average Price.\n11 --- List employees with the total sales amount they handled.\n12 --- show the employee who handled the most orders in 1997.\n13 --- Find employees who share the same territory.\n14 --- Display each employee with the number of distinct customers they served.\n15 --- List employees along with the first order they ever handled.\n16  --- For each shipper, calculate the average delivery time (ShippedDate – OrderDate).\n17 --- List orders that took more than 30 days to deliver.\n18 --- Find the top shipper based on the number of orders shipped.\n19 --- Show the top employee per year based on total sales. " +
                "\n20 --- Find all products that were ordered by every customer.\n21 --- Find suppliers who supply more than 5 products.\n22 --- List the customer(s) with the single highest order value.\n23 --- List customers who have ordered all products in a given category (e.g., Beverages).\n24 --- Show the most profitable product (highest total sales revenue).");
            string str=Console.ReadLine();
            int option=int.TryParse(str, out int val)?val:0;
            
                switch (option)
            {
                case 1:
                    PlaceOrder(context);
                    break;
                case 2:
                    CategoryMulProd(context);
                    break;
                case 3:
                    Customer(context);
                    break;
                case 4:
                    CustomerOrder(context);
                    break;
                case 5:
                    MaxOrder(context);
                    break;
                case 6:
                    ProductAvgPrice(context);
                    break;
                case 7:
                    NotOrderProduct(context);
                    break;
                case 8:
                    MostSoldProduct(context);
                    break;
                case 9:
                    ProductDetails(context);
                    break;
                case 10:
                    AboveAvg(context);
                    break;
                case 11:
                    EmployeeOrder(context);
                    break;
                case 12:
                    EmpOrder(context);
                    break;
                case 13:
                    SameTerritory(context);
                    break;
                case 14:
                    EmpCus(context);
                    break;
                case 15:
                    FirstOrder(context);
                    break;
                case 16:
                    AvgDays(context);
                    break;
                case 17:
                    TotalSeAmt(context);
                    break;
                case 18:
                    TopShipper(context);
                    break;
                 case 19:
                    TopSaleEmp(context);  
                    break;
                 case 20:
                    break;
                 case 21:
                    MostBuyProduct(context);
                    break;
                case 22:
                    HighestOrder(context);
                    break;
                case 23:
                    break;
                case 24:
                    MostProfitPro(context);
                    break;
                default:
                    Console.WriteLine("Invalid Option!.");
                    break;
            }
        }
        static void SameTerritory(NorthwndContext context)
        {
            var result =( from t in context.Territories
                   from e1 in t.Employees
                   from e2 in t.Employees
                   where e1.EmployeeId < e2.EmployeeId   
                   select new
                    {
                        Employee1 = e1.FirstName + " " + e1.LastName,
                        Employee2 = e2.FirstName + " " + e2.LastName,
                        TerritoryName = t.TerritoryDescription
                    });
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|", "Employee1", "Employee1", "TerritoryName");
            foreach (var row in result)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|",row.Employee1,row.Employee2,row.TerritoryName);
            }





        }
        static void CategoryMulProd(NorthwndContext context)
        {
            try
            {
                Console.Write("Enter the CategoryName: ");
                string CategoryName = Console.ReadLine();
                Console.Write("Enter the Description : ");
                string Description = Console.ReadLine();
                bool wantContinue = true;
                List<Product> products = new List<Product>();
                while (wantContinue)
                {

                    string ProName = Console.ReadLine();
                    string Price = Console.ReadLine();

                    decimal? UnitPrice = decimal.TryParse(Price, out var d) ? d : null;
                    Console.Write("Enter the Quantity: ");


                    Console.Write("Do you want to Continue?(y/n)");
                    string str = Console.ReadLine().ToLower();
                    var object1 = new Product
                    {

                        ProductName = ProName,
                        UnitPrice = UnitPrice ?? 0,


                    };

                    products.Add(object1);
                    if (str != "y")
                    {
                        wantContinue = false;
                    }

                }
                var category = new Category
                {
                    CategoryName = CategoryName,
                    Description = Description,
                    Products = products
                };

                foreach (var p in products)
                {
                    p.Category = category;
                }

                using (context)
                {
                    context.Categories.Add(category);
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void MostProfitPro(NorthwndContext context)
        {
            //27.Show the most profitable product(highest total sales revenue). Output: ProductID | ProductName | TotalRevenue
            var list = context.OrderDetails.GroupBy(s => s.ProductId).Select(s => new
            {
                ProductId = s.Key,
                Total = s.Sum(t => t.Quantity * t.UnitPrice*(decimal)(1-t.Discount))
            }).Join(context.Products, s => s.ProductId, t => t.ProductId, (s, t) => new
            {
                s.ProductId,
                t.ProductName,
                s.Total
            }).OrderByDescending(s => s.Total).Take(3);
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}", i.ProductId, i.ProductName, i.Total);
            }
        }
        static void HighestOrder(NorthwndContext context)
        {
            //25.List the customer(s) with the single highest order value. Output: CustomerName | OrderID | OrderValue
            var list = context.Orders.Select(o => new{
                   o.OrderId,
                   o.Customer.ContactName,
                    OrderValue = o.OrderDetails
                   .Sum(od => od.UnitPrice * od.Quantity * (1 - (decimal)od.Discount))
            })
           .Where(x => x.OrderValue == context.Orders
           .Select(o => o.OrderDetails.Sum(od => od.UnitPrice * od.Quantity * (1 - (decimal)od.Discount)))
            .Max())
           .Select(x => new
            {
                CustomerName = x.ContactName,
                x.OrderId,
                 x.OrderValue
            }).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|", "OrderId", "CustomerName", "OrderValue");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|", i.OrderId, i.CustomerName, i.OrderValue);
            }
        }
        static void MostBuyProduct(NorthwndContext context)
        {
            // 24.	Find suppliers who supply more than 5 products. Output: SupplierID | SupplierName | ProductCount
            var list = context.Products.GroupBy(s => s.SupplierId).Select(s => new
            {
                SupplierId = s.Key,
                ProductCount = s.Count()
            }).Where(s => s.ProductCount>4).OrderByDescending(s => s.SupplierId).Join(context.Suppliers,s=> s.SupplierId,t=> t.SupplierId,
            (s, t) => new{
                s.SupplierId,
                t.CompanyName,
                s.ProductCount
                
            });
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}", "SupplierId", "CompanyName", "ProductCount");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}", i.SupplierId,i.CompanyName, i.ProductCount);
            }
        }
        static void TopShipper(NorthwndContext context)
        {
            // 21.Find the top shipper based on the number of orders shipped. Output: ShipperName | OrdersShipped
            var list = context.Orders.GroupBy(s => s.ShipVia).Select(s => new
            {
                ShipVia = s.Key,
                TotOrder = s.Count()
            }).Join(context.Shippers,s=> s.ShipVia ,t => t.ShipperId ,(s,t)=> new
            {
                s.ShipVia,
                t.CompanyName,
                s.TotOrder
            }).OrderByDescending(s=> s.TotOrder).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}", "ShipVia", "CompanyName", "TotOrder");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|",i.ShipVia,i.CompanyName,i.TotOrder );
            }

        }
        static void TopSaleEmp(NorthwndContext context)
        {
            //22.Show the top employee per year based on total sales.Output: Year | EmployeeName | TotalSales
            var list = context.Orders.GroupBy(s => s.OrderDate.Value.Year).Select(s => new
            {
                OrderYear = s.Key,
                TopEmp = s.GroupBy(t => t.EmployeeId).Select(t => new
                {
                    EmployeeId = t.Key,
                    TotalSales = t.Count()
                }).OrderByDescending(e => e.TotalSales)
            .Take(1).Join(context.Employees, a => a.EmployeeId, b => b.EmployeeId, (a, b) => new
            {

                a.EmployeeId,
                b.FirstName,
                b.LastName,
                a.TotalSales
            })
             .FirstOrDefault()
            }).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|{4,-30}|", "Year", "EmployeeId", "FirstName", "LastName", "TotalSales");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|{4,-30}|", i.OrderYear,i.TopEmp.EmployeeId,i.TopEmp.FirstName,i.TopEmp.LastName,i.TopEmp.TotalSales );
            }


        }
        static void FirstOrder(NorthwndContext context)
        {
            // 18.List employees along with the first order they ever handled.Output: EmployeeID | EmployeeName | FirstOrderDate
            var list = context.Orders.GroupBy(s => s.EmployeeId).Select(s => new
            {
                EmployeeId = s.Key,
                FDate = s.Min(s => s.OrderDate)
            }).Join(context.Employees, e => e.EmployeeId, em => em.EmployeeId, (e, em) => new
            {
                e.EmployeeId,
                em.FirstName,
                em.LastName,
                e.FDate

            }).OrderBy(s => s.EmployeeId).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|", "EmployeeId", "FirstName", "LastName", "FirstOrderDate");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|", i.EmployeeId, i.FirstName, i.LastName, i.FDate);
            }
        }
        static void EmpCus(NorthwndContext context)
        {
            // 17.Display each employee with the number of distinct customers they served. Output: EmployeeID | EmployeeName | DistinctCustomers
            var list = context.Orders.GroupBy(s => s.EmployeeId).Select(s => new
            {
                EmployeeId = s.Key,
                TotalCus = s.Select(x => x.CustomerId).Distinct().Count()
            }).Join(context.Employees,e => e.EmployeeId,em => em.EmployeeId,(e,em)=> new
            {
                e.EmployeeId,
                em.FirstName,
                em.LastName,
                e.TotalCus
            }).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|", "EmployeeId", "FirstName", "LastName", "TotCustHandled");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|", i.EmployeeId, i.FirstName, i.LastName, i.TotalCus);
            }

        }
        static void TotalSeAmt(NorthwndContext context)
        {
            //20.List orders that took more than 30 days to deliver.Output: OrderID | CustomerName | DaysTaken
            var list = context.Orders.Where(o => o.OrderDate.HasValue && o.ShippedDate.HasValue)
                .Where(o => EF.Functions.DateDiffDay(o.OrderDate.Value, o.ShippedDate.Value) > 30)
                .Join(context.Customers,s=> s.CustomerId,t => t.CustomerId,(s,t)=> new
                {
                    s.OrderId,
                    t.CustomerId,
                    t.CompanyName,
                    TotDays = EF.Functions.DateDiffDay(s.OrderDate.Value, s.ShippedDate.Value)
                }).ToList();

            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|", "OrderId", "CustomerId", "CompanyName", "TotDays");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|", i.OrderId, i.CustomerId, i.CompanyName, i.TotDays);
            }



        }
       
        static void AvgDays(NorthwndContext context)
        {
            //19.For each shipper, calculate the average delivery time(ShippedDate – OrderDate). Output: ShipperName | AvgDeliveryDays
            var list = context.Orders.Where(o => o.ShippedDate.HasValue && o.OrderDate.HasValue)
                .GroupBy(s => s.ShipVia).Select(s => new
                {
                    ShipVia = s.Key,
                    Avg = s.Average(x => EF.Functions.DateDiffDay(x.OrderDate.Value, x.ShippedDate.Value))
                }).Join(context.Shippers, s => s.ShipVia, t => t.ShipperId, (s, t) => new
                {
                    s.ShipVia,
                    t.CompanyName,
                    s.Avg
                }).OrderBy(s => s.ShipVia).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|", "ShippingId", "ShipperName", "AvgDeliveryDays");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|", i.ShipVia, i.CompanyName, i.Avg);

            }
        }
            static void PlaceOrder(NorthwndContext context)
        {
            // 1.Place new order - Input from Console CustomerID, EmployeeID, Multiple products(ProductID and Quantity for each)
            Console.Write("Enter the CustomerId : ");
            string CusId=Console.ReadLine();
            Console.Write("Enter the CusEmployeeId : ");
            string Id = Console.ReadLine();
            int EmpId=int.TryParse(Id, out int m)? m :0;
            
            List<OrderDetail> OrderProducts = new List<OrderDetail>();
            bool Insert=false;
            while (!Insert)
            {
                Console.Write("Enter the ProductId : ");
                string ProId = Console.ReadLine();
                int PId = int.TryParse(ProId, out int n) ? n : 0;
                var Prod = context.Products.FirstOrDefault(s => s.ProductId == PId);
                if(Prod == null)
                {
                    Console.WriteLine("The ProductId is Not Exist!.");
                    continue;
                }
                decimal ? UnitPrice = Prod?.UnitPrice;
                Console.Write("Enter the Quantity: ");
                string Product = Console.ReadLine();
                short Quantity= short.TryParse(Product, out short q) ? q : (short)0;
                
                Console.Write("Do you want to Continue?(y/n)");
                string str = Console.ReadLine().ToLower();
                var object1 = new OrderDetail
                {
                    ProductId=PId,
                    UnitPrice=UnitPrice??0,
                    Quantity=Quantity,
                    Discount = 0,
                    Product = Prod
                };
                
                OrderProducts.Add(object1); 
                if(str!="y")
                {
                    Insert=true;
                }

            }

            var order = new Order
            {
                CustomerId = CusId,
                EmployeeId = EmpId,
                OrderDate = DateTime.Today,
                ShippedDate = DateTime.Today.AddDays(15),
                OrderDetails = OrderProducts
            };

         
            foreach (var detail in OrderProducts)
            {
                detail.Order = order;
            }

            context.Orders.Add(order);
            context.SaveChanges();

         



        }
        static void EmpOrder(NorthwndContext context)
        {
            //15.Show the employee who handled the most orders in 1997.Output: EmployeeID | EmployeeName | OrdersHandled
            var list = context.Orders.Where(s => s.OrderDate.HasValue && s.OrderDate.Value.Year == 1997)
                   .GroupBy(s => s.EmployeeId)
                       .Select(n => new
                       {
                           EmployeeId = n.Key,
                           TotOrder = n.Count()
                       }).OrderByDescending(s => s.TotOrder).Take(1).ToList();
            var ansList = (from l in list join e in context.Employees on l.EmployeeId equals e.EmployeeId
                        select new
                        {
                              l.EmployeeId,
                              e.FirstName,
                              e.LastName,
                              l.TotOrder
                        });
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|", "EmployeeId", "FirstName", "LastName", "OrderHandled");
            foreach (var i in ansList)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|", i.EmployeeId, i.FirstName, i.LastName, i.TotOrder);
            }

        }
       
        static void AboveAvg(NorthwndContext context)
        {
            //13.Display all products where UnitPrice > Category Average Price. Output: ProductID | ProductName | UnitPrice | CategoryAverage
            var list = context.Products.GroupBy(g => g.CategoryId)
                     .Select(n => new
                     {
                         CategoryId = n.Key,
                         Avg = n.Average(n => n.UnitPrice)
                     }).ToList();
            var aboveList= (from c in list join p in context.Products on c.CategoryId equals p.CategoryId
                            select new
                            {
                                p.ProductId,
                                p.ProductName,
                                p.CategoryId,
                                p.UnitPrice,
                                c.Avg
                            }).Where(m => m.UnitPrice > m.Avg).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|{4,-30}|", "ProductId", "ProductName", "CategoryId","UnitPrice", "CategoryAvg");
            foreach (var i in aboveList)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|{4,-30}|", i.ProductId, i.ProductName,i.CategoryId, i.UnitPrice, i.Avg);
            }
        }
        static void ProductDetails(NorthwndContext context)
        {
           
            var list = (from p in context.Products join s in context.Suppliers on p.SupplierId equals s.SupplierId
                        join c in context.Categories on p.CategoryId equals c.CategoryId
                        select new
                        {
                            p.ProductId,
                            p.ProductName,

                            c.CategoryName,
                            s.CompanyName
                        }).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|", "ProductId", "ProductName", "CategoryName","SupplierName");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|", i.ProductId, i.ProductName, i.CategoryName,i.CompanyName);
            }

        }
        static void Customer(NorthwndContext context)
        {

            var list = context.Customers.Where(c => context.Orders .Any(o => o.CustomerId == c.CustomerId
                && o.OrderDate.HasValue
                && o.OrderDate.Value.Year == 1997))
               .Where(c => !context.Orders
                        .Any(o => o.CustomerId == c.CustomerId
                && o.OrderDate.HasValue
                && o.OrderDate.Value.Year == 1998)).Select(c => new
                {
                    c.CustomerId,
                    c.CompanyName
                }) .ToList();



            Console.WriteLine("|{0,-20}|{1,-40}|", "CustomerId", "CompanyName");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|", i.CustomerId, i.CompanyName);
            }

        }
        static void Place(NorthwndContext context)
        {

        }
        static void EmployeeOrder(NorthwndContext context)
        {
            // 14.List employees with the total sales amount they handled. Output: EmployeeID | EmployeeName | TotalSales
            var list = context.Orders.Join(context.OrderDetails,
                o => o.OrderId,
                od => od.OrderId,
                (o, od) => new
                {
                    o.EmployeeId,
                    o.OrderId,
                    od.UnitPrice,
                    od.Quantity,
                }).GroupBy(s => s.EmployeeId).Select(s => new
                {
                    EmployeeId = s.Key,
                    Total = s.Sum(m => m.UnitPrice * m.Quantity)
                }).Join(context.Employees,
                a => a.EmployeeId, e => e.EmployeeId,
                (a, e) => new
                {
                    e.EmployeeId,
                    e.FirstName,
                    e.LastName,
                    a.Total
                }).OrderBy(n => n.EmployeeId);
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|", "EmployeeId", "FirstName", "LastName", "Total");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|{3,-30}|", i.EmployeeId, i.FirstName, i.LastName, i.Total);
            }



        }
        static void NotOrderProduct(NorthwndContext context)
        {
            var query ="select ProductId,ProductName from [Products] as p where not exists (select productId from [Order Details] as od where od.ProductId=p.ProductId)";

            var con = context.Database.GetDbConnection();
            var list = con.Query<Product>(query).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|", "ProductId", "ProductName", "UnitPrice");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|",i.ProductId,i.ProductName,i.UnitPrice);
            }
        }
        static void MostSoldProduct(NorthwndContext context)
        {
            var proList = context.OrderDetails.GroupBy(p => p.ProductId)
                .Select(m => new
                {
                    ProductId = m.Key,
                    QtnTot = m.Sum(n => n.Quantity)
                }).OrderByDescending(s => s.QtnTot).Take(3).ToList();
            var list = from p in proList
                       join l in context.Products on p.ProductId equals l.ProductId
                       select new
                       {
                           p.ProductId,
                           p.QtnTot,
                           l.ProductName
                       };
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|", "ProductId", "ProductName", "TotalSold");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|", i.ProductId, i.ProductName, i.QtnTot);
            }

        }
        static void ProductAvgPrice(NorthwndContext context)
        {
            var proList = context.Products.GroupBy(p => p.CategoryId)
                          .Select(g => new{
                               CategoryId = g.Key,
                               Avg = g.Average(m => m.UnitPrice)
                           }).ToList();
            var list = (from p in proList
                       join ap in context.Categories
                     on p.CategoryId equals ap.CategoryId
                       select new
                       {
                           ap.CategoryId,
                           ap.CategoryName,
                           p.Avg
                       }).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|", "CategoryId", "CategoryName", "AveragePrice");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|",i.CategoryId,i.CategoryName,i.Avg);
            }
        }
        static void MaxOrder(NorthwndContext context)
        {
            var query = @"select o.CustomerId, Sum(UnitPrice*Quantity) as Total
              from [Order Details] as od
              inner join Orders as o on (o.OrderID=od.OrderID)
              group by o.CustomerID
              having Sum(UnitPrice*Quantity) > 50000";

            var con = context.Database.GetDbConnection();
            
            var list = con.Query(query).ToList();
            var list2 = from co in list
                        join c in context.Customers
                            on co.CustomerId equals c.CustomerId
                        select new
                        {
                            co.CustomerId,
                            c.CompanyName,
                            co.Total
                        };

            var result = list2.ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|","CustomerId","CompanyName","Total");
            foreach (var i in list2)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|",i.CustomerId,i.CompanyName,i.Total);
            }

        }
        static void CustomerOrder(NorthwndContext context)
        {
            var query =from c in context.Customers
                     join o in context.Orders
                     on c.CustomerId equals o.CustomerId into orderGroup
                     from og in orderGroup.DefaultIfEmpty()  
                     select new
                     {
                           c.CustomerId,
                          c.ContactName,
                          OrderDate = og != null ? og.OrderDate : (DateTime?)null
                     };
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|", "CustomerId", "ContactName", "OrderDate");
            foreach (var i in query)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-30}|",i.CustomerId,i.ContactName,i.OrderDate);
            }


        }

    }
}

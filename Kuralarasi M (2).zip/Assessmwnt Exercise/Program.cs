﻿using Assessmwnt_Exercise.Models;
using Microsoft.EntityFrameworkCore;


using Microsoft.EntityFrameworkCore.Internal;
namespace Assessmwnt_Exercise
{
    class History
    {
        public string ProductName { get; set; }
        public int Total { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            var context = new NorthwndContext();

            Boolean isContinue = true;
            while (isContinue)
            {
                Console.WriteLine("Menu:\n1 --- Add new Customer\n2 --- Display a list of customers and their total no.orders\n3 --- Display the top 5 expensive products" +
                "\n4 --- Display each employee’s full name and number of orders they handled\n5 --- Display all customers who didn't place any orders\n6 --- Execute 'CustOrderHist' stored procedure\n7  --- Display all products with category contains the text entered by the user\n8 --- For the given EmployeeId update the address ");
                Console.Write("Enter your Option : ");
                string str = Console.ReadLine();
                int option = int.TryParse(str, out int value) ? value : 0;
                try
                {
                    switch (option)
                    {
                        case 1:
                            Add(context);
                            break;
                        case 2:
                            DisplayCustOrder(context);
                            break;
                        case 3:
                            Expensive(context);
                            break;
                        case 4:
                            NoOrderedCus(context);
                            break;
                        case 5:
                            EmpOrder(context);
                            break;
                        case 6:
                            CustOrderHist(context);
                            break;
                        case 7:
                            DisplayAllPro(context);
                            break;
                        case 8:
                            Update(context);
                            break;
                        default:
                            Console.WriteLine("Invalid Option");
                            break;
                    }
                    Console.WriteLine("Do you Want Continue?(y/n)");
                    string s = Console.ReadLine();
                    if (s.ToLower() != "y")
                    {
                        isContinue = false;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

            }

        }
        static void Add(NorthwndContext context)
        {
            try
            {
                Console.Write("Enter your CustomerId : ");
                Boolean isRight = false;
                string Id = null;
                while (!isRight)
                {
                    Id = Console.ReadLine();
                    if (Id.Length == 5)
                    {
                        isRight = true;
                    }
                    else
                    {
                        Console.Write("Enter your CustomerId : ");
                    }

                }
                Console.Write("Enter your CompanyName : ");
                string CompanyName = Console.ReadLine();
                Boolean isRightCo = false;

                while (!isRightCo)
                {
                    CompanyName = Console.ReadLine();
                    if (Id.Length == 150)
                    {
                        isRight = true;
                    }
                    else
                    {
                        Console.Write("Enter your CompanyName : ");
                    }

                }

                Console.Write("Enter your ContactTitle : ");
                string Address = Console.ReadLine();
                if ((Address.Length) > 60)
                {
                    Address = null;
                }

                string City = Console.ReadLine();
                if ((City.Length) > 15)
                {
                    City = null;
                }
                Console.Write("Enter your Regoin : ");
                string Region = Console.ReadLine();
                if ((Region.Length) > 15)
                {
                    Region = null;
                }
                Console.Write("Enter your PostalCode : ");
                string PostalCode = Console.ReadLine();
                if ((PostalCode.Length) > 10)
                {
                    PostalCode = null;
                }
                Console.Write("Enter your Country : ");
                string Country = Console.ReadLine();
                if ((Country.Length) > 15)
                {
                    Country = null;
                }
                Console.Write("Enter your Phone : ");
                string Phone = Console.ReadLine();
                if ((Phone.Length) > 24)
                {
                    Phone = null;
                }
                Console.Write("Enter your Fax : ");
                string Fax = Console.ReadLine();
                if ((Fax.Length) > 24)
                {
                    Fax = null;
                }
                var customer = new Customer
                {
                    CustomerId = Id,
                    CompanyName = CompanyName,

                    Address = Address,
                    City = City,
                    Region = Region,
                    PostalCode = PostalCode,
                    Country = Country,
                    Phone = Phone,
                    Fax = Fax,
                };
                context.Customers.Add(customer);
                context.SaveChanges();

            }
            catch (Exception ex) {
                Console.WriteLine(ex.Message);
            }

        }
        static void DisplayCustOrder(NorthwndContext context)
        {

            var list = context.Orders.GroupBy(s => s.CustomerId).Select(m => new
            {
                CustomerId = m.Key,
                TotalOrder = m.Count()
            }).Join(context.Customers, s => s.CustomerId, t => t.CustomerId, (s, t) => new
            {
                s.CustomerId,
                t.CompanyName,
                s.TotalOrder
            }).ToList();

            Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}|", "CustomerID", "CompanyName", "TotalOrder");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}|", i.CustomerId, i.CompanyName, i.TotalOrder);
            }


        }
        static void Expensive(NorthwndContext context)
        {

            var list = context.Products.OrderByDescending(s => s.UnitPrice).Take(5).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}|", "ProductId", "ProductName", "Price");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}|", i.ProductId, i.ProductName, i.UnitPrice);
            }
        }
        static void NoOrderedCus(NorthwndContext context)
        {
            var list = context.Customers.Where(c => !context.Orders.Any(o => o.CustomerId == c.CustomerId))
      .ToList();

            Console.WriteLine("|{0,-20}|{1,-40}|", "CustomerId", "CompanyName");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|", i.CustomerId, i.CompanyName);
            }


        }
        static void CustOrderHist(NorthwndContext context)
        {
            Console.WriteLine("Enter CustomerId");
            String Id = Console.ReadLine();
            Console.WriteLine("|{0,-50}|{1,-40}|", "ProductName", "Total");
            var SpList = context.Database.SqlQueryRaw<History>($"Exec CustOrderHist @CustomerId={Id}").ToList();
            foreach (var item in SpList)
            {
                Console.WriteLine("|{0,-50}|{1,-40}|", item.ProductName, item.Total);
            }
        }
        static void DisplayAllPro(NorthwndContext context)
        {
            Console.WriteLine("Enter Category Name");
            string ProductStr = Console.ReadLine().ToLower();

            var list = context.Categories.Where(s => s.CategoryName.ToLower().Contains(ProductStr))
                      .Join(context.Products, s => s.CategoryId, t => t.CategoryId, (s, t) => new {
                          s.CategoryId,
                          s.CategoryName,
                          t.ProductId,
                          t.ProductName

                      }).ToList();
            Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}||{3,-20}|", "CategoryId", "CategoryName", "ProductId", "ProductName");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}||{3,-20}|", i.CategoryId, i.CategoryName, i.ProductId, i.ProductName);
            }

        }
        static void EmpOrder(NorthwndContext context)
        {


            var list = context.Orders.GroupBy(a => a.EmployeeId).Select(g => new
            {
                EmployeeId = g.Key,
                TotalOrder = g.Count(),

            }).Join(context.Employees, m => m.EmployeeId, n => n.EmployeeId, (m, n) => new
            {
                m.EmployeeId,
                n.FirstName,
                n.LastName,
                m.TotalOrder
            }).ToList();

            Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}||{3,-20}|", "EmployeeIdID", "FirstName", "LastName", "TotalOrder");
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-20}|{1,-40}|{2,-20}||{3,-20}|", i.EmployeeId, i.FirstName, i.LastName, i.TotalOrder);
            }
        }
        static void Update(NorthwndContext context)
        {
            Console.WriteLine("Enter CustomerId");
            string IdStr = Console.ReadLine();
            int Id = int.TryParse(IdStr, out var id) ? id : 0;
            var list = context.Employees.FirstOrDefault(s => s.EmployeeId == Id);
            if (list == null)
            {
                Console.WriteLine("Employee Not Exist");
            }
            else
            {
                Console.WriteLine("Enter Address");
                string Str = Console.ReadLine();
                list.Address = Str;
                context.SaveChanges();
            }


        }

    }
}

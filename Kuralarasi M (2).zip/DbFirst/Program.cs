﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbFirst
{
    public class ShowData
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int TotalMark { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Menu\n1 --- Add Data\n2 --- Search Data\n3 --- Delete Data\n4 --- Show Data\n5 --- Orderby Mark");
            Console.WriteLine("Enter the Option");
            string str= Console.ReadLine();
            int option=Convert.ToInt32(str);
            switch (option)
            {
                case 1:
                    Add();
                    break;
                case 2:
                    Search();
                    break;
                case 3:
                    Delete();
                    break;
                case 4:
                    Show();
                    break;
                case 5:
                    OrderByMark();
                    break;
                default:
                    break;

            }

        }
        static void Add()
        {
            Console.WriteLine("Enter your Name");
            String name= Console.ReadLine();
            Console.WriteLine("Enter your Email");
            String email = Console.ReadLine();
            Console.WriteLine("Enter your Phone");
            String phoneNo = Console.ReadLine();
            Console.WriteLine("Enter your Mark1");
            String str1 = Console.ReadLine();
            int mark1=int.TryParse(str1, out int m1) ? m1 : 0;
            Console.WriteLine("Enter your Mark2");
            String str2 = Console.ReadLine();
            int mark2 = int.TryParse(str2, out int m2) ? m2 : 0;
            Console.WriteLine("Enter your Mark3");
            String str3 = Console.ReadLine();
            int mark3 = int.TryParse(str3, out int m3) ? m3 : 0;
            Console.WriteLine("Enter your Mark4");
            String str4 = Console.ReadLine();
            int mark4 = int.TryParse(str1, out int m4) ? m4 : 0;
            Console.WriteLine("Enter your Mark5");
            String str5 = Console.ReadLine();
            int mark5 = int.TryParse(str1, out int m5) ? m5 : 0;
            using (var a = new EmployeeDBEntities())
            {
                var post = new Student
                {
                    StuName = name,
                    Email = email,
                    Mobile = phoneNo,
                    Marks = new List<Mark> {new Mark{
                        Subject1=mark1,
                        Subject2=mark2,
                        Subject3=mark3,
                        Subject4=mark4,
                        Subject5=mark5
                } }
                };
                a.Students.Add(post);
                a.SaveChanges();
               
                Console.WriteLine("Inserted Successfully");
                Show();
            }
        }
        static void Show()
        {
            using (var a=new EmployeeDBEntities())
            {
                var post = a.Students.Select(s => new ShowData
                {
                    Id = s.StudentId,
                    Name = s.StuName,
                    TotalMark = s.Marks.Select(m => m.TotalMarks ?? 0)
                                      .FirstOrDefault()
                }).ToList();
                foreach (var i in post)
                {
                    Console.WriteLine($"Id: {i.Id} Name: {i.Name} TotalMark: {i.TotalMark}");
                }
            }
        }
        static void Search()
        {
            Console.WriteLine("Enter your Id");
            String str1 = Console.ReadLine();
            int Id = int.TryParse(str1, out int m1) ? m1 : 0;
            using(var a = new EmployeeDBEntities())
            {
                var post1 = a.Students.Where(s => s.StudentId == Id).Select(s => new ShowData
                {
                    Id = s.StudentId,
                    Name = s.StuName,
                    TotalMark = s.Marks.Select(m => m.TotalMarks ?? 0).FirstOrDefault()
                });
                
                foreach (var i in post1)
                {
                    Console.WriteLine($"Id: {i.Id} Name: {i.Name} TotalMark: {i.TotalMark}");
                }
              
            }


        }
        static void Delete()
        {
            Console.WriteLine("Enter your Id");
            String str1 = Console.ReadLine();
            int Id = int.TryParse(str1, out int m1) ? m1 : 0;
            using (var a = new EmployeeDBEntities())
            {
                var post  = a.Students.FirstOrDefault(s => s.StudentId == Id);
                if (post == null)
                {
                    return;
                }

                var post1 = a.Marks.Where(s => s.StudentId == Id).ToList();
                if (post1.Any())
                {
                    a.Marks.RemoveRange(post1);
                }
               
                a.Students.Remove(post);
                a.SaveChanges();
                Console.WriteLine("Deleted Sucessfully");
                Show();

            }
        }
        static void OrderByMark()
        {

            using (var a=new EmployeeDBEntities())
            {
                var list = a.Marks.OrderByDescending(s =>  s.TotalMarks).Select(s => new ShowData
                {
                    Id = s.StudentId,
                    Name = s.Student.StuName,
                    TotalMark =(int) s.TotalMarks
                }).ToList();
                foreach (var i in list)
                {
                    Console.WriteLine($"Id: {i.Id} Name: {i.Name} TotalMark: {i.TotalMark}");
                }
            }
        }
    }
}

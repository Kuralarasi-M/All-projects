﻿using System;

namespace DbFirst
{
    public partial class EmployeeDBEntities : IDisposable
    {

    }
}
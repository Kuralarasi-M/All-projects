﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using NorthWind_Exercise_2.Models;
using System.Buffers.Text;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text.RegularExpressions;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace NorthWind_Exercise_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                bool wantContinue=false;
                while (!wantContinue)
                {
                    Console.WriteLine("Menu:\n1 --- List each employee’s full name along with all the territories they are responsible for (comma-separated). Output: EmployeeID | EmployeeName | Territories\n2 --- Find all orders in the system that do not have any related OrderDetails. Output: OrderID | CustomerID | OrderDate.\n3 --- Find the product category with the highest total quantity ordered across all orders. Output: CategoryName | TotalQuantityOrdered.\n4 --- For each customer, calculate the average number of days between their orders. Output: CustomerID | CompanyName | AvgDaysBetweenOrders." +
               "\n5 --- Display all shippers with the total order value they handled (based on Freight + sum of order details). Output: ShipperName | TotalRevenueHandled. \n6 --- Find all products that were never included in any order. Output: ProductID | ProductName | CategoryName.\n7 --- Rank employees by their total sales amount in 1998. Output: EmployeeName | TotalSales | Rank.\n8 --- Generate a report of total sales per month for the year 1997, grouped by month. Output: Month | TotalSales.\n9 --- Find the customer who had the longest gap between two consecutive orders. Output: CustomerID | CompanyName | MaxGapDays\n10 --- Find all products where the current stock (UnitsInStock) + units on order is less than the reorder level. Output: ProductID | ProductName | UnitsInStock | UnitsOnOrder | ReorderLevel" +
               "\n11 --- For each product, list the top 3 other products most frequently ordered together with it. Output: ProductName | AlsoBoughtProductName | Frequency\n12 --- Give a 10% discount to all orders placed by customers from \"Germany\" in 1997. (Update via EF Core).\n13 --- Delete all orders that were never shipped (ShippedDate IS NULL). (Handle cascading deletes safely).\n14 --- Insert a new order for an existing customer with at least 2 order details, making sure EF Core correctly saves both the order and its details.\r\n");
                    Console.Write("Enter your Option : ");
                    string str = Console.ReadLine();
                    int option = int.TryParse(str, out int value) ? value : 0;
                    var context = new NorthwndContext();
                    switch (option)
                    {
                        case 1:
                            EmployeeTerritory(context);
                            break;
                        case 2:
                            MissingOrder(context);
                            break;
                        case 3:
                            HighQuantity(context);
                            break;
                        case 4:
                            AvgDays(context);
                            break;
                        case 5:
                            ShippersTotal(context);
                            break;
                        case 6:
                            NotOrderedProduct(context);
                            break;
                        case 7:
                            HighRankEmployee(context);
                            break;
                        case 8:
                            MonthSales(context);
                            break;
                        case 9:
                            LongGap(context);
                            break;
                        case 10:
                            CurrentStock(context);
                            break;
                        case 11:
                            
                            break;
                        case 12:
                            AddDiscount(context);
                            break;
                        case 13:
                            ShipperDelete(context);
                            break;
                        case 14:
                            PlaceOrder(context);        
                            break;
                        default:
                            Console.WriteLine("Invalid Option!. Try Again.");
                            break;

                    }
                    Console.WriteLine("Do you Want to Continue?(y / n)");
                    string answer=Console.ReadLine().ToLower();
                    if(answer != "y")
                    {
                        wantContinue = true;
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }



        }
        static void EmployeeTerritory(NorthwndContext context)
        {
           // 1-- - List each employee’s full name along with all the territories they are responsible for (comma - separated).Output: EmployeeID | EmployeeName | Territories
            var list = context.Employees.Select(s => new
            {
                s.EmployeeId,
                EmployeeName = s.FirstName + " " + s.LastName,
                Territories = string.Join(", ",
                s.Territories.Select(t => t.TerritoryDescription))

            }).ToList();
            foreach (var i in list)
            {
              

                Console.WriteLine("|{0,-10}|{1,-40}|{2}|",
                    i.EmployeeId, i.EmployeeName, i.Territories.Trim());
            }

        }
        static void MissingOrder(NorthwndContext context)
        {
            // 2.Find all orders in the system that do not have any related OrderDetails. Output: OrderID | CustomerID | OrderDate.
            
            var list=context.Orders.Where(c => !context.OrderDetails.Any(o => o.OrderId==c.OrderId)).Select(s => new
                {
                    s.OrderId,
                    s.CustomerId,
                    s.OrderDate
                }).ToList();
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-10}|{1,-20}|{2,-30}|", i.OrderId,i.CustomerId,i.OrderDate);
            }
        

        }
        static void HighQuantity(NorthwndContext context)
        {
            //3.Find the product category with the highest total quantity ordered across all orders. 
            var list = (from c in context.Categories
                        join p in context.Products on c.CategoryId equals p.CategoryId
                        join od in context.OrderDetails on p.ProductId equals od.ProductId
                        group od by new { c.CategoryId, c.CategoryName } into g
                        select new
                        {
                            g.Key.CategoryId,
                            g.Key.CategoryName,
                            TotalQuantity = g.Sum(x => x.Quantity)
                        })
                              .OrderByDescending(x => x.TotalQuantity)
                              .ToList();
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-10}|{1,-20}|{2,-30}|", i.CategoryId, i.CategoryName, i.TotalQuantity);
            }

        }
        static void AvgDays(NorthwndContext context)
        {
            // 4.For each customer, calculate the average number of days between their orders. Output: CustomerID | CompanyName | AvgDaysBetweenOrders.
            var list = context.Orders.GroupBy(s => s.CustomerId).Select(d => new
            {
                CustomerId = d.Key,
                 AvgerageDay = d.Average(i => EF.Functions.DateDiffDay(i.OrderDate, i.ShippedDate.Value))
            })
            .ToList();
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-10}|{1,-20}|", i.CustomerId, i.AvgerageDay);
            }
        }
        static void ShippersTotal(NorthwndContext context)
        {
            // 5.Display all shippers with the total order value they handled(based on Freight + sum of order details).Output: ShipperName | TotalRevenueHandled.
            var list = context.Orders.GroupBy(s => s.ShipVia).Select(s => new
            {
                ShipVia = s.Key,
                Total = s.Sum(s => s.Freight)
            }).ToList();
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-10}|{1,-20}|", i.ShipVia, i.Total);
            }
        }
        static void NotOrderedProduct(NorthwndContext context)
        {
            //6.Find all products that were never included in any order. Output: ProductID | ProductName | CategoryName.
            var list=context.Products.Where(s => !(s.OrderDetails).Any(t => t.ProductId==s.ProductId)).Join(context.Categories,s=>s.CategoryId,t=>t.CategoryId,(s,t) => new
            {
                s.ProductId,
                s.ProductName,
                t.CategoryId,
                t.CategoryName,
                
            }).ToList();
            foreach (var i in list)
            {
                Console.WriteLine("|{0,-10}|{1,-20}|{2,-30}|{2,-30}|", i.ProductId,i.ProductName,i.CategoryId, i.CategoryName);
            }
        }
        static void HighRankEmployee(NorthwndContext context)
        {
            //7.Rank employees by their total sales amount in 1998.Output: EmployeeName | TotalSales | Rank.
            var i = 0;
            var list = context.Orders.Where(t => t.OrderDate.HasValue && t.OrderDate.Value.Year == 1998)
                .GroupBy(s => s.EmployeeId).Select(s => new
                {
                    EmployeeId = s.Key,
                    Total = s.SelectMany(o => o.OrderDetails).Sum(od => od.UnitPrice * od.Quantity * (1 - (decimal)od.Discount))

                }).Join(context.Employees, s => s.EmployeeId, t => t.EmployeeId, (s, t) => new
                {
                    s.EmployeeId,
                    EmployeeName = t.FirstName + t.LastName,
                    s.Total,
                    Rank = i + 1
                }).ToList();
            foreach (var j in list)
            {
                Console.WriteLine("|{0,-10}|{1,-40}|{2,-30}|{3,-10}|",j.EmployeeId,j.EmployeeName,j.Total,j.Rank);
            }
        }
        static void MonthSales(NorthwndContext context)
        {
            // 8.Generate a report of total sales per month for the year 1997, grouped by month.Output: Month | TotalSales.
            var list = context.Orders.Where(t => t.OrderDate.HasValue && t.OrderDate.Value.Year == 1997).GroupBy(
                s => (s.OrderDate.Value.Month)).Select(s => new
                {
                    Month = new DateTime(1997, s.Key, 1).ToString("MMMM"),
                    TotalSales = s.SelectMany(o => o.OrderDetails).Sum(od => od.UnitPrice * od.Quantity * (1 - (decimal)od.Discount))
                });
            foreach (var j in list)
            {
                Console.WriteLine("|{0,-10}|{1,-40}|", j.Month, j.TotalSales);
            }
        }
        static void LongGap(NorthwndContext context)
        {
            //9.Find the customer who had the longest gap between two consecutive orders.Output: CustomerID | CompanyName | MaxGapDays
            var list = context.Orders.Where(d => d.OrderDate.HasValue).OrderByDescending(s => s.OrderDate).GroupBy(s => s.CustomerId).Select(s => new
            {
                EmployeeId = s.Key,
                First = s.OrderBy(o => o.OrderDate).Select(o => o.OrderDate).FirstOrDefault(),
                Second = s.OrderBy(o => o.OrderDate).Select(o => o.OrderDate).Skip(1).FirstOrDefault()
            }).Select(i => new {
                i.EmployeeId,
                Gap=EF.Functions.DateDiffDay(i.First, i.Second)}).OrderByDescending(s => s.Gap).Take(3).ToList();

            foreach (var j in list)
            {
                Console.WriteLine("|{0,-10}|{1,-40}|",j.EmployeeId,j.Gap);
            }
        }
        static void CurrentStock(NorthwndContext context)
        {
            //10.Find all products where the current stock(UnitsInStock) +units on order is less than the reorder level.
            //Output: ProductID | ProductName | UnitsInStock | UnitsOnOrder | ReorderLevel
            try
            {
                var list=context.Products.Where(s => s.UnitsInStock+s.UnitsOnOrder<s.ReorderLevel).ToList();
                Console.WriteLine("|{0,-10}|{1,-40}|{2,-20}|{3,-20}|{4,-20}|", "ProductId", "ProductName", "UnitsInStock", "UnitsOnOrder", "ReorderLevel");
                foreach (var j in list)
                {
                    Console.WriteLine("|{0,-10}|{1,-40}|{2,-20}|{3,-20}|{4,-20}|", j.ProductId,j.ProductName,j.UnitsInStock,j.UnitsOnOrder,j.ReorderLevel);
                }
            }
            catch(Exception ex) {
                Console.WriteLine(ex.Message);
            }
        }
        static void AddDiscount(NorthwndContext context)
        {
            // 12.Give a 10 % discount to all orders placed by customers from "Germany" in 1997. (Update via EF Core).
            var answer = context.OrderDetails.Where(od => context.Orders
                       .Where(o => o.Customer.Country == "Germany"
                                   && o.OrderDate.HasValue
                                   && o.OrderDate.Value.Year == 1997)
                       .Select(o => o.OrderId)
                       .Contains(od.OrderId)).ToList();
            if (answer.Any())
            {
                foreach (var i in answer)
                {
                   i.Discount *= 0.90f;
                }
                int a=context.SaveChanges();
                Console.WriteLine(a.ToString()+" rows updated successfully.");
            }
           
            else
            {
                Console.WriteLine("There is no Orders");
            }
        }
        static void ShipperDelete(NorthwndContext context)
        {
           
            try
            {
                
                var shippersToDelete = context.Shippers
                    .Where(s => context.Orders.Any(o => o.ShipVia == s.ShipperId && o.ShippedDate == null))
                    .ToList();

                if (shippersToDelete.Any())
                {
                 

                    var ordersToDelete = (from o in context.Orders
                                          join s in context.Shippers
                                          on o.ShipVia equals s.ShipperId
                                          where o.ShippedDate == null
                                          select o).ToList();
                    
                    context.Orders.RemoveRange(ordersToDelete);

                    
                    context.Shippers.RemoveRange(shippersToDelete);

                 
                    context.SaveChanges();

                    Console.WriteLine($"{shippersToDelete.Count} shippers and {ordersToDelete.Count} orders deleted successfully!");
                }
                else
                {
                    Console.WriteLine("There is no data to delete.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);

                // Print inner exceptions recursively
                var inner = ex.InnerException;
                while (inner != null)
                {
                    Console.WriteLine("Inner Exception: " + inner.Message);
                    inner = inner.InnerException;
                }
            }

        }
        static void PlaceOrder(NorthwndContext context)
        {
            //try
            //{
            //    Console.Write("Enter your CustomerId :");
            //    string CusId=Console.ReadLine();

            //    if (CusId.Length != 5) {
            //        Console.WriteLine("Enter Valid CustomerId!. Try Again");
            //        return;
            //    }
            //    var customer=context.Customers.Any(s => s.CustomerId==CusId);
            //    if (!customer)
            //    {
            //        Console.WriteLine("Customer Not Exist!.");
            //        return;
            //    }
            //    bool continuePurchase = false;
            //    var list = new Order
            //    {
            //        CustomerId = CusId,
            //        OrderDate = DateTime.Now,
            //        RequiredDate = DateTime.Now.AddDays(15),
            //        ShippedDate = DateTime.Now.AddDays(8),
            //        ShipVia = 2,
            //        ShipCity = "London",
            //        ShipCountry = "UK",
            //        OrderDetails = new List<OrderDetail>()
            //    };
            //    while (!continuePurchase)
            //    {
            //        Console.Write("Enter ProductId : ");
            //        string PId = Console.ReadLine();
            //        int productId = int.TryParse(PId, out int proId) ? proId : 0;
            //        var productDetail = context.Products.FirstOrDefault(s => s.ProductId == productId);
            //        if (productDetail != null)
            //        {
            //            Console.Write("Enter Quantity : ");
            //            string Q = Console.ReadLine();

            //            short quantity = short.TryParse(Q, out short quan) ? quan : (short)0;
            //            list.OrderDetails.Add(new OrderDetail
            //            {
            //                ProductId = productId,
            //                Quantity = quantity,
            //                Discount = 0,
            //                UnitPrice = productDetail?.UnitPrice ?? 0m,


            //            });

            //        }
            //        else
            //        {
            //            Console.WriteLine("ProductId is Not Exist.");
            //        }
            //        Console.WriteLine("Do you want to continue?(y/n)");
            //        string str = Console.ReadLine().ToLower();
            //        if (str != "y")
            //        {
            //            continuePurchase = true;
            //        }
            //    }



            //    context.Orders.Add(list);
            //    context.SaveChanges();

            //}
            //catch (Exception ex)
            //{  Console.WriteLine(ex.ToString()); }
            try
            {
                
                    var customer = context.Customers.First(c => c.CustomerId == "ALFKI");


                    var newOrder = new Order
                    {
                        CustomerId = customer.CustomerId,
                        EmployeeId = 1,
                        OrderDate = DateTime.Now,
                        RequiredDate = DateTime.Now.AddDays(7),
                        ShipName = "Gislen",
                        ShipAddress = "Obere Str. 57",
                        ShipCity = "Chennai",
                        ShipCountry = "India"
                    };


                    newOrder.OrderDetails = new List<OrderDetail>
             {
                 new OrderDetail
                 {
                     ProductId = 1,
                     UnitPrice = 18.00m,
                     Quantity = 5,
                     Discount = 0
                 },
                 new OrderDetail
                 {
                     ProductId = 2,
                     UnitPrice = 19.00m,
                     Quantity = 3,
                     Discount = 0
                 }
             };


                    context.Orders.Add(newOrder);


                    context.SaveChanges();

                    Console.WriteLine("Added successfully");


                
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Error at Answer 14 !");
                Console.ResetColor();
                Console.WriteLine(ex.Message);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace NorthWind_Exercise_2.Models;

public partial class ProductsAboveAveragePrice
{
    public string ProductName { get; set; } = null!;

    public decimal? UnitPrice { get; set; }
}

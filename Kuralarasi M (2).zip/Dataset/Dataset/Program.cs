﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dataset
{
    internal class Program
    {
        public static string constr = ConfigurationManager.ConnectionStrings["StudentDB"].ConnectionString;
        static void Main(string[] args)
        {
           
           

            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand cmd= new SqlCommand("select * from student", con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Console.WriteLine(reader["id"]);
                }
               

            }
            SqlConnection con1 = new SqlConnection(constr);
            SqlDataAdapter adapter = new SqlDataAdapter("select * from student", con1);
            DataSet set = new DataSet();
            adapter.Fill(set);
            DataTable dt = set.Tables[0];
            
            foreach (DataRow row in dt.Rows)
            {
                Console.WriteLine(row["id"] + "-" + row["Name"]);
            }
            dt.Rows[0]["Name"] = "Alice";
            SqlCommandBuilder command = new SqlCommandBuilder(adapter);
            adapter.Update(set);
            userTable();
            Student();
        }
        static void userTable()
        {
            // Create table
            DataTable table = new DataTable();
            table.TableName = "Users";
           table.MinimumCapacity = 5;
            // create columns 
            DataColumn Id = new DataColumn("id", typeof(int));
            DataColumn userName = new DataColumn("userName", typeof(string));
            DataColumn Email = new DataColumn("Email", typeof(string));
            DataColumn Location = new DataColumn("Location", typeof(string));
            table.Columns.Add(Id);
            table.Columns.Add(userName);
            table.Columns.Add(Email);
            table.Columns.Add(Location);
            table.PrimaryKey = new DataColumn[] { Id };
            Id.AutoIncrement=true;
            Id.AutoIncrementSeed = 100;
            Id.AutoIncrementStep = 1;
            UniqueConstraint uniqueEmail = new UniqueConstraint("Email", Email);
            table.Constraints.Add(uniqueEmail);
            table.Rows.Add(null, "Kaviya", "kaviya@gmail.com", "Chennai");
            table.Rows.Add(null, "Kural", "kuralgmail.com", "Chennai");
            table.Rows.Add(null, "Dhivya", "dhivigmail.com", "Chennai");
            table.Rows.Add( null,"Nabitha", "nabi@gmail.com", "Madurai");
            table.Rows.Add(null, "Bhuvana", "bhuvana@gmail.com", "Trichy");
            foreach (DataRow row in table.Rows)
            {
                Console.WriteLine($"{row["Id"]}, {row["userName"]},{row["Email"]}, {row["Location"]}");
            }

        }
        static void Student()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlTransaction tran= con.BeginTransaction();
                try
                {
                    string query = "insert into student(Id,Name,Email,Mobile,DepartmentId) values(@Id,@Name,@Email,@Mobile,@DepartmentId)";
                    SqlCommand cmd = new SqlCommand(query, con,tran);
                    cmd.Parameters.AddWithValue("@Id", 112);
                    cmd.Parameters.AddWithValue("@Name","Jane");
                    cmd.Parameters.AddWithValue("@Email","jane@gmail.com" );
                    cmd.Parameters.AddWithValue("@Mobile", 343434343);
                    cmd.Parameters.AddWithValue("@DepartmentId", 1);
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Insertion Success!");
                    tran.Commit();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Insertion Failed");
                    Console.WriteLine(ex.Message);
                    tran.Rollback();
                }
                SqlDataAdapter adapt=new SqlDataAdapter("select * from student",constr);
                DataTable table=new DataTable();
                adapt.Fill(table);
                DataView stuView = new DataView(table);
                DataView studentView = table.DefaultView;
                for (int i = 0; i < stuView.Count; i++)
                {
                    Console.WriteLine($"Id : {stuView[i]["Id"]}  Name : {stuView[i]["Name"]}");
                }
                foreach(DataRowView row in studentView)
                {
                    DataRow i = row.Row;
                    Console.WriteLine($"Id : {i["Id"]}   Name : {i["Name"]}   Email : {i["Email"]}");
                }
            }

        }

    }
}

﻿using Exercise_25Aug.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Linq;
using System.Xml.Linq;
using static Azure.Core.HttpHeader;
namespace Exercise_25Aug
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            using (var a = new AdventureWorks2019Context())
            {
                //var list=a.Products.Take(30).ToList();
                //Console.WriteLine(new string('_', 150));
                //Console.WriteLine("|{0,-20}|{1,-50}|{2,-20}|{3,-30}|", "ProductNumber", "Name", "ProductId", "ListPrice");
                //Console.WriteLine(new string('_', 150));
                //foreach (var i in list)
                //{
                //    Console.WriteLine("|{0,-20}|{1,-50}|{2,-20}|{3,-30}|",i.ProductNumber,i.Name,i.ProductId,i. ListPrice);
                //}
                //Console.WriteLine(new string('_',150));
                var Employees = (from p in a.People join emp in a.Employees on p.BusinessEntityId equals emp.BusinessEntityId
                                 select new
                                 {
                                     p.BusinessEntityId,
                                     p.FirstName,
                                     p.LastName,
                                     emp.HireDate,
                                     emp.Gender,
                                     emp.JobTitle
                                 }).Where(d => d.HireDate.Year>2010).ToList();
                Console.WriteLine(new string('_', 150));
                Console.WriteLine("{0,-20}|{1,-20}|{2,-20}|{3,-30}|{4,-30}|{5,-30}", "BusinessEntityId", "FirstName", "LastName", "HireDate", "Gender", "JobTitle");
                foreach (var emp in Employees)
                {
                    Console.WriteLine("{0,-20}|{1,-20}|{2,-20}|{3,-30}|{4,-30}|{5,-30}",emp.BusinessEntityId,emp.FirstName,emp.LastName,emp.HireDate,emp.Gender,emp.JobTitle);
                }
                var product=a.Products.Take(10).OrderByDescending(p => p.ListPrice).ToList();
                Console.WriteLine(new string('_', 150));
                Console.WriteLine("|{0,-20}|{1,-50}|{2,-20}|{3,-30}|", "ProductId", "Name", "ProductNumber", "ListPrice");
                Console.WriteLine(new string('_', 150));
                foreach (var i in product)
                {
                    Console.WriteLine("|{0,-20}|{1,-50}|{2,-20}|{3,-30}|",i.ProductId,i.Name,i.ProductNumber,i.ListPrice);
                }
                Console.WriteLine(new string('_', 150));
                var customerList = (from p in a.People
                                    join ad in a.BusinessEntityAddresses on p.BusinessEntityId equals
                                   ad.BusinessEntityId
                                   
                                    join c in a.Customers on p.BusinessEntityId equals  c.Person.BusinessEntityId
                                    join add in a.Addresses on ad.AddressId equals add.AddressId
                                    select new
                                    {
                                         p.FirstName,
                                         p.LastName,
                                         p.BusinessEntityId,
                                         add.City,

                                    }).Where(p => p.City.ToLower()=="london").OrderBy(l => l.LastName).Take(20).ToList();
                Console.WriteLine(new string('_', 150));
                Console.WriteLine("|{0,-20}|{1,-50}|{2,-20}|{3,-30}| ", "BusinessEntityId", "FirstName" , "LastName" , "City");
                Console.WriteLine(new string('_', 150));
                foreach (var i in customerList)
                {
                    Console.WriteLine("|{0,-20}|{1,-50}|{2,-20}|{3,-30}| ",i.BusinessEntityId,i.FirstName,i.LastName,i.City);
                }
                Console.WriteLine(new string('_', 150));
                var productList= a.Products.Where(a => a.SafetyStockLevel == 0).ToList();
                Console.WriteLine(new string('_', 150));
                Console.WriteLine("|{0,-20}|{1,-50}|{2,-20}|{3,-30}|", "ProductId", "Name", "ProductNumber", "ListPrice");
                Console.WriteLine(new string('_', 150));
                foreach (var i in productList)
                {
                    Console.WriteLine("|{0,-20}|{1,-50}|{2,-20}|{3,-30}|", i.ProductId,i.Name,i.ProductNumber,i.ListPrice);
                }
                Console.WriteLine(new string('_', 150));
                //6.Get the 5 most recent orders placed.
                var orderProduct = (from order in a.SalesOrderHeaders.OrderByDescending(s => s.OrderDate).Take(5)
                                    join orderDet in a.SalesOrderDetails on order.SalesOrderId equals orderDet.SalesOrderId
                                    join p in a.Products on orderDet.ProductId equals p.ProductId
                                    select new
                                    {
                                        order.SalesOrderId,
                                        order.OrderDate,
                                        orderDet.ProductId,
                                        p.Name,
                                        p.ListPrice
                                    }).ToList();
                Console.WriteLine(new string('_', 150));
                Console.WriteLine("|{0,-20}|{1,-50}|{2,-20}|{3,-30}|{4,-30}|", "SalesOrderId", "OrderDate", "ProductId", "Name", "ListPrice");
                Console.WriteLine(new string('_', 150));
                foreach (var i in orderProduct)
                {
                    Console.WriteLine("|{0,-20}|{1,-50}|{2,-20}|{3,-30}|{4,-30}|", i.SalesOrderId,i.OrderDate,i.ProductId,i.Name,i.ListPrice);
                }
                Console.WriteLine(new string('_', 150));
                Console.Write("Enter the CustomerId : ");
               
                
                string str = Console.ReadLine();

                int Id = int.Parse(str);
                var customerOrder = (from OrderHead in a.SalesOrderHeaders
                                     join orderDet in a.SalesOrderDetails on OrderHead.SalesOrderId equals orderDet.SalesOrderId
                                     join p in a.Products on orderDet.ProductId equals p.ProductId 
                                     join c in a.Customers on  OrderHead.CustomerId equals c.CustomerId
                                     join per in a.People on c.Person.BusinessEntityId equals per.BusinessEntityId
                                     select new
                                     {
                                         OrderHead.OrderDate,
                                         p.ProductId,
                                         p.Name,
                                         c.CustomerId,
                                         per.FirstName,
                                         per.LastName
                                     }).Where(s => s.CustomerId== Id).ToList();

                Console.WriteLine(new string('_', 150));
                Console.WriteLine("|{0,-20}|{1,-20}|{2,-20}|{3,-20}|{4,-20}|{5,-20}|","CustomerId", "FirstName", "LastName", "ProductId", "Name", "OrderDate");
                Console.WriteLine(new string('_', 150));
                foreach (var o in customerOrder)
                 {
                    Console.WriteLine("|{0,-20}|{1,-20}|{2,-20}|{3,-20}|{4,-20}|{5,-20}|", o.CustomerId, o.FirstName, o.LastName,o.ProductId,o.Name,o.OrderDate);
                }

                  
                
                Console.WriteLine(new string('_', 150));
                // 8.List all employees along with their managers’ names.

                //var empMan = (from emp in a
                //             join empDep in a.EmployeeDepartmentHistories on emp.BusinessEntityId equals empDep.BusinessEntityId


                // 9. 9.Show the department name for each employee.
                var EmpDept = (from emp in a.Employees
                               join empdep in a.EmployeeDepartmentHistories
                              on emp.BusinessEntityId equals empdep.BusinessEntityId
                              join per in a.People on emp.BusinessEntityId equals per.BusinessEntityId
                              join dep in a.Departments on empdep.DepartmentId equals dep.DepartmentId
                              select new
                              {
                                  per.BusinessEntityId,
                                  per.FirstName,
                                  per.LastName,
                                  dep.DepartmentId,
                                  dep.Name
                              }
                              ).ToList();
                Console.WriteLine(new string('_', 150));
                Console.WriteLine("|{0,-20}|{1,-20}|{2,-20}|{3,-20}|{4,-20}|", "BusinessEntityId", "FirstName", "LastName", "DepartmentId", "Name");
                Console.WriteLine(new string('_', 150));
                foreach (var i in EmpDept)
                {
                    Console.WriteLine("|{0,-20}|{1,-20}|{2,-20}|{3,-20}|{4,-20}", i.BusinessEntityId,i.FirstName,i.LastName,i.DepartmentId,i.Name);
                }
                Console.WriteLine(new string('_', 150));
                //10.Find the total sales for each year.
                var SalesList = a.SalesOrderHeaders.GroupBy(a => a.OrderDate.Year).Select(b => new
                {
                    OrderYear= b.Key,
                    sum = b.Sum( s => s.TotalDue)

                });
                foreach (var i in SalesList)
                {
                    Console.WriteLine(i.OrderYear+ " - "+i.sum);
                }
                //11.	Get the average list price of products in each subcategory
                //var subCat= (from sub in a.ProductSubcategories join cat in a.Products 
                //             on sub.ProductSubcategoryId equals cat.ProductSubcategoryId
                //             ).GroupBy(p => p.ProductCategoryId).ToList();
                var subList = a.Products.GroupBy(s => s.ProductSubcategoryId).Select(m => new
                {
                    ProdSubCatId=m.Key,
                    avg=m.Average(n => n.ListPrice)
                }).ToList();
                Console.WriteLine(new string('_', 43));
                Console.WriteLine("|{0,-20}|{1,-20}|", "ProductSubcategoryId", "AverageListPrice");
                Console.WriteLine(new string('_', 43));
                foreach (var i in subList)
                {
                    Console.WriteLine("|{0,-20}|{1,-20:F3}|", i.ProdSubCatId,i.avg);
                }
                Console.WriteLine(new string('_', 43));
                //12.Find the best-selling product by total quantity sold
                //var bsp = a.Products.GroupBy(s => s.ProductId).Select(
                //    m => new
                //    {
                //        ProductId = m.Key,
                //        Quantity = m.Sum(n => n.OrderId)
                //    }).ToList();
            }


        }
    }
}

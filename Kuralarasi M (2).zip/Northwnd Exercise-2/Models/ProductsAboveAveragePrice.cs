﻿using System;
using System.Collections.Generic;

namespace Northwnd_Exercise_2.Models;

public partial class ProductsAboveAveragePrice
{
    public string ProductName { get; set; } = null!;

    public decimal? UnitPrice { get; set; }
}



$(document).ready(function () {

    //Display Data     
    function loadThePage(){
         $.get('http://localhost:5000/employees', function (data) {
        let colCount = 6;

        // If no employees found
        if (!data || data.length === 0) {
            $('#emstable').append(`
            <tr class="empty-row">
                <td colspan="${colCount}" style="text-align:center;" class="p-2">
                   No Employees found
                </td>
            </tr>`);
            return;
        }

        data.forEach(element => {
            $('#emstable').append(`<tr>
            <td contenteditable="false">${element.name}</td>
              <td contenteditable="false">${element.email}</td>
              <td contenteditable="false">${element.department}</td>
              <td contenteditable="false">${element.joiningDate}</td>
              <td contenteditable="false">${element.salary}</td>
              <td><button class="editBtn bg-warning" data-id="${element.id}">Edit</button>
              <button class="deleteBtn bg-danger" data-id="${element.id}">Delete</button></td>
              </tr>`)


        });


    })
    }
    loadThePage();


    //    delete data


   // Delete employee dynamically
$(document).on("click", ".deleteBtn", function () {
    let empId = $(this).data('id');           
    let row = $(this).closest("tr");          

    if (confirm("Are you sure you want to delete this employee?")) {
        $.ajax({
            url: `http://localhost:5000/departments/${deptId}`,
            method: "DELETE",
            success: function () {
                row.remove();              
                alert("Employee deleted successfully!");
            },
            error: function () {
                alert("Error deleting employee.");
            }
        });
    }
});

    // add the Data
    $(document).ready(function () {

        $("#empSubmitBtn").click(async function (event) {
            event.preventDefault(); 
            const isValid = await validateInput();

            if (!isValid) return;
            const newEmployee = {
                name: $('#name').val().trim(),
                email: $('#email').val().trim(),
                department: $('#dep').val(),
                joiningDate: $('#jdate').val().trim(),
                salary: Number($('#sal').val().trim())
            };

          
            $.ajax({
                url: "http://localhost:5000/employees",
                method: "POST",
                contentType: "application/json",
                data: JSON.stringify(newEmployee),
                success: function () {
                    alert("Employee added successfully!");
                     window.location.href = "EmployeePage.html";
                },
                error: function (xhr, status, err) {
                    console.error("Error:", err);
                }
            });

        });

        // Input validation function
        async function validateInput() {
            $('.err1, .err2, .err3, .err4, .err5').text('');
            let departments = await $.get('http://localhost:5000/departments');
            let name = $('#name').val().trim();
            let email = $('#email').val().trim();
            let dept = $('#dep').val();
            let jdate = $('#jdate').val().trim();
            let salary = $('#sal').val().trim();
            let isValid = true;

            const emailPattern = /^[^\s]+@[^\s]+\.[^\s]+$/;
            const today = new Date();

            if (name.length < 3) {
                $('.err1').text('Minimum 3 characters required.');
                isValid = false;
            }

            if (!emailPattern.test(email)) {
                $('.err2').text('Enter a valid email address.');
                isValid = false;
            }

            if (dept === "") {
                $('.err3').text('Please select a department.');
                isValid = false;
            }

            if (jdate === "") {
                $('.err4').text('Please enter your joining date.');
                isValid = false;
            } else {
                let joinDate = new Date(jdate);
                if (isNaN(joinDate.getTime())) {
                    $('.err4').text('Invalid date format.');
                    isValid = false;
                } else if (joinDate > today) {
                    $('.err4').text('Joining date cannot be in the future.');
                    isValid = false;
                }
            }

            if (salary === "" || Number(salary) <= 0) {
                $('.err5').text('Salary must be a positive number.');
                isValid = false;
            }

            return isValid;
        }
    });



    // sorting
    $('select[name="sorting"]').on('change', function () {
        let sortByval = $(this).val();
        let columnNo;
        switch (sortByval) {
            case "Name": columnNo = 0; break;
            case "Email": columnNo = 1; break;
            case "Dept": columnNo = 2; break;
            case "Jdate": columnNo = 3; break;
            case "Salary": columnNo = 4; break;
            default: return;
        }
        let rows = $('#emstable tr').not(':lt(2)').get();
        rows.sort(function (a, b) {
            let m = $(a).children('td').eq(columnNo).text().toLowerCase();
            let n = $(b).children('td').eq(columnNo).text().toLowerCase();
            if (sortByval == "Jdate") {
                return new Date(m) - new Date(n);
            }
            if (sortByval == "Salary") {
                return parseFloat(m) - parseFloat(n);
            }
            return m.localeCompare(n);
        })
        $.each(rows, function (index, row) {
            $('#emstable').append(row);
        });
    });


    // search on keyup
    $('#emstable tr:eq(1) input').on('keyup', function () {
        let filters = [];

        $('#emstable tr:eq(1) input').each(function () {
            let val = $(this).val().toLowerCase();
            filters.push(val);
        });

        // save to localStorage
        localStorage.setItem("employeeFilters", JSON.stringify(filters));

        // apply filters only when typing
        applyFilters(filters);
    });

    function applyFilters(filters) {
        $('#emstable tr.empty-row').remove();

        $('#emstable tr').each(function (index) {
            if (index < 2) return; // skip header & filter row
            let $row = $(this);
            if ($row.hasClass('empty-row')) return;

            let show = true;
            $row.find('td').each(function (colIndex) {
                if (colIndex >= filters.length) return; 
                let filterVal = filters[colIndex];
                if (filterVal) {
                    let cellText = $(this).text().toLowerCase();
                    if (!cellText.includes(filterVal)) {
                        show = false;
                    }
                }
            });
            $row.toggle(show);
        });

     
        let visibleRows = $('#emstable tr:visible').filter(function (index) {
            return index >= 2; 
        }).length;

        if (visibleRows === 0) {
            let colCount = $('#emstable tr:first th').length;
            $('#emstable').append(`
            <tr class="empty-row">
                <td colspan="${colCount}" style="text-align:center;" class="p-2">
                   No Employees found
                </td>
            </tr>
        `);
        }
    }



    // Department Options
    $.get('http://localhost:5000/departments', function (data) {
        data.forEach(dept => {
            $('#dep').append(`<option value="${dept.name}">${dept.name}</option>`);
        });
    });


    // Update Employee Data
    $(document).on("click", ".editBtn", function () {
    let empId = $(this).data("id");   // get employee id
    localStorage.setItem("editEmployeeId", empId); 
    window.location.href = "EmpForm.html";
    console.log(empId)
});
$(document).ready(function () {
    let editId = localStorage.getItem("editEmployeeId");



       
        if (editId) {
            
            $.get(`http://localhost:5000/employees/${editId}`, function(emp) {
                $('#name').val(emp.name);
                $('#email').val(emp.email);
                $('#jdate').val(emp.joiningDate);
                $('#sal').val(emp.salary);
                $('#dep').val(emp.department); 
            });

            $("#empSubmitBtn").text("Update Employee");

            $("#empSubmitBtn").off("click").on("click", function (event) {
                event.preventDefault();

                let updatedEmployee = {
                    name: $('#name').val(),
                    email: $('#email').val(),
                    department: $('#dep').val(),
                    joiningDate: $('#jdate').val(),
                    salary: $('#sal').val()
                };

                $.ajax({
                    url: `http://localhost:5000/employees/${editId}`,
                    method: "PUT",
                    contentType: "application/json",
                    data: JSON.stringify(updatedEmployee),
                    success: function () {
                        alert("Employee updated successfully!");
                        localStorage.removeItem("editEmployeeId");
                        window.location.href = "EmployeePage.html";
                    }
                });
            });
        }
    });
    //  Reset 
    $(document).on("click", ".rbtn", function() {
      $('#emstable tr:gt(1)').remove(); 


         loadThePage();
      
    });
});





$(document).ready(function(){
    try{
        async function LoadEmployeeDetail()  {
        try{
            let empData=await  $.get('http://localhost:5000/departments');
            empData.forEach(element => {
                $('#deptable').append(`<tr><td>${element.id}</td>
                <td contenteditable="false">${element.name}</td>
                <td contenteditable="false">${element.code}</td>
                <td><button class="editBtn bg-warning" data-id="${element.id}">Edit</button>
                <button class="deleteBtn bg-danger" data-name="${element.name}">Delete</button></td>
                 </tr>`)
            })
        }
        catch(err){
            console.error("Error fetching employees:", err);
            
        }

    }
    LoadEmployeeDetail();

    $("#deptsubmit").click(async function(event) {
    event.preventDefault(); 

    const isValid = await validateinput(); 
    if (!isValid) return; 

    let id = $('#id').val();
    let name = $('#name').val();
    let code = $('#code').val();

    $.ajax({
        url: 'http://localhost:5000/departments',
        method: "POST",
        contentType: "application/json",
        data: JSON.stringify({ id: id, name: name, code: code }),
        success: function(res) {
            console.log("success", res);

            
            $('#deptable').append(`
                <tr>
                    <td>${id}</td>
                    <td contenteditable="false">${name}</td>
                    <td contenteditable="false">${code}</td>
                    <td>
                        <button class="editBtn" data-id="${id}">Edit</button>
                        <button class="deleteBtn" data-id="${id}">Delete</button>
                    </td>
                </tr>
            `);

          
            $('#id, #name, #code').val('');
             window.location.href = "DepartmentPage.html";
        },
        error: function(err) {
            console.log("error", err);
        }
    });
});

    async  function validateinput() {
       
       let departments=await  $.get('http://localhost:5000/departments');
        let found = true;
        let id   = $('#id').val();
        let name = $('#name').val();
        let code = $('#code').val();

        $('.err1').text('');
        $('.err2').text('');
        $('.err3').text('');

        if(id <= 0 || id === '') {
            $('.err1').text('Id must be positive');
            found = false;
        }

        // Check if department ID already exists
        let exists = departments.some(d => String(d.id) === String(id));
        if(exists) {
            $('.err1').text('Department ID already exists!');
            found = false;
        }

        if(name.length < 3) {
            $('.err2').text('Minimum 3 characters required.');
            found = false;
        }
         let codeExists = departments.some(d => String(d.code) === String(code));
        if(codeExists) {
            $('.err3').text('Department Already Exists.');
            found = false;
        }
        if(code.length < 2) {
            $('.err3').text('Minimum 2 characters required.');
            found = false;
        }

        return found; 
    };



        



     // Edit 
    $(document).on("click", ".editBtn", function() {
    let row = $(this).closest("tr");
    let editableCells = row.find("td").not(":last"); 

    if ($(this).text() === "Edit") {
        editableCells.attr("contenteditable", "true").addClass("bg-light"); 
        row.addClass("table-warning"); 
        $(this).text("Save").removeClass("btn-warning").addClass("btn-success");
    } else {
        editableCells.attr("contenteditable", "false").removeClass("bg-light");
        row.removeClass("table-warning"); // remove highlight
        $(this).text("Edit").removeClass("btn-success").addClass("btn-warning");

        // collect updated values
        let values = editableCells.map(function() { return $(this).text(); }).get();
        console.log("Updated row:", values);
        
        
        $.ajax({
            url: `http://localhost:5000/departments/${$(this).data("id")}`,
            method: "PUT",
            contentType: "application/json",
            data: JSON.stringify({
                id: values[0],
                name: values[1],
                code: values[2],
               
            }),
            success: function(res) {
                console.log("Updated successfully", res);
            }
        });
    }
    
});
// Delete data
$(document).on("click", ".deleteBtn", function () {
    let deptName = $(this).data("name"); // department name
    let row = $(this).closest("tr");     // table row

    // 1. Find department by name
    $.get(`http://localhost:5000/departments?name=${deptName}`, function(depts) {
        if (depts.length === 0) {
            alert(`Department "${deptName}" not found!`);
            return;
        }

        let deptId = depts[0].id; // get the department ID

        // 2. Check if department has employees
        $.get(`http://localhost:5000/employees?department=${deptName}`, function (emps) {
            if (emps.length > 0) {
                alert(`Cannot delete department "${deptName}" because it still has employees.`);
            } else {
                if (confirm(`Are you sure you want to delete department "${deptName}"?`)) {
                    $.ajax({
                        url: `http://localhost:5000/departments/${deptId}`, // DELETE by ID
                        method: "DELETE",
                        success: function () {
                            alert(`Department "${deptName}" deleted successfully!`);
                            row.remove(); // remove row dynamically
                        },
                        error: function () {
                            alert("Error deleting department.");
                        }
                    });
                }
            }
        });
    });
});


// search
    $('#deptable tr:first input').on('keyup',function() {
        let col=$(this).parent().index();
        let con=$(this).val().toLowerCase();
         let hasVisible = false;
        $('#deptable tr').each(function(index){
            if(index < 2) return;
            let cellText=$(this).find('td').eq(col).text().toLowerCase();
            let match=cellText.indexOf(con)> -1;
            $(this).toggle(match);
            if(match){
                 hasVisible = true;
            }
        });
        if(!hasVisible){
            $('#deptable').append(`
            <tr class="empty-row">
                <td colspan="4" style="text-align:center;">
                    Department not found
                </td>
            </tr>
        `);
    
        }
        
    });
   

     
   // sorting data
    $('select[name="sorting"]').on('change',function(){
        let col=$(this).val();
        let columnNo;
        switch (col) {
            case "DeptId":
                columnNo=0;
                break;
            case "Name":
                columnNo=1;
                break;
            case "Code":
                columnNo=2;
                break;
            default:
                break;
        }
        let rows= $('#deptable tr').not(':lt(2)').get();
        rows.sort(function(a,b){
            let m=$(a).children('td').eq(columnNo).text().toLowerCase();
            let n=$(b).children('td').eq(columnNo).text().toLowerCase();
            if(col=="Id"){
                return parseInt(m)-parseInt(n);
            }
            return m.localeCompare(n);
        });
        console.log(rows.length);
        
       
        $.each(rows, function (index, row) {
            $('#deptable').append(row);
        });
    
        
    });
   


    // reset button
    $("#resetBtn").on("click", function () {

        $("#deptable tr:gt(1)").remove();
        $("#deptable tr:first input").val('');
         $.get('http://localhost:5000/departments',function(data){
        data.forEach(element => {
             $('#deptable').append(`<tr><td>${element.id}</td>
              <td contenteditable="false">${element.name}</td>
              <td contenteditable="false">${element.code}</td>
              
              <td><button class="editBtn" data-id="${element.id}">Edit</button>
              <button class="deleteBtn" data-id="${element.id}">Delete</button></td>
              </tr>`)
       })
             
   })

    });
        // search
$('#deptable tr:eq(1) input').on('keyup', function () {
    let filters = [];

    // collect all input values from the search row
    $('#deptable tr:eq(1) input').each(function () {
        let val = $(this).val().toLowerCase();
        filters.push(val);
    });

    let hasValue = false;

    $('#deptable tr').each(function (index) {
        if (index < 2) return; // skip first 2 rows
        if ($(this).hasClass('empty-row')) return;

        let show = true;

        $(this).find('td').each(function (colIndex) {
            if (filters[colIndex]) {
                let cellText = $(this).text().toLowerCase();
                if (cellText.indexOf(filters[colIndex]) === -1) {
                    show = false;
                }
            }
        });

        $(this).toggle(show);

        if (show) hasValue = true;
    });


    $('#deptable tr.empty-row').remove();

    // show message if nothing matches
    if (!hasValue) {
        let colCount = $('#deptable tr:first th').length;
        $('#deptable').append(`
            <tr class="empty-row">
                <td colspan="${colCount}" style="text-align:center;" class="p-2">
                   No Departments found
                </td>
            </tr>`);
    }
});
        
    }
   catch(err){
            console.error("Error fetching employees:", err);
            
        }
    
});


import createPrompt from 'prompt-sync';
const prompt=createPrompt();
let number1=prompt("Enter the number: ");
if(Number(number1)%2==0){
    console.log(`${number1} is Even Number`);
}
else if(Number(number1)%2==1){
    console.log(`${number1} is odd Number`);
}
else{
     console.log(`${number1} is Not a Number`);
}
import createPrompt from 'prompt-sync';
const prompt=createPrompt();
let userName=prompt("Enter Your Name: ");
let pattern=/^[A-Za-z]{4,}$/;
if (pattern.test(userName)){
    console.log(`Welcome ${userName} !`);
}
else{
    console.log("Please Enter Correct Name");
}

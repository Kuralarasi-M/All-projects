let Today=new Date();
let tdate=Today.getDate();
let tmonth=Today.getMonth();
let tyear=Today.getFullYear();
 Today=Today.toLocaleDateString(tdate,tmonth,tyear);
console.log(Today);
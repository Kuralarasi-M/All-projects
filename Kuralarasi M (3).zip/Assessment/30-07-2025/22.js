import createPrompt from 'prompt-sync';
const prompt=createPrompt();
let userInput=prompt("Enter your Birth year: ");
let Today=new Date();
let currentYear=Today.getFullYear();
let Age=currentYear-userInput;
console.log("Your Age is: "+Age);
if(Age<19){
    console.log("you are Teenager");
}
else if(Age>=19 && Age<=40){
    console.log("you are Adult");
}
else if(Age>40){
    console.log("you are senior citizen");
}
else{
    console.log("your input is wrong! please enter correct input.");
}

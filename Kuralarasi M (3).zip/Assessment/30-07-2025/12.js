let number=3.14159;
number=number.toFixed(2);
console.log(number);
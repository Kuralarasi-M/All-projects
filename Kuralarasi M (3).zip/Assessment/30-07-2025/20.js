import createPrompt from 'prompt-sync';
const prompt=createPrompt();
let userName=prompt("Enter Your UserName: ");
if(userName==""){
    console.log("Empty String!Please Enter your Name");
}
else{
    console.log(`Hello ${userName} !`);
}
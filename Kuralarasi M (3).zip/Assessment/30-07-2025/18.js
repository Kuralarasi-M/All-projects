import createPrompt from 'prompt-sync';
const prompt=createPrompt();
let input=prompt("Enter Your DOB: ");
let DOB=new Date(input);
let Today=new Date();
let diff=(Today-DOB)/(24*60*60*1000*365.25);
let Age=Math.floor(diff);
if(!isNaN(Age)){
   console.log("Please Enter Valid Date");
}
else{
    console.log(Age);
}




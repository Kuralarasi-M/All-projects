let number1=10;
if(number1>0){
   console.log("Number is Positive");
}
else if(number1<0){
   console.log("Number is Negative");
}
else{
    console.log("Number is not Both");
}

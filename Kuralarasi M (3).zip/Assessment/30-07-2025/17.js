let userName="kuralarasi";
console.log("User: " + userName.toUpperCase());

const student = { name: "Tom", age: 21 };

let studentJson=JSON.stringify(student); 
let studentobj1=JSON.parse(studentJson);
console.log(studentJson); // JSON Format
console.log(studentobj1); //  JS Object



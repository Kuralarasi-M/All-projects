// 1)    c) let name = "John";
// 2)   True
// 3)   let --  it can be reassign, not redeclare,block  scope
//      var --  it can reassign, redeclare and have  global scope
//      const -- it can't reassign,redeclare , must initialize  and block scope.
// 4)   undefined -- if we doesnot initialize variable then by default it is undefined.it comes under in undefined type.  
//       null -- we can assign variable as null . it doesn't contains anything . it comes under in object type. 
// 5)    JS Object to JSON -- by using JSON.Stringify(object1);
//       JSON to JS Object -- by using JSON.Parse(object1);
// 6)      a) false
//          b) 0
//7)  False , The === operator only checks  both value and type equality.
// 8)  if(userinput!=""){.....}
//     else{ console.log("Input is empty") ; }



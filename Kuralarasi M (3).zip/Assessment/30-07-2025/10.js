/* let name = "Alice"; // this is single line comment
    let age = 30;*/
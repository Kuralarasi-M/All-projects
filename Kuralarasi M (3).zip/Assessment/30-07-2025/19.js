import createPrompt from 'prompt-sync';
const prompt=createPrompt();
let Age=prompt("Enter Your Age: ");
if(Number(Age)>18){
    console.log("You are eligible for Voting");
}
else if(Number(Age)<18){
    console.log("You are not eligible for Voting");
}
else {
    console.log("Please enter valid age!");
}


// for Add Task
document.querySelector("form").addEventListener("submit", async (e) => {
    e.preventDefault();
    
    let title=document.getElementById('title').value.trim();
    let description=document.getElementById('Description').value.trim()
    let prio=document.getElementById('Priority');
    let priority=String(prio.value);
    let createdDate=new Date();
    let isDone="false";
    try {
        let res = await fetch("http://localhost:5000/tasks", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ title, description, priority,createdDate,isDone})
        });
        getStore(title,description,priority,createdDate,isDone);
        
    } catch (err) {
        console.error("Error:", err);
    }
});
/// for Show the task
let display=document.querySelector(".main");
let ul=document.createElement('table');
let showbtn=document.querySelector(".showbtn").addEventListener('click',async ()=>{
    display.innerHTML="";
    try{
       let data=await fetch("http://localhost:5000/tasks");
       let user=await data.json();
      
       user.forEach(user => {
          let ele=fun(user)
           
      });
    }
   catch(err){
    console.log(err);
    
   }
   
})
// function for display the Task
function fun(user){
       let tr1=document.createElement('p');
        let tr2=document.createElement('p');
        let tr3=document.createElement('p');
        let tr4=document.createElement('p');
        let tr5=document.createElement('p');
        let tr6=document.createElement('p')
        let tr8=document.createElement('button');
        let tr9=document.createElement('button');
        let tr7=document.createElement('hr');
        tr1.textContent=`Id :${user.id} `
        tr2.textContent=`Title :${user.title} `
        tr3.textContent=`Description :${user.description}`
        tr4.textContent=`priority:  ${user.priority} `
        tr5.textContent=` isDone: ${user.isDone} `
        tr6.textContent=`CreatedDate: ${user.createdDate} `;
        tr8.textContent=`Update`
        tr9.textContent=`Delete`;
        display.appendChild(tr1);
        display.appendChild(tr2);
        display.appendChild(tr3);
        display.appendChild(tr4);
        display.appendChild(tr5);
        display.appendChild(tr6);
        display.appendChild(tr8);
        display.appendChild(tr9);
        display.appendChild(tr7);
        
}
// function for all Task in localStorage
function getStore(title,description,priority,createdDate,isDone){
      localStorage.clear();
      
        localStorage.setItem("ID",userid);
        localStorage.setItem("Title",title);
         localStorage.setItem("Description",description);
        localStorage.setItem("priority",priority);
         localStorage.setItem("isDone",isDone);
        localStorage.setItem("CreatedDate",createdDate);
        
}    

//  for Update task
let display1=document.querySelector(".main");
let updatebtn=document.querySelector(".updatebtn").addEventListener('click',async ()=>{
    display1.innerHTML="";
    let value=document.querySelector('.update').value.trim();
    let p=document.createElement('p');
       let isDone=prompt("are you completed");
       console.log(isDone);
       console.log(value);
       
       let ans;
       if(isDone.trim().toLowerCase()=='yes'){
           ans=true;
           
       }
       else{
           ans=false;
       }
       let updatedDate=new Date();
       await fetch(`http://localhost:5000/tasks/${value}`,{
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({isDone:ans,updatedDate:updatedDate})
       })
        .then((ans)=>{
        if(!ans.ok){
            throw 'task is not found';
        }
        else {
            p.textContent=`updated task ${value}`;
            display1.appendChild(p);

        }
             
     })
     .catch((err)=>{
          p.textContent=err;
        display1.appendChild(p);
     })

});

// Delete Task
let display2 = document.querySelector('.main');
let deletebtn=document.querySelector('.deletebtn').addEventListener('click',async (event)=>{
    event.preventDefault();
    let value=document.querySelector('.delete').value.toLowerCase().trim();
    display2.innerHTML="";
    let p=document.createElement('p');
    await fetch(`http://localhost:5000/tasks/${value}`,{
        method:"DELETE"
    })
    .then((ans)=>{
        if(!ans.ok){
           throw `Task(${value})  is not found`
        }
        else{
           p.textContent=`Task(${value}) Deleted Successfully.`
           display2.appendChild(p);
        }
   
    })
    .catch((err)=>{
        p.textContent=err;
        display2.appendChild(p);
    });
});
   

// // for search
// let display3 = document.querySelector('.main');
// let searchbtn=document.querySelector('.searchbtn').addEventListener('click',async (event)=>{
//     event.preventDefault();
//     let value=document.querySelector('.search').value.toLowerCase().trim();
//     display3.innerHTML="";
//     console.log(value);
//     let p=document.createElement('p');
//     let task= await fetch(`http://localhost:5000/tasks/${value}`)
//     .then((ans)=>{
        
//         //  let  ans=task.json();
//     })
//     .catch((err)=>{
    
        
//         p.textContent=err;
//         display2.appendChild(p);
//     });
//       p.textContent=ans 
//            display2.appendChild(p);
// });




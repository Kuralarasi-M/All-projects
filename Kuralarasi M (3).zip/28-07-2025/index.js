import createPrompt from 'prompt-sync';
 let prompt = createPrompt();
 let name = prompt("please enter first name:- ");
 console.log(name);
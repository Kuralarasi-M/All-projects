// for Add Task
document.querySelector("form").addEventListener("submit", async (e) => {
    e.preventDefault();
    
    let title=document.getElementById('title').value.trim();
    let description=document.getElementById('Description').value.trim()
    let prio=document.getElementById('Priority');
    let priority=String(prio.value);
    let createdDate=new Date();
    let isDone = document.querySelector('input[name="done"]:checked').value === "true";
     let h2=document.querySelector('h2');
    h2.classList.remove('up');
    let id = document.getElementById('taskId').value;
    console.log(isDone);
    let p=document.createElement('p');
    if(id){
    try {
        
        let res = await fetch(`http://localhost:5000/tasks/${id}`,{
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({title, description, priority, createdDate, isDone})
        });

        if(!res.ok) throw 'Task not found';
        let ress = await res.json();
        p.textContent = `Updated task ${id} successfully`;
        display1.appendChild(p).style.setProperty('text-align','center');;
    } catch(err) {
        p.textContent = err;
        display1.appendChild(p).style.setProperty('text-align','center');;
        console.log(err);
    }
    }

    else{
         try {
        let res = await fetch("http://localhost:5000/tasks", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ title, description, priority,createdDate,isDone})
        });
        let task=await res.json();
        console.log(task.id);
        
        getStore(task.id,title,description,priority,createdDate,isDone);
        
    } catch (err) {
        console.error("Error:", err);
    }
    }
 document.getElementById('taskId').value = "";
    e.target.reset();
    document.querySelector("form button[type='submit']").textContent = "Add Task";
   
});
/// for Show the task
let display=document.querySelector(".main");
let ul=document.createElement('table');
let showbtn=document.querySelector(".showbtn").addEventListener('click',async ()=>{
    display.innerHTML="";
    try{
       let data=await fetch("http://localhost:5000/tasks");
       let user=await data.json();
      
       user.forEach(user => {
          let ele=fun(user)
           
      });
    }
   catch(err){
    console.log(err);
    
   }
   
})
let display1=document.querySelector(".main");
function fun(user){
    let tr1=document.createElement('p');
    let tr2=document.createElement('p');
    let tr3=document.createElement('p');
    let tr4=document.createElement('p');
    let tr5=document.createElement('p');
    let tr6=document.createElement('p');
    let tr8=document.createElement('button'); 
    let tr9=document.createElement('button'); 
    
    let displaydiv=document.createElement('div');
    displaydiv.classList.add('boxing')
    tr1.textContent=`Id :${user.id} `;
    tr2.textContent=`Title :${user.title} `;
    tr3.textContent=`Description :${user.description}`;
    tr4.textContent=`priority:  ${user.priority} `;
    tr5.textContent=` isDone: ${user.isDone} `;
    tr6.textContent=`CreatedDate: ${user.createdDate} `;
    tr8.textContent=`Update`;
    tr8.type = 'button';
    tr9.textContent=`Delete`;
    tr9.type = 'button';
    tr8.setAttribute("data-id", user.id);
    tr9.setAttribute("data-id", user.id);
    tr8.setAttribute('type', 'button');
    tr9.setAttribute('type', 'button');

   displaydiv.appendChild(tr1);
    displaydiv.appendChild(tr2);
    displaydiv.appendChild(tr3);
    displaydiv.appendChild(tr4);
    displaydiv.appendChild(tr5);
    displaydiv.appendChild(tr6);
    displaydiv.appendChild(tr8);
    displaydiv.appendChild(tr9);
    
   
    display.appendChild(displaydiv);
    // Update task
    tr8.addEventListener('click', async (e)=>{
        e.preventDefault();
        e.stopPropagation();
        let value = e.target.getAttribute('data-id');
        sessionStorage.setItem("TaskId",value);
        display1.innerHTML="";
        let p=document.createElement('p');
        let h2=document.querySelector('h2');
        h2.classList.add('up');
        let task=await fetch(`http://localhost:5000/tasks/${value}`);
        let tasklist=await task.json();
        document.getElementById('title').value=tasklist.title;
        document.getElementById('Description').value=tasklist.description;
        document.getElementById('Priority').value=tasklist.priority;
        document.querySelector(`input[name="done"][value="${tasklist.isDone}"]`).checked = true;
        document.getElementById('taskId').value = value;
        document.querySelector("form button[type='submit']").textContent = "Update Task";
        
    });

    // task Deletion
    tr9.addEventListener('click', async (e)=>{
        e.preventDefault();
        let p=document.createElement('p');
        display1.innerHTML="";
        let value = e.target.getAttribute('data-id');
        await fetch(`http://localhost:5000/tasks/${value}`,{
            method: "DELETE"
        })
        .then((res)=>{
            if(!res.ok) throw `Task(${value}) not found`;
            p.textContent=`Task(${value}) deleted`;
            display1.appendChild(p).style.setProperty('text-align','center');
        })
        .catch((err)=>{
             p.textContent=err;
            display1.appendChild(p).style.setProperty('text-align','center');;
        });
        
    });

   
}

function getStore(id,title,description,priority,createdDate,isDone){
         localStorage.clear();
         console.log("Local storage");
         
        localStorage.setItem("Id",id);
        localStorage.setItem("Title",title);
         localStorage.setItem("Description",description);
        localStorage.setItem("Priority",priority);
         localStorage.setItem("isDone",isDone);
        localStorage.setItem("CreatedDate",createdDate);
        
}    


 let display2 = document.querySelector('.main');
let search=document.querySelector(".searchbtn").addEventListener("click",async ()=>{
    display2.innerHTML="";
    let value=document.querySelector('.search').value.trim().toLowerCase();
    console.log(value);
    
    let list=await fetch(`http://localhost:5000/tasks`);
    let userlist=await list.json();
   
   
    let filteruser= userlist.filter((val)=> val.title.toLowerCase().includes(value) || 
    String(val.id).toLowerCase().includes(value))
    
    
    filteruser.forEach(user=>{
        console.log(user);
        
            fun(user)

        }
        
    )
    
    
    
});




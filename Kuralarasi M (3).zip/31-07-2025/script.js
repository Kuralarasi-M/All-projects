// Set
let arr=new Array(1,2,"45",true,1,2);
console.log(arr);
let set3=new Set();
set3.add("3");
set3.add("90");
set3.add("100");
let set1=new Set(['3',"90",67,"kural"]);
set1.add("3");
set1.add("90");
set1.add("100");
set1.add(100);
console.log(set1 instanceof Set);
console.log(set1);
let set2=new Set([...arr]);
console.log(arr);
console.log(set2);
let i=0;
for(let i=0;i<10;i++){
    console.log(i);
    
}
console.log(set1);
set1.delete('90');
set1.delete(100);
console.log(set1);
set1.forEach(function(value){
    console.log(value);
    
})
let wset=new WeakSet();
let obj={name:'kural'};
wset.add(obj);
console.log(wset.has(obj));
console.log(wset.delete(obj));
console.log(wset.has(obj));
function sum(...nums) {
    
  return nums.reduce((total, n) => {
    console.log(total +"  "+n);
    
    return total + n, 0} );
}

console.log(sum(1, 2, 3, 4));  

function sq(x){
    return x*x;
}
console.log(sq(8));
let upper=function(x){
    return x.toUpperCase();
}
console.log(upper("hello world"));
// let evenOrOdd = (x) =>{
//      if (x%2==0)
//         return "Even";
     
//     return "Odd";
        
// }
let evenOrOdd= (x) => x%2==0 ? "Even" :"Odd";
console.log(evenOrOdd(22));
// let maxTwo= function (...nums){
//     let max1=nums[0],max2=nums[1];
//     for(let x of nums){
//         if(x>max1){
//             max2=max1;
//             max1=x;
            
//         }
       
//     }
//      return "max1: "+max1+" max2: "+max2;
   
// }
let maxTwo = (...nums) => {
    nums.sort((a, b) => b - a);
    return `max1: ${nums[0]} max2: ${nums[1]}`;
};

console.log(maxTwo(23,4,5,6,7,25));
let num1=new Array(23,4,5,6,7,25);


num1.sort((a,b)=>b-a);
console.log(num1);


let sent= function (name,age){
     return `Hi, my name is ${name} and I'm ${age} years old.`
   
}
console.log(sent('kural',21));
function total(...x){
    let tot=0;
    for(let i of x){
        tot+=i;
    }
    return tot;
}
console.log(total(2,45,55,22,33,90));
function rev(a){
    return a.split('').reverse().join('');
}
console.log(rev("hello world"));
function Evennum(...x){
    let tot=new Array();
    for(let i of x){
        if(i%2==0){
            tot.push(i);
        }
    }
    return tot;
}
console.log(Evennum(32,8,46,100,8,9,7,5));
function vowel(a){
    let num=0;
    a.toLowerCase();
    let arr=a.split('');
    
    pattern=/^[aeiou]$/;
    for(let i of arr){
        if(pattern.test(i)){
            num++;
        }
    }
    return num
}
console.log(vowel("hello world"));
console.log(Object.entries(num1));

let str="hello there this is kural";
console.log(str.split(' '));
console.log(str.at(-1));


const words = ["ant", "ant", "ant", "ball", "cat", "dog", "dog"]; 
let word=new Set(words);
let words1=new Array(...word);
console.log(words1);
let sentence1 = "I am at Gislen Software";
let matches1=sentence1.match(/[aeiou]/gi);
console.log(matches1.length);
let co=0;
let patt=/^[A-Za-z]$/;
for(i=0;i<sentence1.length;i++){
    if(patt.test(sentence1.charAt(i))){
        co++;
    }
   
}



const words2 = ["apple", "ball", "angle", "bill", "cat", "dog", "eat", "ant"];
for(let i=0;i<words2.length;i++){
    let word=words2[i];
    words2[i]=word.charAt(0).toUpperCase()+word.slice(1);

    
    
}


console.log(words2);
let sentence = "I am at Gislen Software";
let matches=sentence.match(/[aeiou]/gi);
console.log(matches);

const users = [
        { name: "Alice", active: true },
        { name: "Bob", active: false },
        { name: "Carol", active: true }
];

let ans=[];
for(let x of users){
    let word=x;
    if(x.active==true){
        ans.push(x.name);
    }
}
console.log(ans);
let answer =users.filter(x => x.active).map(x => x.name)
console.log(answer);

 


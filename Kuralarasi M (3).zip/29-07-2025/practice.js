//array

let arr=new Array(22,33,44,55);
console.log(arr);
let str='hello';
console.log('hello');
console.log(str.length);
console.log('hi');
console.log(arr.shift());
arr.pop();
arr.unshift(90);
console.log(arr);
console.log(str.slice(-4,-1));
let arr1=arr.slice(1);
let array=[23,45,66,77];
array.splice(1,1,66,100,`100`);
console.log(arr1.toString());
console.log(array);
let array1=array.toSpliced(3,1);
console.log(array1);
const fruits = ["Banana", "Orange", "Lemon", "Apple", "Mango"];
const citrus = fruits.slice(3);





// import createPrompt from 'prompt-sync';
//  let prompt = createPrompt();
//  let email = prompt("please enter mailId:- ");
//  let password = prompt("please password:- ");


// import createPrompt from 'prompt-sync';
// const prompt=createPrompt();
// let email=prompt("enter mailid");
// let password=prompt("enter password");
// const emailpattern=/^[a-zA-Z0-9%_=-]+@[A-Za-z]+\.[A-Za-z]{2,}$/;
// const pw=/^[a-zA-Z0-9]{4,}$/;
// if(emailpattern.test(email) && pw.test(password)){
//     console.log('right');
// }
// else{
//     console.log('mismatch');
// }
let num=[22,44,66,777];
let high=num.findLast(x => x>40);
console.log(high);

let hello=new Map();
hello.set('cat',33);
hello.set('dog',33);
hello.set('rabbit',33);
hello.set('lion',33);

console.log(hello);
console.log(hello.keys());
const contacts = new Map();
contacts.set("Jessie", { phone: "213-555-1234", address: "123 N 1st Ave" });
contacts.has("Jessie"); // true
contacts.get("Hilary"); // undefined
contacts.set("Hilary", { phone: "617-555-4321", address: "321 S 2nd St" });
contacts.get("Jessie"); // {phone: "213-555-1234", address: "123 N 1st Ave"}
contacts.delete("Raymond"); // false
contacts.delete("Jessie"); // true
console.log(contacts.size); // 1
console.log(contacts);
let setarr=new Set();
setarr.add(10);
setarr.add(45);
setarr.add(45);
setarr.add(4);
setarr.add(5);
setarr.add(9);
setarr.add(90);
console.log(setarr);
let today=new Date();
const d = new Date(2025, 11, 31);
d.setDate(d.getDate() + 1);
console.log(d.toDateString());
let amount=2000000;
let tt=Intl.NumberFormat('en-US',{
    style:'currency',
    currency:'USD'
});
let amt=tt.format(amount);
console.log(amt);

let obj={
    bookName:'HaaryPotter',
    author:'JKRowling',
    year:1997,
    fun:function(){
        return `bookName : ${this.bookName} ,author : ${this.author} ,year : ${this.year}`;
    }
}
// console.log(obj.fun());
let obj1={
    bookName:'HarryPotter',
    author:'JKRowling',
    year:1997
}
let jsonobj=JSON.stringify(obj1);

let obj2=JSON.parse(jsonobj);
console.log(jsonobj);
console.log(obj2);

const str1 = "5" + 1 - 1;
console.log(str1);  // ?
let input="hello world"
let reversed = input.split('').reverse().join('');
console.log(reversed);  

let num1=1234567.89;
console.log(num1.toLocaleString());

let tday=new Date("2025-07-30");


console.log(tday.toLocaleDateString('en-GB', {
  day: '2-digit',
  month: 'short',
  year: 'numeric'
}));

// import createPrompt from 'prompt-sync';
// const prompt=createPrompt();
// let userdate=prompt('enter your DOB');
// let DOB=new Date(userdate);
// console.log(DOB);
// let today1=new Date();
// console.log(today1);

// let diffwe=(today1-DOB);
// console.log(diffwe);

// console.log("remaining date   "+
//     diffwe/(1000*60*60*24));
// let diff=Math.floor(diffwe/(365.25*1000*60*60*24));
// console.log(diff);

let pat=/^(?=(?:.*[A-Z]){2,})(?=(?:.*[a-z]){2,})(?=(?:.*\d){2,}).{6,}$/;

let ans="KUio200000";
if(pat.test(ans)){
    console.log('right');
    
}
else{
    console.log('wrong');
}



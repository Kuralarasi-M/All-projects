console.log(process.argv);

console.log(process.argv.slice(2));

const temp = process.argv.slice(2)
console.log(temp[2]);
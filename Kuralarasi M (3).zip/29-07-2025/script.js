console.log('Learning JavaScript');
let course="JavaScript Basics";
console.log(course);
let x,y,z;
x=12;
y=12;

//variables type
console.log(z);
let a;
let b=null;
let book=true;
console.log(typeof course);
console.log(typeof x);
console.log(typeof a);
console.log(typeof b);
console.log(typeof book);
let score = 0;

// string Interpolation and templete literals
let firstName='kuralarasi';
let lastName='manivannan';
let name=`my name is ${firstName} ${lastName}`;
console.log(name);
console.log(name.length);
let isLoggedIn=true;
if(isLoggedIn){
    console.log('welcome back!');
}
else{
    console.log('Please Log in')
}
let marks1=90;
let marks2=80;
let Average=(marks1+marks2)/2;
let Total=(marks1+marks2);
console.log(`Average:${Average}`);
console.log('Total:'+Total);

// undefined and null

let m;
let n=null;
console.log(m + " "+typeof m);
console.log(n  + " "+typeof n);
console.log(m==n);
console.log(m===n);


// object 

let object1={brand:'Toyato',model:'Innovo',year:21}
console.log(object1['brand']+" "+object1['model']+" "+object1['year']);
console.log(object1.brand);

//dates

let today=new Date();
console.log('Today'+" "+today);
console.log(today.getFullYear());
console.log(today.getMonth());
console.log(today.getDay());
console.log(today.getUTCDate());

let nextDay=new Date(today);
nextDay.setDate(today.getDate()+1);
console.log(nextDay);
let DOB=new Date('2003-09-02');
let diff=(today-DOB);
let totaldays=diff/(24*60*60*1000);
console.log(Math.floor(totaldays));
let age=Math.floor(totaldays/365.25);
console.log(age);
console.log(today.toDateString());
let Daysleft=new Date('2025-09-02');
let df=Math.round(Daysleft-today);
console.log(Math.round(df/(24*60*60*1000)));
let next=new Date(today);
next.setDate(today.getDate()+35);
console.log(next);

// Regex 

let email=/^[A-Za-z0-9_%-]+@[A-Za-z]+\.[a-zA-Z]{2,}$/;
let einput="kural%123@maco.ua"
if (einput.match(email)){
    console.log('correct');
}
else{
    console.log('wrong');
}
if(-0){
    console.log('truthy');
}
else{
    console.log('falsy');
}

// Form Validation

function validateForm(){
    let  error="";
    let nameerror="";
    let name=document.getElementById('name').value.trim();
    let Email=document.getElementById('email').value.trim();
    if(name===""){
        nameerror="Name is Required";
    }
    else if(!Email.match(email)){
        error="enter correct format";
    }
    if(nameerror!==""){
        document.getElementById('nameerror').innerText=nameerror;
    }
    else{
         document.getElementById('nameerror').innerText="";
    }
    if(error!=="" ){
        document.getElementById('error').innerText=error;
       
    }
    else{
        document.getElementById('error').innerText=error;
       
    }
   
    if (nameerror==" " && error==" ")
          return true;
    else{
        return false;
    }
}
 
// type coercion 

const value1 = "5";
const value2 = 9;
let sum = value1 + value2;
sum = Number(value1) + value2;

console.log(sum);


// number format ting


let amount=3000;

let numformat=new Intl.NumberFormat('en-US',{
    style:'currency',
    currency:'USD'
})
let numformat1=new Intl.NumberFormat('en-IN',{
    style:'currency',
    currency:'INR'
})
let curamt=numformat.format(amount);
console.log(curamt);
let curamt1=numformat1.format(amount);
console.log(curamt1);
let numfor=amount.toLocaleString();
console.log(numfor);
console.log(amount);
let amount1=300000.9876;
console.log(amount1.toFixed(2));

// switch statement
let Today=new Date();
let currentDay=Today.getUTCDay();
console.log(currentDay);
switch(currentDay){
    case 0:
        console.log('sunday');
        break;
    case 1:
        console.log('monday');
        break;
    case 2:
        console.log('tuesday');
        break;
    case 3:
        console.log('wednesday');
        break;
    case 4:
        console.log('thursday');
        break;
    case 5:
        console.log('friday');
        break;
    case 6:
        console.log('saturday');
        break;
    
}

// Object

let object2={firstName:"kural",lastname:"manivannan",age:21,eyecolor:'black',fun:function(){
    return this.firstName+" "+this.lastname+" "+this.age+" "+this.eyecolor;
}};
console.log(object2.lastname);
object2.age=22;
console.log(object2.age);
delete object2.age;
console.log(object2['age']);
console.log(object2.fun());
let  text="";
for(let x in object2){
    text+=object2[x]+" ";
}
console.log(text);
let array=Object.values(object2);
console.log(array);
let text1="";
for(let [x,y] of Object.entries(object2)){
     text1+=x+":"+y+" ";
}
console.log(text1);
let object3=JSON.stringify(object2);
console.log(object3);

// Arrays 

let array1 =new Array(23,44,66,88);
console.log(array1);
console.log(typeof array1);
let array2=['hello','world','!',0.5];
console.log(array2);
for(let i=0;i<array2.length;i++){
    console.log(array2[i]+" ");
}

// Array Methods
array1=array1.concat('12','13','12');
console.log(array1);
console.log(array2);
array1.push('444');
array1.shift();
console.log(array1);







 



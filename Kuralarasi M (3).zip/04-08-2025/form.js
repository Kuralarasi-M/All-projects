



document.querySelector("form").addEventListener("submit", async (e) => {
    e.preventDefault();

    let name = document.querySelector('.name').value.trim();
    let email = document.querySelector('.email').value.trim();
    let password = document.querySelector('.password').value.trim();

    try {
        let res = await fetch("http://localhost:3000/users", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, password })
        });

       

    } catch (err) {
        console.error("Error:", err);
    }
});
async function userdetails(){
  try{
    let data=await fetch("http://localhost:3000/users");
    let user=await data.json();
    console.log(user);
    
  }
   catch(err){
    console.log(err);
    
   }

}
userdetails();
let para = document.querySelector('.para');
document.querySelector('.userbtn').addEventListener("click",async ()=>{
    para.innerHTML = "";
    try {
    let ulist = await fetch('http://localhost:3000/users');
    let details = await ulist.json();

    let ul = document.createElement("ul"); 

    details.forEach(user => {
        let li = document.createElement("li"); 
        li.textContent = `${user.name} - ${user.email}`;
        ul.appendChild(li); 
    });

    para.appendChild(ul); 
    } 
    catch (err) {
         console.log(err);
    }
});
let para1 = document.querySelector('.para');

let search=document.querySelector(".searchbtn").addEventListener("click",async ()=>{
    para1.innerHTML="";
    let value=document.querySelector('.data').value.trim().toLowerCase();
    let list=await fetch("http://localhost:3000/users");
    let userlist=await list.json();
    let ul=document.createElement('ul')
   
    let filteruser= userlist.filter((val)=> val.email.toLowerCase().includes(value) ||  val.name.toLowerCase().includes(value) || 
    String(val.id).toLowerCase().includes(value))
    
    
    filteruser.forEach(user=>{
          let li=document.createElement('li');
            li.textContent=`${user.name}- ${user.email}` ;
            ul.appendChild(li);
        }
        
    )
    para1.appendChild(ul);
    
    
});

let updatebtn=document.querySelector('.updatebtn').addEventListener('click',()=>{
    let update=document.querySelector('.update').value.toLowerCase().trim();
    para.innerHTML="";

    let email=prompt("get the email");
      let name=prompt("get the name");
      let username=document.createElement('p');
    fetch(`http://localhost:3000/users/${update}`,{
        method:"PATCH",
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify({name:name,email:email})
        
        
    })
    .then((res)=>{
        if(!res.ok){
            throw 'user is not found'
        }
        else {
            username.textContent=`updated ${update}`;
            para.appendChild(username);
        }
             
    })
    .then((ans)=>{
    
         username.textContent=`updated ${update}`;
            para.appendChild(username);
    })
    .catch((err)=>{
        username.textContent=`the user is not found`;
            para.appendChild(username);
        
    })
});
let para2 = document.querySelector('.para');
let deletebtn=document.querySelector('.deletebtn').addEventListener('click',(event)=>{
      event.preventDefault();
    let del=document.querySelector('.delete').value.toLowerCase().trim();
    para2.innerHTML="";
    let p=document.createElement('p');
    fetch(`http://localhost:3000/users/${del}`,{
        method:"DELETE"
    })
    .then((res)=>{
        if(res.ok){
          p.textContent=`User(${del}) Deleted Successfully.`
          para2.appendChild(p);
        }
        else{
            throw `User(${del})  is not found`
        }
   
    })
    .catch((err)=>{
        p.textContent=err;
        para2.appendChild(p);
    });
});
   
localStorage.setItem("username","kural");

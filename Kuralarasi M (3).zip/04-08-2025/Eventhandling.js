
let btn=document.getElementById('clickbtn');
btn.addEventListener("click", function(e) {
  console.log(e.type, e.target, e.clientX, e.clientY);
});
let paragraph=document.getElementById('para');
paragraph.addEventListener("mouseover",(e)=>{
     console.log(e.type);
     
});
document.addEventListener("keydown",(e)=>{
    console.log(e.key);
    
})
// document.addEventListener("keyup", (e) => {
//     console.log(e.key);
// });

document.getElementById("name").addEventListener("change", function() {
    console.log("Value changed to:", this.value);
});

document.querySelector('.box').addEventListener("focus",(e)=>{
    console.log("box is focused");
    
});
let inputs = document.querySelectorAll("input");

inputs.forEach(input => {
            
        input.addEventListener("input", () => {
        
        input.style.backgroundColor = "red";
    });
    input.addEventListener("blur", () => {
   
    input.style.backgroundColor = "";
    });
});

document.querySelector('.password').addEventListener("input",(e)=>{
    let input1=document.querySelector('.password').value;
    console.log(input1);
    
})

document.querySelector(".box1").addEventListener("click",()=>{
    console.log("parent is clicked");
    
});
document.querySelector(".box2").addEventListener("click",()=>{
    console.log("child is clicked");
    
});
document.querySelector(".btn1").addEventListener("click",()=>{
   window.scrollTo({ top: 0, behavior: "smooth" });


})  
 document.addEventListener("DOMContentLoaded", () => {
            console.log("DOM fully loaded!");
            document.getElementById("title").textContent = "Page is Ready!";
});
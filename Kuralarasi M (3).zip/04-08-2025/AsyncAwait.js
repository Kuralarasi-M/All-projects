

// async function user(){
//   try{
//      let userdate=await fetch("http://localhost:5000/users");
//     let data= await userdate.json();
//     console.log(data);
//   }
//    catch(err){
//         console.log(err);
        
//    } 
    
// }

// user();




// async function getJoke() {
//     try {
//         let res = await fetch("https://official-joke-api.appspot.com/random_joke");
//         let data = await res.json();
//         console.log(data);
//     } catch (err) {
//         console.log(err);
//     }
// }
// getJoke();



// async function createUser(){
//     try{
//        const  use=await fetch("http://localhost:5000/users",{
//            method:"POST",
//            headers:{
//                "Content-Type":"Application/json"
//            },
//            body:JSON.stringify({name:"Harry",email:'harry@gmail.com'})
//        });
//        const data=await use.json();
//       console.log(data);
      
//     }
//     catch(err){
//       console.log(err);
      
//     }
// }
// createUser();

// async function user(){
//   try{
//      let usersdata=await fetch("http://localhost:5000/users/2137",{
//        method:'PUT',
//        headers:{
//           'Content-Type':"Application/json"
//        },
//        body: JSON.stringify({name:"Ron",email:"ron@gmail.com"})

//     });
//     console.log(usersdata.json());
    
    
//   }
//    catch(err){
//        console.log(err);
       
//    } 
// }
// user();


// async function userdetails(){
//   try{
//       let data=await fetch("http://localhost:5000/users");
//     let user=await data.json();
//      let value="emma";
     
     
//     let filteruser= user.filter((val)=> val.email.toLowerCase().includes(value) ||  val.name.toLowerCase().includes(value) || 
//      String(val.id).toLowerCase().includes(value))
    
//      console.log(filteruser);

    
     
//   }
//    catch(err){
//     console.log(err);
    
//    }

// }
// userdetails();
// console.log("heellooo");

// async function userdet(){
//      try{
//       let value='kural';
//       let user1=await fetch('http://localhost:3000/users');
//        let userli=await user1.json();
      
       
//        let userlist=userli.filter((user)=>
//          user.name.toLowerCase().includes(value.toLowerCase()) || 
//          user.email.toLowerCase().includes(value.toLowerCase()) || 
//         String(user.id).toLowerCase().includes(value.toLowerCase()));
//         console.log(userlist) ;
//      }
//      catch(err){
//       console.log(err);
      
//      }
// }
// userdet();
// let id="b76f";
// fetch(`http://localhost:3000/users/${id}`, {
//     method: "DELETE"
// })
// .then(res => {
//     if (!res.ok) {
//         throw new Error("Failed to delete");
//     }
//     console.log("Deleted successfully");
// })
// .catch(err => console.error(err));

let id=1;
fetch(`http://localhost:3000/users/${id}`, {
    method: "PATCH",
    headers: {
        "Content-Type": "application/json"
    },
    body: JSON.stringify({
        name: "alice"
    })
})
.then(res => res.json())
.then(data => console.log("Partially Updated:", data))
.catch(err => console.error(err));

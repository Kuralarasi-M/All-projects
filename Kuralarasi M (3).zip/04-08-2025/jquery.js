import { createElement } from "react";

$(document).ready(function(){
     $('p').click(function(){
       $(this).hide();
     })
     $('div').on('dblclick',function(){
       $(this).append("hiii there").toggle()
     })
     $('p.para').mouseenter(function(){
         $(this).fadeIn(2000);
     })
     $('p.para').mouseout(function(){
      $(this).fadeOut(2000)
     })
     
});



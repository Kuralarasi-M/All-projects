const fruits = new Map();

fruits.set("apples", 500);
fruits.set("bananas", 300);
fruits.set("oranges", 200);
console.log(fruits);
console.log(fruits.get('bananas'));
let detail=new Map([["oranges",500],
    ["mangos",200],
    ["grapes",100]
]);
console.log(detail);
console.log(detail.size);
console.log(detail.delete('oranges'));
console.log(detail);
console.log(detail.clear());

let details=new Map([["oranges",500],
    ["mangos",200],
    ["grapes",100]
]);
console.log(details);
console.log(detail);
console.log(details.has('orang'));
let text;
details.forEach(function(value,key)  {
    text+=" "+key+":"+value+" ";
});
console.log(detail.size);
console.log(details.delete('oranges'));
console.log(text);
console.log(details);


// entries

for(let x of details.entries()){
    console.log(x);
}
console.log(details.entries());
console.log(details.keys());
console.log(details.values());

for(let x of details.keys()){
    console.log(x);
}
for(let x of details.values()){
    console.log(x);
}
let students = new Map([
    ["kural",434],
    ["TD",480],
    ["Kaviya",400]
])
console.log(students.get('Kaviya'));
console.log(students.has('kural'));
let high=0,key="";
for(let x of students.keys()){
    if(students.get(x)>high){
        high=students.get(x);
        key=x;
    }
         
    
}
console.log(key+":"+high);
students.set("md",410);
console.log(students.entries());
students.delete("md");
console.log(students);


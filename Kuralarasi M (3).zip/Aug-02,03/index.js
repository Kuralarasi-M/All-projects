const jsdom = require('jsdom');
const { JSDOM } = jsdom;
const { window } = new JSDOM(`<!DOCTYPE html><p>Hello World</p>`);
const $ = require('jquery')(window);

$('p').text('Hello from jQuery in Node.js!');
console.log($('p').text()); // Output: Hello from jQuery in Node.js!


async function getData() {
    const user = await fetch('https://alexwohlbruck.github.io/cat-facts/').then(res => res.json());
    const orders = await fetch('https://kinduff.github.io/dog-api/').then(res => res.json());
    console.log(user, orders);
}
getData();
setTimeout(()=>{
    console.log("1..Hello");
},4000)
setTimeout(()=>{
    console.log("2..Hi");
},3000)
setTimeout(()=>{
    
console.log("3..Hi there");
},1000)


let fun=new  Promise((resolve,reject)=>{
    let reached=true;
    if(reached){
        resolve("hi there i am reached");
    }
    else{
        reject("hi there i am on the way");
    }
})
fun.then((msg)=>{
    console.log(msg);
    
})
.catch((msg)=>{
    console.log(msg);
    
})
function tripplan(){
    return    new Promise((resolve,reject)=>{
        let planaction=true;
        if(planaction){
            resolve("Plan Executed Successfully");
        }
        else{
            reject("Try Again");
        }
    })
}
tripplan().then((msg)=>{
    console.log(msg);
})
.catch((msg)=>{
    console.log(msg);
    
})
   
async function tripplan1(){
    try{
      result =await tripplan();
      console.log(result+" with asyn and await");
      
    }
    catch(err){
       console.log(err);
       
    }

}
// tripplan1();

// fetch("https://dogapi.dog/api/v2/facts")
// .then((res)=> res.json())
// .then((exm)=>{
//     console.log(exm)})
// .then((ans)=>console.log(ans)
// )
async function getDogFact() {
  try {
    const res = await fetch("https://dogapi.dog/api/v2/facts");
    const data = await res.json();
    console.log(data.data[0].attributes.body); // Fact text
  } catch (err) {
    console.error("Error fetching fact:", err);
  }
}

getDogFact();

fetch("https://jsonplaceholder.typicode.com/users/1")
.then ((res)=>res.json())
.then ((ans)=>{
    console.log(ans);
    
})
function hello(){
    return new Promise((resolve,reject)=>{
        let plan=true;
        if(plan){
            resolve('Success we meet in dreamland');
        }
        else{
            reject('we meet some other time');
        }
    })
}
hello().then((res)=>{
    console.log(res);
    
})
.catch((ans)=>{
    console.log(ans);
    
});

async function hi(){
    let helloworld= new Promise((resolve,reject)=>{
       let plan=true;
       if(plan){
          resolve("hello everything going well");
       }
       else{
        reject("we will fix it.")
       }
        
    })
    let fun=await helloworld .then((msg)=>{
        console.log(msg);
        
    })
    .catch((ans)=>{
        console.log(ans);
        
    })
}

setTimeout(async ()=>{
    await console.log(hello());
    
},5000);


const form=document.getElementById('form');
const name=document.getElementById('name');
const email=document.getElementById('email');
const password=document.getElementById('password');
const cpassword=document.getElementById('cpassword');

form.addEventListener('submit',(e)=>{
    if(!validateinput()){
        e.preventDefault();
    }
    else{
        localStorage.setItem('name', name.value.trim());
        localStorage.setItem('email', email.value.trim());

        // Save in session storage
        sessionStorage.setItem('name', name.value.trim());
        sessionStorage.setItem('email', email.value.trim());

        alert("Form submitted and data saved!");
    }
});
function validateinput(){
    let patt=/^[A-Za-z]+$/;
    let mail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    
    const fullname=name.value.trim();
    const emailId=email.value.trim();
    const pass=password.value.trim();
    const cpass=cpassword.value.trim();
    let successin=true;
    if(fullname===""){
        seterror(name,"userName is required")  ;
        successin=false;
    }
    else if(!patt.test(fullname)){
        seterror(name,"Please enter correct name");
         successin=false;
    }
    else{
        setsuccess(name)
    }
    if(emailId===""){
        seterror(email,"emailId is required")  ;
         successin=false;
    }
    else if(!mail.test(emailId)){
        seterror(email,"Please enter correct ");
         successin=false;
    }
    else{
        setsuccess(email)
    }
     if(pass===""){
        seterror(password,"password is required")  ;
         successin=false;
    }
    else if(pass.length<6){
        seterror(password,"Please enter atleast 6 characters");
         successin=false;
    }
   
    else{
        setsuccess(password)
    }
     if(cpass===""){
        seterror(cpassword,"password is required")  ;
         successin=false;
    }
    else if(cpass.length<6){
        seterror(cpassword,"Please enter atleast 6 characters");
         successin=false;
    }
     else if(pass!==cpass){
        seterror(cpassword,"Please enter same password ");
         successin=false;
    }
    else{
        setsuccess(cpassword);
    }
    return successin;
  
}

function  seterror(element,error){
     const inputg=element.parentElement;
     const errorEle=inputg.querySelector('.error');
     errorEle.innerText=error;
    inputg.classList.add('error')
    inputg.classList.remove('success')
}
function  setsuccess(element){
     const inputg=element.parentElement;
     const errorEle=inputg.querySelector('.error');
     errorEle.innerText="";
    inputg.classList.add('success')
    inputg.classList.remove('error')
}

// "username=John; theme=dark"

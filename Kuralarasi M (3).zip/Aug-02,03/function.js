async function getData() {
    const cat = await fetch('https://catfact.ninja/fact').then(r => r.json());
    const joke = await fetch('https://official-joke-api.appspot.com/random_joke').then(r => r.json());
    console.log(cat, joke);
}
getData();

async function fetchData() {
    try {
        const [user, posts, comments] = await Promise.all([
            fetch('http://localhost:5000/users').then(r => r.json()),
            fetch('http://localhost:5000/orders').then(r => r.json()),
            fetch('http://localhost:5000/products').then(r => r.json())
        ]);
        console.log(user, posts, comments);
    } catch (error) {
        console.error("One of the promises failed", error);
    }
}
fetchData();

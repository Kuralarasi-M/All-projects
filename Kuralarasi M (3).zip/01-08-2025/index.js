// let typing=document.getElementById('name');
// let par=document.getElementById("err");
// typing.addEventListener('input',()=>{
//     let con=typing.value;
//     par.innerHTML=con;
// })
// let box1=document.getElementById("box");
// box1.addEventListener('click',()=>{
//     alert("you clicked the box");
    
// });
// let sub1=document.getElementById("sub");
// sub1.addEventListener('submit', x=>{
//     x.preventDefault(); 
// })




let mypromise=new Promise((resolve,reject) => {
    let action=true;
    if(action){
       resolve("Successfully Done!");
    }
    else{
       reject("Nice Try!");
    }
});
mypromise 
.then(res => {
    console.log(res);
})
.catch(res=>{
    console.log(res);
})
.finally(()=>{
    console.log("All the best.");
    
});
// let btn1=document.getElementById("btn");
// btn1.addEventListener("click", ()=>{
//     document.getElementById("para").innerHTML="the button is Clicked";
// })
// btn1.removeEventListener("click", ()=>{
//     document.getElementById("para").innerHTML="";
// })


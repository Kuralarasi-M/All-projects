let fun=function(){
    console.log ("Hello World!");
}
fun();
let fun1=function(name){
     return ("Hello "+name);
}
console.log(fun1("kural"));

//1
const numbers = [1, 2, 3, 4, 5, 6];

let even = numbers.filter( x => x%2==0) ;
console.log(even);
//2
const names = ["Alice", "Bob", "adam", "Steve", "Annie"];
let name = names.filter(x => x.charAt(0)=='A' || x.charAt(0)=='a')
console.log(name);
let stu="kaviya";
//3
const students = [
  { name: "Asha", score: 90 },
  { name: "Kiran", score: 35 },
  { name: "Maya", score: 70 }
];

let student=students.filter(x => x.score >=40)
console.log(student);
//4
const items = ["Hello", "", 0, null, "World", undefined, false];
let item=items.filter(x => Boolean(x))
console.log(item);
//5
const nums = [1, 2, 2, 3, 4, 4, 5];
const num=new Set(nums);
console.log(num);

setTimeout(() => {
  console.log("Hello Kural! Happy Coding!.");
  
},2000);
//recursion
//1
let num1=4321;
function sum(x){
  if(x==0)
      return 0;
  return x%10+sum(Math.floor(x/10));
}
console.log(sum(num1));
//2 
let c=0;
function digit(num){
   
   if(num==0){
      return 0;
   }
   
   return 1+digit(Math.floor(num/10));
}
console.log(digit(1234));
function pow(num,power){
   if(power==0){
      return 1;
   }
  
   
   return num * pow(num,power-1);
}

console.log(pow(2,5));

function rev(num){
  if(num==0){
     return 0;
  }
  console.log((num%10)*10);
  
  return num*10+(num%10)+ rev(Math.floor(num/10));
}
console.log(rev(234));


(function (a,b) {
	console.log(a+b);
})(10,29);



function HOF(name,clb){
  console.log(`i am ${name}`);
  clb();

}
function clb(){
     
}

 HOF("kural",clb) ;

// import createPrompt from "prompt-sync";
// let prompt=createPrompt();
// let name1=prompt("Enter your name: ");
// console.log("Hello "+name1);

function outer() {
  let name = "dhivya";

  function inner() {
    console.log("Hello " + name);
  }

  return inner;
}

const greet = outer(); // outer() runs, inner() returned
greet();               // still remembers "name" → prints Hello Kural

let student2= {
  
   age:23,
   location:"chennai",
 
  };
console.log(student2);
console.log(this);
// 1
let num3=[34,55,77,88,9,23];
let dou=num3.map(x => x*x);
console.log(dou);
//2 
let eve=num3.filter(x => x%2==0)
console.log(eve);

//3
function  applyOp(x,y){
  console.log("hello");
  
   return `add: ${x+y} sub: ${x-y}`

}
function op(callback){
    let x=10 ,y=5;
    return callback(x,y);
}
console.log(op(applyOp));


function digitcount(num){
   if (num==0){
      return 0;
   }
   return num%10+digitcount(Math.floor(num/10));
}
console.log(digitcount(123));

let tarray=[1, [2, [3, 4], 5], 6];
function flatarray(){
    
}
function numpower(x,y){
      if(y==0){
        return 1;
      }
      console.log(x*x );
      
      return x * numpower(x,y-1);
}
console.log(numpower(2,5));

import createPrompt from 'prompt-sync';
const prompt=createPrompt();
let input=prompt("Enter Your DOB: ");
let DOB=new Date(input);
let Today=new Date();
let diff=(Today-DOB)/(24*60*60*1000*365.25);
let Age=Math.floor(diff);
if(isNaN(Age)){
   console.log("Please Enter Valid Date");
}
else{
    console.log(Age);
}


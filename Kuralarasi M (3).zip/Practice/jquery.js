// $("#filterBtn").on("click", () => {
//   const selected = $("#prioritySelect").val(); // dropdown with values High, Medium, Low

//   $.get(`http://localhost:3000/tasks?priority=${selected}`, function (data) {
//     $(".box").empty();
//     data.forEach(task => {
//       $(".box").append(`<p>${task.title} - ${task.priority}</p>`);
//     });
//   });
// });



$(document).ready(function(){
    // $('p').click(function(){
    //     $('p').toggle(4000);
    // })
    // $('p.para').click(function(){
    //     $('p.para').fadeIn()
    // })
 
    // $('.box').click(function(){
    //     $(this).animate({
    //         left:'+200px',
    //         Height:'+200px',
    //         width:'+200px',
            
    //     })
    // })
    //  $('.box1').click(function(){
    //     $('span').slideToggle({
             
    //     });
    // })
    // $('#btn').click(function(){
    //     $('.para').text('kural')
    // })
    // $('#btn1').click(function(){
    //    $('.box1').text('kural');
    // })
    //  $('#btn2').click(function(){
    //    $('section,main,article').toggleClass("coloring");
    // })
    
    // $('.p1').css("color","blue");
    
    //  $.get("http://localhost:5000/tasks",function(data){
    //     $('.box').empty();
    //         data.forEach(task=> {
                
    //             $('.box').append(`<p>taskid:${task.id}-task-title${task.title}</p>`);

    //         });
            
    //  })
     
    //  fetch("http://localhost:5000/Quotes",{
    //     method:"POST",
    //     headers:{
    //         "content-Type":"application/json"
    //     },
    //     body:JSON.stringify({title,Description,})
    //  }).then((res)=>{
    //     let ans=res.json();
    //     ans.forEach((i)=>{
    //         console.log(`<p>Quote:${i.quote}</p>`);
    //         console.log(`<p>:${i.author}</p>`);
    //     })
    //     if(!res.ok) return;
    //     console.log("Uploaded successfully");
        
    //  })
    //   fetch("http://localhost:5000/Quotes")
       
    //  .then((res)=>{
    //     let ans=res.json();
    //     ans.forEach((i)=>{
    //         console.log(`<p>Quote:${i.quote}</p>`);
    //         console.log(`<p>:${i.author}</p>`);
    //     })
    //     if(!res.ok) throw "error";
    //     console.log("Uploaded successfully");
        
    //  })
    //  .catch((err)=>{
    //     console.log(err);
        
    //  }) 
   
    $('p').text('Hello, jQuery!')

    $('.btn').click(function(){
         $('.box').toggleClass('action');
    })
    $('.inbox').keydown(function(ans){
        let tyoing=$(this).val();
                $('.txt').text(tyoing);
    })
    $('.btn1').click(function(){
        $('img').fadeToggle(1000);
    })
    $('.sbtn').click(function(){
        let item=$('.taskbox').val();
        if(item!==""){
             $('.task').append(`<p>${item}</p>`)
             $('.taskbox').val("");
        }
       
    })
    
    $.get('http://localhost:5000/Quotes',function(data){
        data.forEach(element => {
            console.log(element.quote);
            
        });
    })
    console.log("------------------------------------------------------------------------");
    
   
//     $.ajax({
//     url: 'http://localhost:5000/Quotes',
//     method: "POST",
//     contentType: 'application/json',
//     data: JSON.stringify({
//         quote: "Everything will be fine one day",
//         author: "people"
//     }),
//     success: function(response) {
//         console.log("Quote added:", response);
//     },
//     error: function(error) {
//         console.log("Error adding quote:", error);
//     }
    
// });
// $('.update-quote').click(function(){
//     var id="67dd"
//    $.ajax({
//     url:`http://localhost:5000/Quotes/${id}`,
//     method:'PUT',
//     contentType:"application/json",
//     data:JSON.stringify({
//         id:id,
//         quote:"Universe loves stubborn hearts",
//         author:"someone"
//     }),
//     success: function(response){
//     console.log("successs",response);
    
//    },
//    error :function(error){
//     console.log("error occured",error);
    
//    }
//    })
// })

//  $('.po').click(function(e){
//     e.preventDefault();
//      var id=$('.poin').val();
//     $.ajax({
//         url:`http://localhost:5000/Quotes/${id}`,
//         method:'PUT',
//         contentType:"application/json",
//         data:JSON.stringify({
//             id:id,
//             quote:"Believe Universe",
//             author:"anyone"
//         }),
//         success:function(response) {
//             console.log("successfully",response);
            
//         },
//         error:function(err){
//             console.log("error",err);
            
//         }
//     })
//  })
    
$('.po').click(function(e){
    e.preventDefault();
    let quo=$('.poin1').val();
    let aut=$('.poin2').val();
    $.ajax({
       url: `http://localhost:5000/Quotes`,
       method:"POST",
       contentType:"application/json",
       data:JSON.stringify({
            quote:quo,
            author:aut
       }),
       success:function(){
           console.log("success");
           
       },
       error:function(){
           console.log("error");
           
       }
    })
    
})

$('.delete').click(function(e){
    e.preventDefault();
    let id=$('.poin3').val();
    $.ajax({
        url:`http://localhost:5000/Quotes/${id}`,
        method:'DELETE',
        contentType:"application/json",
        success:function(){
             console.log("success");
             
         },
         error:function(){
            console.log("error");
            
         }

    })
    
})
let array=[];
$('.show').click(function(){
      $.ajax({
    url:`http://localhost:5000/Quotes`,
    method:"GET",
    contentType:"application/json",
    success:function(data){
        array=data;
        array.forEach(function (i,t){
            $('.items').append(`<dl><dt>${i.author}</dt><dd><p>${i.quote}</p></dd></dl>`);
        })
    },
    error:function(err){
        console.log("errr");
        
    }
     })
     
})










})
 






























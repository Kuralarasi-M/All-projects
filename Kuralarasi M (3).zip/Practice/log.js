
$(document).ready(function(){
    $('.login').click(function(){
    //    $('.f2').addClass('inout');
    //    $('body').addClass('bg');
         $('.f2').addClass('inout').css('z-index', 1001);
        $('.f1').css('z-index', 1000);
        $('body').addClass('bg');
    })
    $('.close').click(function(){
        $('.f2').removeClass('inout');
         $('body').removeClass('bg');
    })
    $('.signup').click(function(){
          $('.f1').addClass('inout').css('z-index', 1001);
        $('.f2').css('z-index', 1000);
        $('body').addClass('bg');
        $('body').addClass('bg');

      
    })
    $('.signin-close').click(function(){
        $('.f1').removeClass('inout');
           $('body').removeClass('bg');
    })
    
    
    

   $('.submit').click(function(e){
    e.preventDefault();
       let name;
       let email=$('#email').val();
       let password=$("#password").val();
       let user=[];
        let found=false;
        $.get("http://localhost:5000/Users",function(data){
            const user=data.find(u =>u.email===email && u.password===password)
            if(user){
                $('#user').text(user.name);
                alert(user.name)
                
            }
            else{
                console.log("you don't have account, please sign up first");
                
            }
        })
       
        // $.ajax({
        // url:"http://localhost:5000/Users",
        // method:"GET",
        // success:function(data){
        //     user=data;
        //      user.forEach(function(ans){
               
        //         if(ans.email==email.toLowerCase() && ans.password==password){
        //             name=ans.name;
        //               found=true;
        //         }
                
        //   })
        //   if(found){
        //        $('.user').text(name);
        //   }
        //   else{
        //     $(".user").text("user is not found!please sign in");
        //   }
        // },
        // error:function(err){
        //     console.log(err);
            
        // }
        
           
       //})
        $('#email').val("");
       $('#password').val("");
       
   })
   function validate(email,password){
       let valid=false;
        let reg=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if((reg.test(email) && password.length>6))  {
              valid=true;
        }
        return valid;
   }
    $('.submit-signup').click(function(){

        let name=$('#signin-name').val().trim();
        let email=$("#signin-email").val().trim();
        let password=$("#signin-password").val().trim();
        if(!validate(email,password)){
             
              
                const onetoast=document.getElementById("toastedone");
               const toasted= new bootstrap.Toast(onetoast);
              toasted.show();
               $('#signin-name').val("")
              $("#signin-email").val("")
              $("#signin-password").val("")
              console.log("all are good")
                  return;
        }
      
    

        $.ajax({
            url:'http://localhost:5000/Users',
            method:"POST",
            contentType:"application/json",
            data:JSON.stringify({
                 name:name,email:email,password:password
            }),
            success:function(data){
                console.log(data.name);
                
            },
            error:function(err){
                console.log(err);
                
            }
        })
           
        
    })
     $('.btn').click(function(){
         $.get('http://localhost:5000/Quotes',function(data){
                data.forEach(element => {
                 $('.btn').append(element.quote);
                  console.log(element.quote);
            });
              
               
         })
     })

   

})
﻿using UnitTestingAssessment_2.Models;

namespace UnitTestingAssessment_2.NewsLetterService
{
    public interface INewsLetterDataAccess
    {
       
        Task<UserNewsletterSchedule> GetNewsLetter(int userId);
    }
}

﻿using UnitTestingAssessment_2.Models;

namespace UnitTestingAssessment_2.NewsLetterService
{
    public class NewsLetterDataAccess: INewsLetterDataAccess
    {
        public async Task<User> GetNewsLetterUser(int userId)
        {
            return null;
        }
        public async Task<UserNewsletterSchedule> GetNewsLetter(int userId)
        {
            return null;
        }
    }
}

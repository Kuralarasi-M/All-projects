﻿using UnitTestingAssessment_2.Models;
using UnitTestingAssessment_2.NewsLetterService;

namespace UnitTestingAssessment_2.NewLetterDataAccess
{
    public class NewLetterService: INewsLetterService
    {
        private INewsLetterDataAccess dataAccess;
        public NewLetterService(INewsLetterDataAccess dataAccess)
        {
            this.dataAccess = dataAccess;
        }
        List<DateTime> Holidays = new List<DateTime>([new DateTime(2025-12-03), new DateTime(2025 -12-25),
        new DateTime(2025-10-12),new DateTime(2025-09-20),new DateTime(2025-1-1),new DateTime(2025-11-24),]
        );

        public async Task<UserNewsletterSchedule?>  GetNewsLetterAsync(int userId,DateTime date)
        {
            DateTime Today = date.Date;
            bool isHoliday = false;
            foreach (var day in Holidays)
            {
                if (day == Today)
                {
                    isHoliday=true;
                }
            }
            //var user = await dataAccess.GetNewsLetterUser(userId);
            var newLetter = await dataAccess.GetNewsLetter(userId);
            if (newLetter != null)
            {
                if (!newLetter.User.IsOptedIn)
                {
                    return null;
                }
                if (!isHoliday)
                {
                    return null;
                }
                if(newLetter.User.PriorityOnly==true && newLetter.NewsLetter.IsPriority==true)
                {
                    return newLetter;
                }
                else if(newLetter.User.PriorityOnly == false)
                {
                    return newLetter;
                }
                else
                {
                    return null;
                }

                if (newLetter != null && newLetter.NewsLetter.IsWeekendEligible == true && newLetter.User.IsOptedIn == true)
                {
                    return newLetter;
                }
                
            }

            return null;
        }
    }
}

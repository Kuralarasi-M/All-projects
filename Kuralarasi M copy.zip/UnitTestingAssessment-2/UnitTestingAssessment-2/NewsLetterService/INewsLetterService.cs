﻿namespace UnitTestingAssessment_2.NewLetterDataAccess
{
    public interface INewsLetterService
    {

    }
}

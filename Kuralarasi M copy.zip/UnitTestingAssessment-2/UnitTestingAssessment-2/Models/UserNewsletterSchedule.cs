﻿namespace UnitTestingAssessment_2.Models
{
    public class UserNewsletterSchedule
    {
        public int UserId { get; set; }
        public int NewsLetterId { get; set; }
        public DateTime sendDate { get; set; }
        public virtual User User { get; set; }
        public virtual NewsLetter NewsLetter { get; set; }
    }

}

﻿namespace UnitTestingAssessment_2.Models
{
    public class User
    {
        public int UserId { get; set; }
        public string Email { get; set; }

        public Boolean IsOptedIn { get; set; }
        public Boolean PriorityOnly { get; set; }
        public Boolean WeekendOptIn {  get; set; }
    }
}

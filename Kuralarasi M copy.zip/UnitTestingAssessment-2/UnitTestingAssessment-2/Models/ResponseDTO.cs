﻿namespace UnitTestingAssessment_2.Models
{
    public class ResponseDTO
    {
        public Boolean Status { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}

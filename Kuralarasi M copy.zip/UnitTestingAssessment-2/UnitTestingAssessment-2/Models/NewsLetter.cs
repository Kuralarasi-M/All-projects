﻿namespace UnitTestingAssessment_2.Models
{
    public class NewsLetter
    {
        public int NewsLetterId { get; set; }
        public string Title{ get; set; }
        public Boolean IsPriority{ get; set; }
        public Boolean IsWeekendEligible { get; set; }
        public Boolean IsActive { get; set; }

    }
}

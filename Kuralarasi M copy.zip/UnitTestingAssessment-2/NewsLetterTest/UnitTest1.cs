using Bogus;
using FluentAssertions;
using Moq;
using UnitTestingAssessment_2.Models;
using UnitTestingAssessment_2.NewLetterDataAccess;
using UnitTestingAssessment_2.NewsLetterService;
using Xunit.Sdk;

namespace NewsLetterTest
{
    public class NewSLetterUnitTest
    {
        private readonly Mock<INewsLetterDataAccess> mock;
        private Faker<User> usefaker;
        private Faker<NewsLetter> NewLetterfaker;
        public NewSLetterUnitTest()
        {
            mock = new Mock<INewsLetterDataAccess>();
            usefaker = new Faker<User>()
                .RuleFor(r => r.UserId, f => f.IndexFaker + 1)
                .RuleFor(r => r.Email, f => f.Internet.Email())
                .RuleFor(r => r.WeekendOptIn, f => f.Random.Bool())
                .RuleFor(r => r.IsOptedIn, f => f.Random.Bool())
                .RuleFor(r => r.PriorityOnly, f => f.Random.Bool());

            NewLetterfaker = new Faker<NewsLetter>()
                .RuleFor(r => r.NewsLetterId, f => f.IndexFaker + 1)
                .RuleFor(r => r.Title, f => f.Random.Word())
                .RuleFor(r => r.IsWeekendEligible, f => f.Random.Bool())
                .RuleFor(r => r.IsPriority, f => f.Random.Bool())
                .RuleFor(r => r.IsActive, f => f.Random.Bool());


        }
        [Fact]

        public async Task GetNewsletters_UserIdDateValidate_retuenNewLetter()
        {
            var user = usefaker.Generate();
            var news = NewLetterfaker.Generate();
            var userNewLetter = new UserNewsletterSchedule()
            {
                NewsLetterId = news.NewsLetterId,
                UserId = user.UserId,
                sendDate = DateTime.Now,
            };
            var userId = userNewLetter.UserId;
            var Date = DateTime.Now;
            mock.Setup(a => a.GetNewsLetter(1)).ReturnsAsync(userNewLetter);
            var service = new NewLetterService(mock.Object);
            var result = service.GetNewsLetterAsync(userId, Date);
            result.Should().NotBeNull();

        }
        [Fact]
        public async Task GetNewsletters_UserIdDateValidate_returnEmptyWhenOptFlase()
        {
            var user = usefaker.Generate();
            user.IsOptedIn = false;
            var news = NewLetterfaker.Generate();
            var userNewLetter = new UserNewsletterSchedule()
            {
                NewsLetterId = news.NewsLetterId,
                UserId = user.UserId,
                sendDate = DateTime.Now,
            };
            var userId = userNewLetter.UserId;
            var Date = DateTime.Now;
            mock.Setup(a => a.GetNewsLetter(1)).ReturnsAsync(userNewLetter);
            var service = new NewLetterService(mock.Object);
            var result = service.GetNewsLetterAsync(userId, Date);
            result.Should().NotBeNull();

        }
        [Fact]
        public async Task GetNewsletters_UserIdDateValidate_returnNewLetter()
        {
            var user = usefaker.Generate();
            user.PriorityOnly = true;

            var news = NewLetterfaker.Generate();
            news.IsPriority = true;
            var userNewLetter = new UserNewsletterSchedule()
            {
                NewsLetterId = news.NewsLetterId,
                UserId = user.UserId,
                sendDate = DateTime.Now,
            };
            var userId = userNewLetter.UserId;
            var Date = DateTime.Now;
            mock.Setup(a => a.GetNewsLetter(1)).ReturnsAsync(userNewLetter);
            var service = new NewLetterService(mock.Object);
            var result = service.GetNewsLetterAsync(userId, Date);
            result.Should().NotBeNull();

        }
    }
}
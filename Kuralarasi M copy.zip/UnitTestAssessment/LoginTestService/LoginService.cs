﻿using LoginTestDataAccess;
using System.Text;

namespace LoginTestService
{
    public class LoginService: ILoginService
    {
        private readonly ILoginDataAccess dataAccess;
        public LoginService(ILoginDataAccess data)
        {
            dataAccess = data;  
        }
        public async Task<string> LoginUser(string email, string password)
        {
            var user = await dataAccess.UserLogin(email,password);
            return user;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginTestService
{
    public interface ILoginService
    {
        Task<string> LoginUser(string email, string password);
    }
}

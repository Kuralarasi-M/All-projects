﻿using LoginTestDataAccess;
using LoginTestService;
using Microsoft.AspNetCore.Mvc;
using LoginTestDataAccess;
using LoginTestDataAccess.ContextFolder;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace LoginAPI.Controller.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {


        private readonly ILoginService service;
        public LoginController(ILoginService service) {
            this.service = service;
        }
        // GET: api/<LoginController>
        [HttpPost]
        public async Task<IActionResult> GetLoginUser([FromBody] LoginDTO user )
        {
            var email=user.Email;
            var password=user.Password;
            var res = service.LoginUser(email,password);
            return Ok(res);
        }

        // GET api/<LoginController>/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

       

        // PUT api/<LoginController>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/<LoginController>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}

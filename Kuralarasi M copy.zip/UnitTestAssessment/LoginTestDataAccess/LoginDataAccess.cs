﻿using LoginTestDataAccess.ContextFolder;
using Microsoft.EntityFrameworkCore;

namespace LoginTestDataAccess
{
    public class LoginDataAccess: ILoginDataAccess
    {
        private readonly LoginContext context;
        public LoginDataAccess(LoginContext data)
        {
            context = data;
        }
        public async Task<string> UserLogin(string email, string password)
        {
            var user = await context.Logins.FirstOrDefaultAsync(r => r.Email == email && r.IsLocked==false);
            if (user != null)
            {
                if (user.Password == password)
                {
                    user.LastLogin= DateTime.Now;
                    return "sucess";

                }
                else
                {
                    if (user.FailedAttempts >= 5)
                    {
                        user.IsLocked = true;

                        return "Account is Locked";
                    }
                    else
                    {
                        user.MaxFailedAttempt += 1;
                        user.LastFailedAttempt= DateTime.Now;
                        return "Invalid Password.";
                    }
                }
                
            }
            await context.SaveChangesAsync();
            return "Please verify your email before signing in.";
        }
    }
}

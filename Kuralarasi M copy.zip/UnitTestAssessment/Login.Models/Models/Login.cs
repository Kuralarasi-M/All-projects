﻿using System;
using System.Collections.Generic;

namespace LoginTestDataAccess;

public partial class Login
{
    public int UserId { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? Password { get; set; }

    public byte? UserState { get; set; }

    public string? Email { get; set; }

    public bool? IsLocked { get; set; }

    public bool? IsEmailVerified { get; set; }

    public DateTime? LastLogin { get; set; }

    public DateTime? LastFailedAttempt { get; set; }

    public byte? FailedAttempts { get; set; }

    public byte? MaxFailedAttempt { get; set; }
}
public partial class LoginDTO
{
    public string Email { get; set; }

    public string Password { get; set; }


   

   
}

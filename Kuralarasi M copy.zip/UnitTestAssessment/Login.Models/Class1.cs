﻿using Microsoft.EntityFrameworkCore;

namespace LoginModels
{
    public class Class1
    {

    }
}




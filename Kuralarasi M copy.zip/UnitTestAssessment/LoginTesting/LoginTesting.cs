using LoginTestDataAccess.ContextFolder;
using Moq;

namespace LoginUnitTesting
{
    public class LoginTesting
    {
        [Fact]
        public void LoginTesting_ReturnsLoginStatus(string value,string password)
        {
            var mockDataAccess = new Mock<>();
            
        }

    }
}
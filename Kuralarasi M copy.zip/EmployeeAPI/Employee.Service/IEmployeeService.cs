﻿using Employee.Service.EmployeeDTOs;
namespace Employee.Service
{
    public interface IEmployeeService
    {
        Task<IEnumerable<EmployeeDTO>> GetEmployee();
        Task PostEmployee(EmployeePostDTO dto);
        Task<EmployeeDTO> GetEmployee(int id);
        Task<bool> UpdateEmployee(int id, EmployeePostDTO dto);
        Task<bool> DeleteEmployee(int id);
    }
}

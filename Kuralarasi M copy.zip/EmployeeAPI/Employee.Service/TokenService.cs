﻿using Employee.DataAccess;
using Employee.Service.AuthenticationDTO;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Employee.Service
{
    public interface ITokenService
    {
        string GenerateAccessToken(RegisterDTO user);
        string GenerateRefreshToken(RegisterDTO user);
        ClaimsPrincipal GetPrincipalFromExpiredToken(string token);
        Task<TokenResponse> LoginUser(LoginDTO dto);
        Task<string> SignInUser(RegisterDTO dto);
    }

    public class TokenService : ITokenService
    {
        private readonly JwtSettings _jwtSettings;
        private readonly ITokenDataAccess _tokenData;

        public TokenService(IOptions<JwtSettings> jwtSettings, ITokenDataAccess tokenDataAccess)
        {
            _jwtSettings = jwtSettings.Value;
            _tokenData = tokenDataAccess;
        }
        public async Task<string> SignInUser(RegisterDTO dto)
        {
            var user = new Employee.DataAccess.Employee
            {
                Email = dto.Email,
                HashPassword = BCrypt.Net.BCrypt.HashPassword(dto.Password),
                EmployeeName = dto.EmployeeName,
                Role = dto.Role
            };

            return await _tokenData.SignIn(user);
        }

        public string GenerateAccessToken(RegisterDTO user)
        {
            var claims = new List<Claim>
            {
                
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Role, user.Role ?? string.Empty),
                new Claim(ClaimTypes.Email, user.Email ?? string.Empty)
            };

         
            var expiry = DateTime.UtcNow.AddMinutes(_jwtSettings.AccessTokenExpiryMinutes);
            return GenerateToken(claims, expiry);
        }

       
        public string GenerateRefreshToken(RegisterDTO user)
        {
            var claims = new List<Claim>
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
                new Claim("token_type", "refresh")
            };

            var expiry = DateTime.UtcNow.AddHours(_jwtSettings.RefreshTokenExpiryHours);
            return GenerateToken(claims, expiry);
        }

        private string GenerateToken(IEnumerable<Claim> claims, DateTime expiry)
        {
            var key = Encoding.UTF8.GetBytes(_jwtSettings.Secret);
            var creds = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _jwtSettings.Issuer,
                audience: _jwtSettings.Audience,
                claims: claims,
                expires: expiry,
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public ClaimsPrincipal GetPrincipalFromExpiredToken(string token)
        {
            var ValidationParameter = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidIssuer = _jwtSettings.Issuer,
                ValidAudience = _jwtSettings.Audience,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Secret)),
                ValidateLifetime = false 
            };

            var handler = new JwtSecurityTokenHandler();
            var principal = handler.ValidateToken(token, ValidationParameter, out SecurityToken securityToken);

            if (securityToken is not JwtSecurityToken jwt ||
                !jwt.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
            {
                throw new SecurityTokenException("Invalid token");
            }

            return principal;
        }


        public async Task<TokenResponse> LoginUser(LoginDTO dto)
        {
            var list = new Employee.DataAccess.Employee
            {
                Email = dto.Email,
                HashPassword = dto.Password
            };
            var userFromDb = await _tokenData.LoginUserExist(list);
            
            if (userFromDb != null && BCrypt.Net.BCrypt.Verify(dto.Password, userFromDb.HashPassword))
            {
                var userDto = new RegisterDTO
                {
                    Id = userFromDb.EmployeeId,
                    Email = userFromDb.Email,
                    EmployeeName = userFromDb.EmployeeName,
                    Role = userFromDb.Role
                };
                var accessToken = GenerateAccessToken(userDto);
                var refreshToken = GenerateRefreshToken(userDto);

                return new TokenResponse
                {
                    AccessToken = GenerateAccessToken(userDto),
                    RefreshToken = GenerateRefreshToken(userDto)
                };

               

            }

            return null;
            
        }

   
        
    }
}

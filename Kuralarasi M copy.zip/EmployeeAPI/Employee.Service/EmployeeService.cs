﻿using Employee.DataAccess;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee.DataAccess.ContextFolder;
using Employee.Service.EmployeeDTOs;

namespace Employee.Service
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeDataAccess dataAccess;
        public EmployeeService(IEmployeeDataAccess data)
        {
            this.dataAccess = data;
        }

        public async Task<IEnumerable<EmployeeDTO?>> GetEmployee()
        {
            var list = await dataAccess.GetAllEmployee();
            var empList = list.Select(s => new EmployeeDTO
            {
                EmployeeId = s.EmployeeId,
                Email = s.Email,
                EmployeeName = s.EmployeeName,
                Phone = s.Phone,
                Salary = s.Salary,
                DepartmentId = s.DepartmentId,
                HireDate = s.HireDate,
                DepartmentName=s.Department?.DepartmentName
            }).ToList();
            return empList;
        }
        public async Task<EmployeeDTO> GetEmployee(int id)
        {
            var emp = await dataAccess.GetEmployeeById(id);
            if (emp != null)
            {
                var Employee = new EmployeeDTO
                {
                    EmployeeId = emp.EmployeeId,
                    Email = emp.Email,
                    EmployeeName = emp.EmployeeName,
                    Phone = emp.Phone,
                    DepartmentId = emp.DepartmentId,
                    Salary = emp.Salary,
                };
                return Employee;
            }
            else
            {
                return null;
            }

        }
        public async Task PostEmployee(EmployeePostDTO dto)
        {


            var empList = new Employee.DataAccess.Employee
            {
                EmployeeName = dto.EmployeeName,
                Email = dto.Email,
                Phone = dto.Phone,
                HireDate = dto.HireDate,
                Salary = dto.Salary,
                DepartmentId = dto.DepartmentId
                
            };

            await dataAccess.PostEmployeeOne(empList);
        }
        public async Task<bool> UpdateEmployee(int id, EmployeePostDTO dto)
        {
            var empList = new Employee.DataAccess.Employee
            {

                EmployeeName = dto.EmployeeName,
                Email = dto.Email,
                Phone = dto.Phone,
                HireDate = dto.HireDate,
                Salary = dto.Salary,
                DepartmentId = dto.DepartmentId,

            };
            bool Exist = await dataAccess.UpdateEmployeeById(id, empList);
            return Exist;
        }
        public async Task<bool> DeleteEmployee(int id)
        {
            bool Exist = await dataAccess.DeleteEmployeeById(id);
            return Exist;
        }
    }
}

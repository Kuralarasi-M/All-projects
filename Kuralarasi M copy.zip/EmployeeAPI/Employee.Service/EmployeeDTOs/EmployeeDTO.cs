﻿using Employee.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.Service.EmployeeDTOs
{
    public class EmployeeDTO
    {
        public int EmployeeId { get; set; }

        public string EmployeeName { get; set; } = null!;

        public string? Email { get; set; }

        public string? Phone { get; set; }

        public DateOnly HireDate { get; set; }

        public decimal? Salary { get; set; }

        public int? DepartmentId { get; set; }
        public string? DepartmentName { get; set; }

    }
}

﻿namespace Employee.Models
{
    public class Class1
    {

    }
}

﻿using System;
using System.Collections.Generic;

namespace Employee.DataAccess;

public partial class User
{
    public int UserId { get; set; }

    public string? Role { get; set; }

    public string? EmailId { get; set; }

    public string? Password { get; set; }

    public DateTime? CreatedDate { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace Employee.DataAccess;

public partial class Student
{
    public int StudentId { get; set; }

    public string? Name { get; set; }

    public string? Email { get; set; }

    public string? Phone { get; set; }

    public DateOnly? DateOfBirth { get; set; }

    public int? DepartmentId { get; set; }

    public virtual Department1? Department { get; set; }
}

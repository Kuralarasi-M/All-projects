﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BCrypt.Net;
using Employee.DataAccess.ContextFolder;
using Microsoft.EntityFrameworkCore;

namespace Employee.DataAccess
{
    public interface ITokenDataAccess
    {
        Task<Employee> LoginUserExist(Employee dto);
        Task<string> SignIn(Employee dto);
    }
    public class TokenDataAccess: ITokenDataAccess
    {
        private readonly EmployeeContext context;
        public TokenDataAccess (EmployeeContext context)
        {
            this.context = context;
        }
        public async Task<Employee> LoginUserExist(Employee dto)
        {
            
            var user = await context.Employees
    .FirstOrDefaultAsync(s => s.Email == dto.Email);
         
            if (user == null || !BCrypt.Net.BCrypt.Verify(dto.HashPassword, user.HashPassword))
                return null;
            return user;
        }
        public async Task<string> SignIn(Employee dto)
        {
            var user = await context.Employees.AddAsync(dto);
            await context.SaveChangesAsync();
            return "User Updated Successfully.";
        }
    }
}

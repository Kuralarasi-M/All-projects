﻿using Employee.DataAccess.ContextFolder;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee.DataAccess
{
    public class EmployeeDataAccess: IEmployeeDataAccess
    {
        private EmployeeContext  dbContext;
        public EmployeeDataAccess(EmployeeContext employeeContext)
        {
            dbContext = employeeContext;
        }
       public async Task<IEnumerable<Employee>> GetAllEmployee()
        {
            //var list=await  dbContext.Employees.Join(dbContext.Departments,s=> s.DepartmentId,t=> t.DepartmentId, (s, t) => new{
            //    s.EmployeeName,
            //    s.EmployeeId,
            //    s.HireDate,
            //    s.Phone,
            //    s.Email,
            //    s.Salary,
            //    s.DepartmentId,
            //    t.DepartmentName
            //}).ToListAsync();
            var list = await dbContext.Employees.Include(e => e.Department).ToListAsync();
            return  list;
        }
        public async Task PostEmployeeOne(Employee dto )
        {

            var list = await dbContext.Employees.AddAsync(dto);
            await dbContext.SaveChangesAsync();
            
        }
        public async Task<Employee?> GetEmployeeById(int id)
        {
            var emp= await dbContext.Employees.FirstOrDefaultAsync(a => a.EmployeeId ==  id);
             return emp;
        }
        public async Task<bool> UpdateEmployeeById(int id,Employee employee)
        {
            var Exist = await dbContext.Employees.FirstOrDefaultAsync(s => s.EmployeeId == id);
            if (Exist == null)
            {
                return false;
            }
            Console.WriteLine($"Before Update: {Exist.EmployeeName}, {Exist.Email}, {Exist.Salary}");
                
            Exist.EmployeeName = employee.EmployeeName;
                Exist.Email = employee.Email;
                Exist.Phone = employee.Phone;
                Exist.Salary = employee.Salary;
                Exist.DepartmentId = employee.DepartmentId;
                await dbContext.SaveChangesAsync();
            Console.WriteLine($"After Update: {Exist.EmployeeName}, {Exist.Email}, {Exist.Salary}");
            return true;
           
            
        }
        public async Task<bool> DeleteEmployeeById(int id)
        {
            var Exist=await dbContext.Employees.FirstOrDefaultAsync(e => e.EmployeeId == id);
            if(Exist == null) return false;
            dbContext.Employees.Remove(Exist);
            await dbContext.SaveChangesAsync();
            return true;
        }
    }
}

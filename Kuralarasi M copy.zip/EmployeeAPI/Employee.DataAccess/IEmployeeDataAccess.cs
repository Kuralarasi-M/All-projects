﻿namespace Employee.DataAccess
{
    public interface IEmployeeDataAccess
    {
        Task<IEnumerable<Employee>> GetAllEmployee();
        Task PostEmployeeOne(Employee dto);
        Task<Employee> GetEmployeeById(int id);
        Task<bool> UpdateEmployeeById(int id, Employee employee);
        Task<bool> DeleteEmployeeById(int id);
    }
}

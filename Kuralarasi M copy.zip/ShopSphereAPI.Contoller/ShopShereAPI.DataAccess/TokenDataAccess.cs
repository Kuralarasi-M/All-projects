﻿using ShopSphereAPI.Contoller.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BCrypt.Net;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ShopShereAPI.DataAccess
{
    public interface ITokenDataAccess
    {
        Task<User> LoginUserExist(User user);
        Task<string> SignIn(User user);
    }
    public class TokenDataAccess : ITokenDataAccess
    {
        private readonly ShopShereContext context;
        public TokenDataAccess(ShopShereContext context)
        {
            this.context = context;
        }
        public async Task<User?> LoginUserExist(User user)
        {

            var  data = await context.Users.FirstOrDefaultAsync(s => s.Email == user.Email && s.PasswordHash == user.PasswordHash);

            if (user == null)
                return null;
            return user;
        }
        public async Task<string> SignIn(User user)
        {
            var userPost = await context.Users.AddAsync(user);
            await context.SaveChangesAsync();
            return "User Updated Successfully.";
        }
    }
}


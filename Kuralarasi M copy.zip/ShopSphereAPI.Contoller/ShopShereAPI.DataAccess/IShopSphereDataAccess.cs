﻿using ShopSphereAPI.Contoller.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopShereAPI.DataAccess
{
    public interface IShopSphereDataAccess
    {
        Task<IEnumerable<Product>> GetAllProduct();
        Task PostAProduct(Product product);
        Task<string> PlaceOrder(Cart order, int userId);
        Task<IEnumerable<Cart>> GetCartProduct();
    }
}

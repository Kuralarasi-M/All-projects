﻿
using Microsoft.EntityFrameworkCore;
using  ShopSphereAPI.Contoller.Models;
using System.Collections.Generic;
namespace ShopShereAPI.DataAccess
{
    public class ShopSphereDataAccess : IShopSphereDataAccess
    {
        private readonly ShopShereContext context;
        public ShopSphereDataAccess(ShopShereContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<Product>> GetAllProduct()
        {
            var products = await context.Products.ToListAsync();
            return products;
        }
        public async Task PostAProduct(Product product)
        {

            var list = await context.Products.AddAsync(product);
            await context.SaveChangesAsync();

        }
        public async Task<string> PlaceOrder(Cart order,int userId)
        {

            var Product= await context.Products.FirstOrDefaultAsync(s=> s.ProductId == order.ProductId);
            
            var Quantity = await context.Products.FirstOrDefaultAsync(s => (s.ProductId == order.ProductId && s.StockQuantity >= order.Quantity));
            if (Product == null)
            {
                return "Invalid ProductId!.";
            }
            if (Quantity == null)
            {
                return "Currently Product is Unavailable!.";
            }
            var OrderItem = new Cart
            {
                UserId =userId,
                ProductId = order.ProductId,
                UnitPrice = Product.Price,
                Quantity=order.Quantity,
                OrderDate = DateTime.Now  
            };
            Product.StockQuantity=Product.StockQuantity-order.Quantity;
            var list = await context.Carts.AddAsync(OrderItem);
            await context.SaveChangesAsync();
            return "Order Placed Successsfully";
        }
        public async Task<IEnumerable<Cart>> GetCartProduct()
        {
            var list = await context.Carts.ToListAsync();
            return list;
            
        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace ShopSphereAPI.DataAccess;

public partial class Cart
{
    public int OrderId { get; set; }

    public string UserId { get; set; } = null!;

    public string ProductId { get; set; } = null!;

    public DateTime? OrderDate { get; set; }

    public decimal UnitPrice { get; set; }

    public int Quantity { get; set; }

    public decimal TotalAmount { get; set; }
}

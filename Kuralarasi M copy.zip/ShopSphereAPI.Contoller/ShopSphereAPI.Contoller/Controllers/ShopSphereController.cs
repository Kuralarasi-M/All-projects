﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ShopSphereAPI.Service;
using ShopSphereAPI.Service.ShopShereDTO;
using System.Security.Claims;
using System.Threading.Tasks;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ShopSphereAPI.Contoller
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ShopSphereController : ControllerBase
    {
        private readonly IShopSphereService service;
        public ShopSphereController(IShopSphereService shopSphereService)
        {
            service = shopSphereService;
        }
        // GET: api/<ShopSphereController>
        [HttpGet]
        public async Task<IActionResult> GetProductList()
        {
            try
            {
                var Id = User.Claims.FirstOrDefault(s => s.Type == ClaimTypes.NameIdentifier);
                var UserId = Id.Value;
                var product = await service.GetProduct();
                return Ok(product);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }
        [HttpGet("CartItem")]
        public async Task<IActionResult> GetCartItem()
        {
            try
            {
               
                var product = await service.GetCartProduct();
                return Ok(product);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
        // GET api/<ShopSphereController>/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        // POST api/<ShopSphereController>


        [HttpPost("AddItems")]
        [Authorize(Policy = "AllowedPerson")]
        public async Task<ActionResult> Post([FromBody] ProductPostDTO product)
        {
            try
            {
                await service.PostProduct(product);
                return Ok(new { message = "Product Added Successfully!." });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
             
        }

        // PUT api/<ShopSphereController>/5
       
        [HttpPost("AddToCart")]
        public async Task<IActionResult> Order([FromBody] OrderDTO order)
        {

            try
            {
                var user = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier) ;
                int UserId = int.TryParse(user.Value, out int m )?m : 0;
                var orderPlace= await service.PostOrder(order,UserId);
                return Ok(new { message = orderPlace });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // DELETE api/<ShopSphereController>/5
      
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}

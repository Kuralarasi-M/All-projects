﻿using Microsoft.AspNetCore.Mvc;
using ShopSphereAPI.Service;
using ShopSphereAPI.Service.ShopShereDTO;
using System.Security.Claims;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ShopSphereAPI.Contoller.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly ITokenService _tokenService;

        public AuthenticationController(ITokenService tokenService)
        {
            _tokenService = tokenService;
        }

        // GET: api/<TokenController>
        [HttpPost("Login")]

        public async Task<IActionResult> Login([FromBody] LoginDTO dto)
        {

            var tokens = await _tokenService.LoginUser(dto);

            if (tokens == null)
                return Unauthorized("Invalid username or password");

            return Ok(tokens);
        }




        // POST api/<TokenController>
        [HttpPost("Register")]
        public async Task<ActionResult> PostUser([FromBody] RegisterDTO dto)
        {
            string list = await _tokenService.SignInUser(dto);
            return Ok(list);
        }
        [HttpPost("refresh")]
        public IActionResult Refresh([FromBody] TokenRequest request)
        {
         
            var principal = _tokenService.GetPrincipalFromExpiredToken(request.RefreshToken);
            var userId = principal.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var email = principal.FindFirst(ClaimTypes.Email)?.Value;
            var role = principal.FindFirst(ClaimTypes.Role)?.Value;

            // 3. Recreate a user DTO (lightweight object)
            var user = new RegisterDTO { UserId= int.Parse(userId), Email = email, Role = role };

            // 4. Generate new access + refresh tokens
            var newAccessToken = _tokenService.GenerateAccessToken(user);
            var newRefreshToken = _tokenService.GenerateRefreshToken(user);

            // 5. Return both tokens to client
            return Ok(new { accessToken = newAccessToken, refreshToken = newRefreshToken });
        }
    }
}

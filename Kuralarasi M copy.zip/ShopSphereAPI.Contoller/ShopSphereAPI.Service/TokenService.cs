﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using ShopShereAPI.DataAccess;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using BCrypt.Net;
using System.Threading.Tasks;
using ShopSphereAPI.Service.ShopShereDTO;
using ShopSphereAPI.Contoller.Models;
namespace ShopSphereAPI.Service
{
    public interface ITokenService
    {
        string GenerateAccessToken(RegisterDTO user);
        string GenerateRefreshToken(RegisterDTO user);
        ClaimsPrincipal GetPrincipalFromExpiredToken(string token);
        Task<TokenResponse> LoginUser(LoginDTO dto);
        Task<string> SignInUser(RegisterDTO dto);
    }

    public class TokenService : ITokenService
    {
        private readonly JwtSettings _jwtSettings;
        private readonly ITokenDataAccess _tokenData;

        public TokenService(IOptions<JwtSettings> jwtSettings, ITokenDataAccess tokenDataAccess)
        {
            _jwtSettings = jwtSettings.Value;
            _tokenData = tokenDataAccess;
        }

        // -------------------- ACCESS TOKEN --------------------
        public string GenerateAccessToken(RegisterDTO user)
        {
            var claims = new List<Claim>
            {

                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                new Claim(ClaimTypes.Role, user.Role ?? string.Empty),
                new Claim(ClaimTypes.Email, user.Email ?? string.Empty)
            };

            // Access token is short-lived
            var expiry = DateTime.UtcNow.AddMinutes(_jwtSettings.AccessTokenExpiryMinutes);
            return GenerateToken(claims, expiry);
        }
      


        // -------------------- REFRESH TOKEN --------------------
        public string GenerateRefreshToken(RegisterDTO user)
        {
            var claims = new List<Claim>
            {
                 new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
               
                new Claim("token_type", "refresh")
            };

            // Refresh token is long-lived
            var expiry = DateTime.UtcNow.AddHours(_jwtSettings.RefreshTokenExpiryHours);
            return GenerateToken(claims, expiry);
        }

        // -------------------- GENERIC TOKEN --------------------
        private string GenerateToken(IEnumerable<Claim> claims, DateTime expiry)
        {
            var key = Encoding.UTF8.GetBytes(_jwtSettings.Secret);
            var creds = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _jwtSettings.Issuer,
                audience: _jwtSettings.Audience,
                claims: claims,
                expires: expiry,
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        // -------------------- VALIDATE EXPIRED TOKEN --------------------
        public ClaimsPrincipal GetPrincipalFromExpiredToken(string token)
        {
            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidIssuer = _jwtSettings.Issuer,
                ValidAudience = _jwtSettings.Audience,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Secret)),
                ValidateLifetime = false 
            };

            var handler = new JwtSecurityTokenHandler();
            var principal = handler.ValidateToken(token, tokenValidationParameters, out SecurityToken securityToken);

            if (securityToken is not JwtSecurityToken jwt ||
                !jwt.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
            {
                throw new SecurityTokenException("Invalid token");
            }

            return principal;
        }

        // -------------------- LOGIN --------------------
        public async Task<TokenResponse> LoginUser(LoginDTO dto)
        {
            var list = new User
            {
                Email = dto.Email,
                PasswordHash = dto.HashPassword
            };
            var userFromDb = await _tokenData.LoginUserExist(list);
           
            if (userFromDb != null)
            {
                var userDto = new RegisterDTO
                {
                    UserId = userFromDb.UserId,
                    Email = userFromDb.Email,
                     Name = userFromDb.Name,
                    Role = userFromDb.Role
                };
                var accessToken = GenerateAccessToken(userDto);
                var refreshToken = GenerateRefreshToken(userDto);

                return new TokenResponse
                {
                    AccessToken = GenerateAccessToken(userDto),
                    RefreshToken = GenerateRefreshToken(userDto)
                };




            }

            return null;

        }

        // -------------------- SIGNUP --------------------
        public async Task<string> SignInUser(RegisterDTO dto)
        {
            var user = new User
            {
                Email = dto.Email,
                PasswordHash = dto.PasswordHash,
                Name = dto.Name,
                Role = dto.Role
            };

            return await _tokenData.SignIn(user);
        }
    }
}



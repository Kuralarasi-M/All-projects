﻿using ShopSphereAPI.Contoller.Models;
using ShopSphereAPI.Service.ShopShereDTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopSphereAPI.Service
{
    public interface IShopSphereService
    {
        Task<IEnumerable<ProductDTO>> GetProduct();
        
        Task PostProduct(ProductPostDTO product);

        Task<String> PostOrder(OrderDTO order, int userId);
     
        Task<IEnumerable<CartItem>> GetCartProduct();

    }
}

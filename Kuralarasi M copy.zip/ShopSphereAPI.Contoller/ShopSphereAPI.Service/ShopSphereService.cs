﻿using Microsoft.AspNetCore.Mvc;
using ShopShereAPI.DataAccess;
using ShopSphereAPI.Contoller.Models;
using ShopSphereAPI.Service.ShopShereDTO;
using static ShopSphereAPI.Service.ShopSphereService;
namespace ShopSphereAPI.Service
{
    public class ShopSphereService: IShopSphereService
    {
  
         private readonly IShopSphereDataAccess dataAccess;
         public ShopSphereService(IShopSphereDataAccess data)
            {
                this.dataAccess = data;
            }

            public async Task<IEnumerable<ProductDTO>> GetProduct()
        {
            var product = await dataAccess.GetAllProduct();
            var productList = product.Select(s => new ProductDTO
            {
                ProductId=s.ProductId,
                ProductName=s.ProductName,
                Price= s.Price,
                StockQuantity= s.StockQuantity,
                Description= s.Description,
            });
            return productList;
        }
        public async Task PostProduct(ProductPostDTO product)
        {
           
            var list = new Product
            {
                ProductName= product.ProductName,
                Price= product.Price,
                Description= product.Description,
                StockQuantity= product.StockQuantity
            };
            await dataAccess.PostAProduct(list);

        }
        public async Task<String> PostOrder(OrderDTO order,int userId)
        {

            var list = new Cart
            {
                ProductId = order.ProductId,
                Quantity= order.Quantity,   
            };
            var Response= await dataAccess.PlaceOrder(list, userId);
            return Response;
        }
        public async Task<IEnumerable<CartItem>> GetCartProduct()
        {
            var product = await dataAccess.GetCartProduct();
            var productList = product.Select(s => new CartItem
            {
                ProductId= s.ProductId,
                Quantity= s.Quantity,
                UnitPrice= s.UnitPrice,
                TotalAmount= s.Quantity*s.UnitPrice,
                OrderDate= s.OrderDate, 
                
            });
            return productList;
        }
    }
}

﻿namespace ShopShereAPI.Models
{
    public class Class1
    {

    }
}

﻿using System;
using System.Collections.Generic;

namespace ShopSphereAPI.Contoller.Models;

public partial class Cart
{
    public int OrderId { get; set; }

    public int UserId { get; set; } 

    public int ProductId { get; set; }

    public DateTime? OrderDate { get; set; }

    public decimal UnitPrice { get; set; }

    public int Quantity { get; set; }

    public decimal TotalAmount { get; set; }
}

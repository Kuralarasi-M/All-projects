﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.Service;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class ToDoDemoController : ControllerBase
    {
        private readonly IToDoService service;
        public ToDoDemoController(IToDoService service)
        {
            this.service = service;
        }

        // GET: api/<ToDoDemoController>
        [HttpGet]
       
        public ActionResult<IEnumerable<ToDo>> GetAll()
        {
            var todo = service.GetAllToDos();
            return Ok(todo);
        }


        // GET api/<ToDoDemoController>/5
        [HttpGet("{id}")]
        public ActionResult<ToDo> GetById(int id)
        {
            var todo =service.GetById(id);

            if (todo == null)
                return NotFound(new { message = $"No ToDo found with Id = {id}" });

            return Ok(todo);
        }


        // POST api/<ToDoDemoController>
        [HttpPost]
        public ActionResult<ToDo> Post([FromBody] ToDo toDo)
        {
            service.CreateToDo(toDo); 
            return CreatedAtAction(nameof(GetById), new { id = toDo.Id }, toDo);
        }

        // PUT api/<ToDoDemoController>/5
        [HttpPut("{id}")]
        public ActionResult<ToDo> Update(int id, [FromBody] ToDo toDo)
        {

           bool updated= service.UpdateToDo(id, toDo);
            if (!updated)
            {
                return NotFound(new { message = $"No ToDo found with Id = {id}" });
            }

            return Ok(new { message = $"ToDo with Id = {id} updated successfully." });



        }

        // DELETE api/<ToDoDemoController>/5
        [HttpDelete("{id}")]
        public ActionResult<ToDo> DeleteToById(int id)
        {
            bool deleted=service.DeleteToDo(id);
            if (!deleted)
            {
                return NotFound(new { message = $"No ToDo found with Id = {id}" });
            }

            return Ok(new { message = $"ToDo with Id = {id} updated successfully." });
        }
    }
}

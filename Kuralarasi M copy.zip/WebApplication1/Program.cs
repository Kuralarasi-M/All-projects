using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;
using WebApplication1.DataAccess;
using WebApplication1.Service;
var builder = WebApplication.CreateBuilder(args);

// Add DbContext
builder.Services.AddDbContext<AspdbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
);

// Register DAL and BL
builder.Services.AddScoped<IToDoRepository, ToDoRepository>();
builder.Services.AddScoped<IToDoService, ToDoService>();

// Configure CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("CustomPolicy",
        builder => builder
            .AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader());
});

// Controllers & Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Middleware
app.UseCors("CustomPolicy");
app.UseHttpsRedirection();
app.UseAuthorization();

// Enable Swagger in all environments (optional)
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "ToDo API V1");
});

app.MapControllers();

app.Run();

﻿using System.Collections.Generic;
using WebApplication1.Models;

namespace WebApplication1.Service
{
    public interface IToDoService
    {
        IEnumerable<ToDo> GetAllToDos();
        ToDo? GetById(int id);
        void CreateToDo(ToDo todo);
        bool UpdateToDo(int id, ToDo todo);
        bool DeleteToDo(int id);
    }
}


﻿using System.Collections.Generic;
using WebApplication1.Models;
using WebApplication1.DataAccess;

namespace WebApplication1.Service
{
    public class ToDoService : IToDoService
    {
        private readonly IToDoRepository repository;

        public ToDoService(IToDoRepository repository)
        {
            this.repository = repository;
        }

        public IEnumerable<ToDo> GetAllToDos()
        {
            return repository.GetAll();
        }

        public ToDo? GetById(int id)
        {
            return repository.GetToDoById(id);
        }

        public void CreateToDo(ToDo todo)
        {
            repository.Post(todo);
        }

        public bool UpdateToDo(int id, ToDo todo)
        {
           bool exist= repository.UpdateById(id, todo);
            return exist;
        }

        public bool DeleteToDo(int id)
        {
           bool exist= repository.DeleteToDoById(id);
            return exist;
        }
    }
}

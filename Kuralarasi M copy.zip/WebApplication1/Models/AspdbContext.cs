﻿using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models
{
    public partial class AspdbContext : DbContext
    {
        public AspdbContext(DbContextOptions<AspdbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ToDo> ToDos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ToDo>(entity =>
            {
                entity.HasKey(e => e.Id).HasName("PK__ToDo__3214EC078A936F97");

                entity.ToTable("ToDo");

                entity.Property(e => e.Date).HasColumnType("datetime");
                entity.Property(e => e.Description)
                    .HasMaxLength(50)
                    .IsUnicode(false);
                entity.Property(e => e.Title)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}

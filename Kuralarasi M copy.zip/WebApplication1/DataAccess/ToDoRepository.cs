﻿
using WebApplication1.Models;

namespace WebApplication1.DataAccess
{
    public class ToDoRepository : IToDoRepository
    {
        private readonly AspdbContext _dbContext;

        public ToDoRepository(AspdbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<ToDo> GetAll()
        {
            return _dbContext.ToDos.ToList();
        }

        public ToDo? GetToDoById(int id)
        {
            return _dbContext.ToDos.Find(id);
        }

        public ToDo Post(ToDo toDo)
        {
            _dbContext.ToDos.Add(toDo);
            _dbContext.SaveChanges();
            return toDo;
        }

        public bool UpdateById(int id, ToDo toDo)
        {
            var existingToDo = _dbContext.ToDos.Find(id);
            if (existingToDo == null) return false;

            existingToDo.Title = toDo.Title;
            existingToDo.Description = toDo.Description;
            existingToDo.Date = toDo.Date;

            _dbContext.SaveChanges();
            return true;
        }

        public bool DeleteToDoById(int id)
        {
            var existingToDo = _dbContext.ToDos.Find(id);
            if (existingToDo == null) return false;

            _dbContext.ToDos.Remove(existingToDo);
            _dbContext.SaveChanges();
            return true;
        }
    }
}

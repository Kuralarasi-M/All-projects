﻿using System.Collections.Generic;
using WebApplication1.Models;

namespace WebApplication1.DataAccess
{
    public interface IToDoRepository
    {
        IEnumerable<ToDo> GetAll();
        ToDo? GetToDoById(int id);
        ToDo Post(ToDo toDo);
        bool UpdateById(int id, ToDo todo);
        bool DeleteToDoById(int id);
    }
}


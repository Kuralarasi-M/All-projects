﻿using EmployeeMetaLogAPI.DTO;
using EmployeeMetaLogAPI.Models;

namespace EmployeeMetaLogAPI.Employeeservice
{
 
    public interface IEmployeeService
        {
        Task<int> postEmployee(EmpolyeeDTO employee);

    }
    public class EmployeeService: IEmployeeService
    {
        private readonly EmployeeOnBoardContext context;
        public EmployeeService(EmployeeOnBoardContext context)
        {
            this.context = context;
        }
        public async Task<int> postEmployee(EmpolyeeDTO employee)
        {
            var emp = new Metalog
            {
                EmployeeId = employee.EmployeeId,
                EmployeeName = employee.EmployeeName,
                DepartmentId = employee.DepartmentId,
                RoleId = employee.RoleId,
                JoiningDate = employee.JoiningDate,
            };
            var result = await context.Metalogs.AddAsync(emp);
            int response = await context.SaveChangesAsync();
            return response;
        }

    }


}

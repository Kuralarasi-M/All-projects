﻿namespace EmployeeMetaLogAPI.DTO
{
    public class EmpolyeeDTO
    {
        public string? EmployeeId { get; set; }

        public string? EmployeeName { get; set; }

        public int? DepartmentId { get; set; }

        public int? RoleId { get; set; }

        public DateOnly? JoiningDate { get; set; }
    }
}

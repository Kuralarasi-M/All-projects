﻿using EmployeeMetaLogAPI.DTO;
using EmployeeMetaLogAPI.Employeeservice;
using EmployeeMetaLogAPI.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmployeeMetaLogAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MetaLogController : ControllerBase
    {
        private readonly IEmployeeService service;
        public MetaLogController(IEmployeeService service)
        {
            this.service = service;
        }
        [HttpPost]
        public async Task<IActionResult> PostEmployee([FromBody] EmpolyeeDTO value)
        {
            try
            {
                var result = await service.postEmployee(value);
                if (result != null)
                {
                    return Ok(new {status="Success" ,message = "Employee data Added successfully and Processed for payroll setup", processedBy="Finance API",
                    processedDate=DateTime.Now});
                }
                return BadRequest("Fail to add Employee");
            }
            catch (Exception ex)
            {
                return BadRequest(new { ErrorMessage = ex });
            }

        }


    }
}

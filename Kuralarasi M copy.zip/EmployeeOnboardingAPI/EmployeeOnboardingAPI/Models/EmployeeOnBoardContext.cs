﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EmployeeOnboardingAPI.Models;

public partial class EmployeeOnBoardContext : DbContext
{
    public EmployeeOnBoardContext()
    {
    }

    public EmployeeOnBoardContext(DbContextOptions<EmployeeOnBoardContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<DepartmentRole> DepartmentRoles { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<Metalog> Metalogs { get; set; }

   
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(e => e.DepartmentId).HasName("PK__Departme__B2079BEDB5CA88CD");

            entity.ToTable("Department");

            entity.Property(e => e.DepartmentName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<DepartmentRole>(entity =>
        {
            entity.HasKey(e => e.RoleId).HasName("PK__Departme__8AFACE1A98D5DA4C");

            entity.ToTable("DepartmentRole");

            entity.Property(e => e.RoleName)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.Department).WithMany(p => p.DepartmentRoles)
                .HasForeignKey(d => d.DepartmentId)
                .HasConstraintName("FK__Departmen__Depar__5535A963");
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.SubmissionId).HasName("PK__Employee__449EE1257A336F65");

            entity.ToTable("Employee");

            entity.HasIndex(e => e.EmployeeId, "UQ__Employee__7AD04F109E4884C9").IsUnique();

            entity.HasIndex(e => e.Email, "UQ__Employee__A9D105345D5406D5").IsUnique();

            entity.Property(e => e.Ctc).HasColumnName("CTC");
            entity.Property(e => e.Email)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.EmployeeId)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.FirstName)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.IsHod).HasColumnName("isHOD");
            entity.Property(e => e.LastName)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Location)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.MiddleName)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.PhoneNumber)
                .HasMaxLength(15)
                .IsUnicode(false);

            entity.HasOne(d => d.Department).WithMany(p => p.Employees)
                .HasForeignKey(d => d.DepartmentId)
                .HasConstraintName("FK__Employee__Depart__5AEE82B9");

            entity.HasOne(d => d.Role).WithMany(p => p.Employees)
                .HasForeignKey(d => d.RoleId)
                .HasConstraintName("FK__Employee__RoleId__5BE2A6F2");
        });

        modelBuilder.Entity<Metalog>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Metalog");

            entity.HasIndex(e => e.EmployeeId, "UQ__Metalog__7AD04F1054976405").IsUnique();

            entity.Property(e => e.EmployeeId)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.EmployeeName)
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.Department).WithMany()
                .HasForeignKey(d => d.DepartmentId)
                .HasConstraintName("FK__Metalog__Departm__5EBF139D");

            entity.HasOne(d => d.Role).WithMany()
                .HasForeignKey(d => d.RoleId)
                .HasConstraintName("FK__Metalog__RoleId__5FB337D6");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

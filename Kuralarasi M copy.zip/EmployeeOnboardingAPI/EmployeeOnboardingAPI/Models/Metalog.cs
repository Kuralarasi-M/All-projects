﻿using System;
using System.Collections.Generic;

namespace EmployeeOnboardingAPI.Models;

public partial class Metalog
{
    public string? EmployeeId { get; set; }

    public string? EmployeeName { get; set; }

    public int? DepartmentId { get; set; }

    public int? RoleId { get; set; }

    public DateOnly? JoiningDate { get; set; }

    public virtual Department? Department { get; set; }

    public virtual DepartmentRole? Role { get; set; }
}

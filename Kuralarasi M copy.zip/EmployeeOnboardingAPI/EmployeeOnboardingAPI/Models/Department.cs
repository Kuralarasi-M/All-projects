﻿using System;
using System.Collections.Generic;

namespace EmployeeOnboardingAPI.Models;

public partial class Department
{
    public int DepartmentId { get; set; }

    public string? DepartmentName { get; set; }

    public virtual ICollection<DepartmentRole> DepartmentRoles { get; set; } = new List<DepartmentRole>();

    public virtual ICollection<Employee> Employees { get; set; } = new List<Employee>();
}

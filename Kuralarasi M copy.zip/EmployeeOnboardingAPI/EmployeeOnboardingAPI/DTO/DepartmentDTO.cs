﻿namespace EmployeeOnboardingAPI.DTO
{
    public class DepartmentDTO
    {
        public int DepartmentId { get; set; }

        public string? DepartmentName { get; set; }
    }
}

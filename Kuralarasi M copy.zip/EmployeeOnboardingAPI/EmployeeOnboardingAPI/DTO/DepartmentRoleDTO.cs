﻿namespace EmployeeOnboardingAPI.DTO
{
    public class DepartmentRoleDTO
    {
        public int Id { get; set; }
    }
}

﻿namespace EmployeeOnboardingAPI.DTO
{
    public class ResponseDTO
    {
        public int SubmissionId { get; set; }
        public string EmployeeId { get; set; }
    }
}

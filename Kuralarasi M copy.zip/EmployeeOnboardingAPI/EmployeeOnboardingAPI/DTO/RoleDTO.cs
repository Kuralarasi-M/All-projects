﻿namespace EmployeeOnboardingAPI.DTO
{
    public class RoleDTO
    {
        public int RoleId { get; set; }

        public string? RoleName { get; set; }

        public int? DepartmentId { get; set; }
        public string?  DepartmentName { get; set; }
    }
}

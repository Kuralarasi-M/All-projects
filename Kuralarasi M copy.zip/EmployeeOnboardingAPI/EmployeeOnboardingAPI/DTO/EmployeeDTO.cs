﻿namespace EmployeeOnboardingAPI.DTO
{
    public class EmployeeDTO
    {
        public string? EmployeeId { get; set; }

        public string? FirstName { get; set; }

        public string? MiddleName { get; set; }

        public string? LastName { get; set; }

        public string? Email { get; set; }

        public string? PhoneNumber { get; set; }

        public int? DepartmentId { get; set; }

        public int? RoleId { get; set; }

        public string? Location { get; set; }

        public int? Experience { get; set; }

        public DateOnly? JoiningDate { get; set; }

       

        public int? Ctc { get; set; }

        public bool? IsHod { get; set; }
    }
}

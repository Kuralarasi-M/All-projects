﻿using EmployeeOnboardingAPI.DTO;
using EmployeeOnboardingAPI.EmployeeAppService;
using EmployeeOnboardingAPI.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmployeeOnboardingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService service;
        public EmployeeController(IEmployeeService service)
        {
            this.service = service;
        }
        //GET: api/<EmployeeController>
        [HttpGet("Departments")]
        public async Task<IActionResult> GetDepartment()
        {
            try
            {
                var departments = await service.departmentList();
                if (departments == null)
                {
                    return NoContent();
                }
                return Ok(departments);
            }
            catch(Exception ex)
            {
                return BadRequest(new { ErrorMessage = ex });
            }
            
        }
        [HttpGet("Roles")]
        public async Task<IActionResult> GetDepartmentRoles()
        {
            try
            {
                var departmentRoles = await service.departmentRoleList();
                if (departmentRoles == null)
                {
                    return NoContent();
                }
                return Ok(departmentRoles);
            }
            catch (Exception ex)
            {
                return BadRequest(new { ErrorMessage = ex });
            }

        }



        // POST api/<EmployeeController>
        [HttpPost]
        public async Task<IActionResult> PostEmployee([FromBody] EmployeeDTO value)
        {
            try
            {
                var result = await service.postEmployee(value);
                if (result != null)
                {
                    return Ok(new { message = "Employee updated successfully", EmployeeInfo = result });
                }
                return BadRequest("Fail to add Employee");
            }
            catch (Exception ex)
            {
                return BadRequest(new { ErrorMessage = ex });
            }
            
        }

        
    }
}

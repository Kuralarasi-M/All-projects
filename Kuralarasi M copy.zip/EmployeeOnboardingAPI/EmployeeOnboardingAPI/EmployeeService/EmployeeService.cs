﻿using Azure;
using EmployeeOnboardingAPI.DTO;
using EmployeeOnboardingAPI.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace EmployeeOnboardingAPI.EmployeeAppService
{
    public interface IEmployeeService
    {
        Task<ResponseDTO?> postEmployee(EmployeeDTO employee);
        Task<IEnumerable<DepartmentDTO?>?> departmentList();
        Task<IEnumerable<RoleDTO?>?> departmentRoleList();
      
    }
    public class EmployeeService: IEmployeeService
    {
        private readonly EmployeeOnBoardContext context;
        public EmployeeService(EmployeeOnBoardContext context)
        {
            this.context = context; 
        }
        public async Task<ResponseDTO?> postEmployee(EmployeeDTO employee)
        {
            
            var emp = new Employee
            {
                Email = employee.Email,
                FirstName = employee.FirstName,
                LastName = employee.LastName,
                MiddleName = employee.MiddleName,
                EmployeeId = employee.EmployeeId,
                IsHod = employee.IsHod,
                RoleId = employee.RoleId,
                DepartmentId = employee.DepartmentId,
                Ctc = employee.Ctc,
                JoiningDate = employee.JoiningDate,
                PhoneNumber = employee.PhoneNumber,
                Location = employee.Location,
                Experience = employee.Experience,
                ProbationEndDate =new DateOnly().AddMonths(6)
            };
            var result =  await context.Employees.AddAsync(emp);
            int response = await context.SaveChangesAsync();
            if (response == 1)
            {
                var newEmployee = context.Employees.FirstOrDefault(s=> s.EmployeeId==employee.EmployeeId);
                return new ResponseDTO
                {
                    SubmissionId = newEmployee.SubmissionId,
                    EmployeeId=newEmployee.EmployeeId
                };
            }
            return null;
        }
        public async Task<IEnumerable<DepartmentDTO?>> departmentList()
        {

            var list = new List<DepartmentDTO>();
            var department = await context.Departments.ToListAsync();
            if(department != null)
            {
                foreach (var i in department)
                {

                    list.Add(new DepartmentDTO
                    {
                        DepartmentId = i.DepartmentId,
                        DepartmentName = i.DepartmentName

                    });
                }
                return list;
            }
            return null;
        }
        public async Task<IEnumerable<RoleDTO?>> departmentRoleList()
        {
            var department = await context.DepartmentRoles.ToListAsync();
       
            var list= new List<RoleDTO>();
            if (department != null)
            {
                foreach (var i in department)
                {
                  
                    list.Add(new RoleDTO
                    {
                        RoleId= i.RoleId,
                        RoleName= i.RoleName,
                        DepartmentId=i.DepartmentId,
                        DepartmentName=i.Department?.DepartmentName,
                        
                    });
                }
                return list;
            }
            return null;
        }
       
    }
}

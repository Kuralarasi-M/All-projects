import axios from "axios";
import { Navigate } from "react-router-dom";




const AxiosInstance= axios.create({
    baseURL:"https://localhost:44362/api",
    headers:{
        "Content-Type":"application/json",
        "Accept":"application/json"
    },
});

AxiosInstance.interceptors.request.use(

    (config) => {
        const token=localStorage.getItem("accessToken");
        if(token){
            config.headers['Authorization']=`Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        console.log("Error msg: ",error);
        return Promise.reject(error)
    }
)


AxiosInstance.interceptors.response.use(
  response => response,
  async error => {
      const originalRequest = error.config;

      if(originalRequest.url === '/Account/Register'){
        localStorage.removeItem("accessToken");
        localStorage.removeItem("refreshToken");
        
        return Promise.reject(error);
      }


    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
        try {
        const refreshToken = localStorage.getItem("refreshToken");
        if (!refreshToken) throw new Error("No refresh token");
        console.log("refresh error");
        
        const refreshResponse = await AxiosInstance.post(
          "/Account/Register",
          { refreshToken:refreshToken }
          
        );
        
        const newAccessToken = refreshResponse.data.accessToken;
        const newRefreshToken = refreshResponse.data.refreshToken;

        console.log('New token received');
        
        console.log(newAccessToken);
        

        localStorage.setItem("accessToken", newAccessToken);
         localStorage.setItem("refreshToken", newRefreshToken);
         localStorage.setItem("isUser","false");
         localStorage.setItem("isAdmin","true");


        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
        return AxiosInstance(originalRequest); 
      } 
      catch (err) {
        console.error("Refresh token failed", err);
        localStorage.removeItem("accessToken");
        localStorage.removeItem("refreshToken");
        localStorage.removeItem("isUser");
         localStorage.removeItem("isAdmin");
        return Promise.reject(err);
      }
    }
     return Promise.reject(error);
    }
   
  
);


export default AxiosInstance;
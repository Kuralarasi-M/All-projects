import {z} from 'zod';

const loginSchema = z.object({
    email:z.string().nonempty("Email is Required!.").email("Invalid EmailId!."),
    password:z.string().nonempty("Password is Required!.").min(8,"Minimum 8 characters only allowed!.")
    .max(15,"Maximum 15 characters only allowed!.")
    // .regex(/^(?=.*[a-z])(?=.*[A-Z]])(?=.*[0-9])(?=.*[~`!@#$%^&*+=_ \-])[0-9A-Za-z?+*&^%$#@!~\-]{8,}$/,"Atleast one small,capital,number,special characters required!.")
})

export default loginSchema;


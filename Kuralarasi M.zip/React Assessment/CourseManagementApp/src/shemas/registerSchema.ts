import {z} from 'zod';

const registerSchema = z.object({
    id:z.string().optional(),
    name:z.string().nonempty("Name is Required!.").min(3,"Minimum 3 characters only allowed!.")
    .max(30,"Maximum 30 characters only allowed!.").regex(/^[a-zA-Z ]{3,}$/,"Only letters allowed"),
    email:z.string().nonempty("Email is Required!.").email("Invalid EmailId!."),
    dob:z.string().nonempty("Select your DOB.")
     .refine(date => new Date(date)< new Date(),"Date doesn't be in future")
     .refine(date => {
        const today=new Date();
        const userData=new Date(date);
        const age= today.getFullYear()-userData.getFullYear();
        const isBirthdayPassed = today.getMonth>userData.getMonth || today.getMonth === userData.getMonth && today.getDate > userData.getDate
        return isBirthdayPassed ? age >= 10 : age-1 >=10
     },"Age must be 10 or above!."),
    phoneNumber:z.string().nonempty("PhoneNo is Required").regex(/^[0-9+\-]+$/,"Invalid Phone No"),
    password:z.string().nonempty("Password is Required!.").min(8,"Minimum 8 characters only allowed!.")
    .max(15,"Maximum 15 characters only allowed!."),
    isActive:z.boolean().default(true),
    isAdmin:z.boolean().default(false),
   
    
})

export default registerSchema;

import {z} from 'zod';

const courseSchema = z.object({
    id:z.number().optional(),
    name:z.string().nonempty("CourseName is Required!.").min(2,"Minimum 2 letters Required").max(100,"Maximum 100 letters only Allowed!."),
    durationInMonths:z.coerce.number().min(1,"Minimum 1 month Required").max(24,"Maximum 24 Months only allowed!.")
    .default(1),
   minimumRequiredAge:z.coerce.number().min(10,"Below 10 Aged people not allowed").max(100," Above 100 age people not Allowed")
    .default(10),
    startDate:z.date().optional(),
    createdOn:z.string().optional()
})

export default courseSchema;
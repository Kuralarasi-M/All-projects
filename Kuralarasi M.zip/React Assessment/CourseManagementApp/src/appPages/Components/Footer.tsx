import React from 'react'

const Footer = () => {
  return (
    <div className='mt-5'>
      <div className='mt-5 text-center bg-dark text-light'>
        <h3>About us</h3>
        <div>
            <ul className='d-inline'>
                <li>Insta</li>
                <li>Twitter</li>
                <li>FaceBook</li>
                <li>Email</li>
                <li>YouTube</li>
            </ul>
        </div>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto doloremque nemo debitis. Explicabo iusto asperiores ratione nemo possimus numquam aspernatur quod unde sed, quas velit quo omnis aperiam deserunt, voluptate rerum? Velit, alias commodi? Maxime accusamus beatae accusantium fugit reiciendis praesentium, optio aliquid aut voluptas.</p>
      </div>
    </div>
  )
}

export default Footer

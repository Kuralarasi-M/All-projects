import React, { useEffect } from 'react'
import { Container, Nav, Navbar } from 'react-bootstrap'
import { Link } from 'react-router-dom'


const NavBar = () => {
    
    const isAdmin = localStorage.getItem("isAdmin");
    const isUser = localStorage.getItem("isUser");
    return (
        <div>
            <Navbar bg="dark" variant="dark" expand="lg">
                <Container>

                    <Navbar.Brand as={Link} to="/">Course Management System</Navbar.Brand>

                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">

                        <Nav className="ms-auto">

                            {!isAdmin && !isUser &&
                                <Nav.Link as={Link} to="/">Login</Nav.Link>
                                
                            }

                            {isAdmin && <>
                                <Nav.Link as={Link} to="/home">Home</Nav.Link>
                                <Nav.Link as={Link} to="/course">Course</Nav.Link>
                                <Nav.Link as={Link} to="/user">User Details</Nav.Link>
                            </>}
                            {isUser == "true" &&
                                <Nav.Link as={Link} to="/dashboard">User DashBoard</Nav.Link>
                            }
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </div>
    )
}

export default NavBar

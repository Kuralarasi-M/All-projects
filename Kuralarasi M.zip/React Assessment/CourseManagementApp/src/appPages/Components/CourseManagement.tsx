
import { useEffect, useState } from 'react';
import { Button, Form, FormControl, FormGroup, FormLabel, Table } from 'react-bootstrap';
import type z from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import courseSchema from '../../shemas/courseSchema';
import axiosInstance from '../../authenticationApi/api';



type CourseData = z.infer<typeof courseSchema>;
const CourseManagement = () => {

    const [apiError, setApiError] = useState('');
    const [course, setCourse] = useState<CourseData[]>([]);
    const { register, handleSubmit, formState: { errors }, reset, watch } = useForm<CourseData>({
        resolver: zodResolver(courseSchema),
        defaultValues: {
            id: 0,
            name: "",
            durationInMonths: 1,
            minimumRequiredAge: 10,
            startDate: new Date()
        }
    });
    const currentId = watch('id');
    useEffect(() => {
        axiosInstance.get("/Course/GetCourses")
            .then((res) => {
                console.log(res.data);
                setCourse(res.data);
            })
            .catch((err) => {
                console.error("Error fetching:", err);

            });
    }, []);
    const deleteCourse = (data: CourseData) => {
        try {
            if (window.confirm("Are you want to Delete?")) {
                axiosInstance.delete(`/Course/Delete/${data.id}`);
                setCourse(pre => pre.filter(s => s.id != data.id))
            }

        }
        catch (err) {
            console.error("Error fetching:", err);
        }
    }
    const editCourse = (data: CourseData) => {
        reset(data);

    }


    const formSubmit = async (data: CourseData) => {
        console.log("here");

        console.log("Form submitted!", data);

        setApiError('');

        try {
            if (currentId && currentId > 0) {

                await axiosInstance.put('/Course/Edit', data);
                console.log("Edited Successfully");
                setCourse(prev => prev.map(t => t.id === data.id ? data : t));
                reset({

                    name: "",
                    durationInMonths: 1,
                    minimumRequiredAge: 10
                })
                return;
            }
            else {
                const res = await axiosInstance.post('/Course/Add', data);
                setCourse(prev => [...prev, data])

                console.log(res.data);
                reset();
                return;
            }


        } catch (err: any) {
            if (err.response?.status === 401) {
                setApiError('Invalid credentials');
            } else {
                setApiError('Something went wrong. Please try again!.');
            }
        }
    };

    return (
        <div className='my-5 px-2 d-flex'>
            <div className='w-50 px-5'>
                <Form
                    className='w-75 p-5 m-auto border rounded shadow-lg'
                    onSubmit={handleSubmit(formSubmit)}
                >
                     <FormGroup className='mb-3'>
                        <FormLabel>Created Date<span className='text-danger'>*</span></FormLabel>
                        <FormControl type='datetime' {...register('createdOn')} className='form-control p-2' isInvalid={!!errors.createdOn} value={new Date().toLocaleDateString()} disabled/>
                        <FormControl.Feedback type='invalid'>
                            {errors.createdOn?.message}
                        </FormControl.Feedback>
                    </FormGroup>

                    <FormGroup className='mb-3'>
                        <FormLabel>Name<span className='text-danger'>*</span></FormLabel>
                        <FormControl type='name' {...register('name')} className='form-control p-2' isInvalid={!!errors.name} />
                        <FormControl.Feedback type='invalid'>
                            {errors.name?.message}
                        </FormControl.Feedback>
                    </FormGroup>

                    <FormGroup className='mb-3'>
                        <FormLabel>duration In Months<span className='text-danger'>*</span></FormLabel>
                        <FormControl
                            type='number'
                            {...register('durationInMonths')}
                            className='form-control p-2'
                            isInvalid={!!errors.durationInMonths}
                        />
                        <FormControl.Feedback type='invalid'>
                            {errors.durationInMonths?.message}
                        </FormControl.Feedback>
                    </FormGroup>
                    <FormGroup className='mb-3'>
                        <FormLabel>minimum Required Age<span className='text-danger'>*</span></FormLabel>
                        <FormControl
                            type='number'
                            {...register('minimumRequiredAge')}
                            className='form-control p-2'
                            isInvalid={!!errors.minimumRequiredAge}
                        />
                        <FormControl.Feedback type='invalid'>
                            {errors.minimumRequiredAge?.message}
                        </FormControl.Feedback>
                    </FormGroup>

                    {apiError && <p className='text-danger'>{apiError}</p>}

                    <Button type="submit" className="btn btn-primary mt-2">{(currentId && currentId > 0) ? "Update ToDo" : "Add ToDo"}</Button>
                </Form>
            </div>
            <div className='w-50'>
                <Table className='table table-bordered table-striped table-hover table-responsive table-dark w-100'>
                    <thead>
                        <tr>
                            <th>Course Id</th>
                            <th>Course Name</th>
                            <th>Duration in Months</th>
                            <th>Starting Date</th>
                            <th>Age</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {course.map((a, index) => (
                            <tr key={index}>
                                <td>{a.id}</td>
                                <td>{a.name}</td>
                                <td>{a.durationInMonths}</td>
                                <td>{new Date("06-03-2026").toLocaleString()}</td>
                                <td>{a.minimumRequiredAge}</td>
                                <td>
                                    <Button className='mx-2 bg-warning' onClick={() => editCourse(a)}>Edit</Button>
                                    <Button className='mx-2 bg-danger' onClick={() => deleteCourse(a)}>Delete</Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            </div>
        </div>
    );
};

export default CourseManagement;

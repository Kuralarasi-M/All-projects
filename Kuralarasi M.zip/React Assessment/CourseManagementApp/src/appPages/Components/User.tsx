import React, { useEffect, useState } from 'react'
import registerSchema from '../../shemas/registerSchema';
import type z from 'zod';
import { Form } from 'react-router-dom';
import axiosInstance from '../../authenticationApi/api';
import { Button, FormCheck, FormControl, FormGroup, FormLabel, Table } from 'react-bootstrap';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
export type UserData = z.infer<typeof registerSchema>;
const User = () => {
    const [user, setUser] = useState<UserData[]>([]);

    const [apiError, setApiError] = useState('');
    const [action] = useState('Login');
    useEffect(() => {

        axiosInstance.get("/User/GetUsers")
            .then((res) => {
                console.log(res.data);
                setUser(res.data);
            })
            .catch((err) => {
                console.error("Error fetching:", err);

            });
    }, []);

    const { register, handleSubmit, formState: { errors }, reset } = useForm<UserData>({
        resolver: zodResolver(registerSchema),
        defaultValues: {
            name: "",
            email: '',
            password: '',
            dob: "",
            phoneNumber: "",

        }
    });
    const editUser = (data: UserData) => {
        reset(data);

    }
    const formSubmit = async (data: UserData) => {
        console.log("Form submitted!", data);
        setApiError('');

        try {

            const res = await axiosInstance.post("/User/Create", data);
            console.log(res.data);

        } catch (err: any) {
            if (err.response?.status === 401) {
                setApiError('Invalid credentials');
            } else {
                setApiError('Something went wrong. Please try again!.');
            }
        }
        const deleteUser = (data: UserData) => {
            try {
                if (window.confirm("Are you want to Delete?")) {
                    axiosInstance.delete(`/Course/Delete/${data.id}`);
                    setUser(pre => pre.filter(s => s.id != data.id))
                }

            }
            catch (err) {
                console.error("Error fetching:", err);
            }
        }
  return (
    <div>
       <div>
         <div className='m-5'>
                        <Form
                            className='w-25 p-5 m-auto border rounded shadow-lg'
                            onSubmit={handleSubmit(formSubmit)}
                        >
                            <h3 className='text-center mb-4'>{action}</h3>
                            <FormGroup className='mb-3'>
                                <FormLabel>Name<span className='text-danger'>*</span></FormLabel>
                                <FormControl type='name' {...register('name')} className='form-control p-2' isInvalid={!!errors.name} />
                                <FormControl.Feedback type='invalid'>
                                    {errors.name?.message}
                                </FormControl.Feedback>
                            </FormGroup>
                            <FormGroup className='mb-3'>
                                <FormLabel>Email<span className='text-danger'>*</span></FormLabel>
                                <FormControl type='email' {...register('email')} className='form-control p-2' isInvalid={!!errors.email} />
                                <FormControl.Feedback type='invalid'>
                                    {errors.email?.message}
                                </FormControl.Feedback>
                            </FormGroup>

                            <FormGroup className='mb-3'>
                                <FormLabel>Password<span className='text-danger'>*</span></FormLabel>
                                <FormControl
                                    type='password'
                                    {...register('password')}
                                    className='form-control p-2'
                                    isInvalid={!!errors.password}
                                />
                                <FormControl.Feedback type='invalid'>
                                    {errors.password?.message}
                                </FormControl.Feedback>
                            </FormGroup>
                            <FormGroup className='mb-3'>
                                <FormLabel>DOB<span className='text-danger'>*</span></FormLabel>
                                <FormControl
                                    type='date'
                                    {...register('dob')}
                                    className='form-control p-2'
                                    isInvalid={!!errors.dob}

                                />
                                <FormControl.Feedback type='invalid'>
                                    {errors.dob?.message}
                                </FormControl.Feedback>
                            </FormGroup>
                            <FormGroup className='mb-3'>
                                <FormLabel>Phone Number<span className='text-danger'>*</span></FormLabel>
                                <FormControl
                                    type='number'
                                    {...register('phoneNumber')}
                                    className='form-control p-2'
                                    isInvalid={!!errors.phoneNumber}

                                />
                                <FormControl.Feedback type='invalid'>
                                    {errors.phoneNumber?.message}
                                </FormControl.Feedback>
                            </FormGroup>
                            <FormCheck type="checkbox"
                                label="isActive"
                                {...register("isActive")}
                            />
                            <FormCheck type="checkbox"
                                label="isAdmin"
                                {...register("isAdmin")}
                            />
                            {apiError && <p className='text-danger'>{apiError}</p>}

                            <Button type='submit' className='m-4'>Submit</Button>
                        </Form>
                    </div>
                    <div className='w-50'>
                    <Table className='table table-bordered table-striped table-hover table-responsive table-dark w-100'>
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Password</th>
                                <th>PhoneNo</th>
                                <th>DOB</th>
                                <th>IsActive</th>
                                <th>IsAdmin</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {user.map((a, index) => (
                                <tr key={index}>
                                    <td>{index}</td>
                                    <td>{a.name}</td>
                                    <td>{a.email}</td>
                                    <td>{a.password}</td>
                                    <td>{a.phoneNumber}</td>
                                    <td>{a.dob}</td>
                                    <td>{(a.isActive == true) ? "yes" : "no"}</td>
                                    <td>{(a.isAdmin == true) ? "yes" : "no"}</td>
                                    <td>
                                        <Button className='mx-2 bg-warning' onClick={() => editUser(a)}>Edit</Button>
                                        <Button className='mx-2 bg-danger' onClick={() => deleteUser(a)}>Delete</Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </div>
            </div>
       </div>
    
  )
}
}
export default User;

import React from 'react'

const DashBoard = () => {
    return (
        <div>
            <h1>DashBoard</h1>
        </div>
    )
}

export default DashBoard;

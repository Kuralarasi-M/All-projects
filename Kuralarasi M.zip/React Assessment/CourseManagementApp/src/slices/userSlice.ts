import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { UserData } from "../appPages/Components/Login";

interface UserState {
  User: UserData[];
  
}

const initialState: UserState = {
  User: [],
 
};

export const userSlice = createSlice({
  name: "Users",
  initialState,
  reducers: {
    setUsers: (state, action: PayloadAction<UserData[]>) => {
      state.User = action.payload;
    },
   
  },
});

export const { setUsers} = userSlice.actions;
export default userSlice.reducer;

import { Link, Route, Routes } from 'react-router-dom'
import './App.css'
import Login from '../src/appPages/Components/Login'
import DashBoard from '../src/appPages/Components/Login';
import User from './appPages/Components/User';
import CourseManagement from './appPages/Components/CourseManagement';
import NavBar from './appPages/Components/NavBar';
import Home from './appPages/Components/Home';
import Footer from './appPages/Components/Footer';
function App() {
  
  
  return (
    <>
    <NavBar></NavBar>
      <Routes>
        <Route path="/"  element={<Login/>}/>
        <Route path="/home"  element={<Home/>}/>
        <Route path="/dashboard" element={<DashBoard/>} />
        
        <Route path="/user"  element={<User/>}/>
        <Route path="/course" element={<CourseManagement/>} />
      </Routes>
    <Footer></Footer>
    </>
  )
}

export default App

import {z} from "zod"
export const schema = z.object({
    name:z.string().nonempty("Name is Required!.").regex(/^[a-zA-Z ]{3,}$/,"Minimum 3 characters Required"),
    email:z.string().nonempty("Email is Required"),
   
    dob:z.string().nonempty("Select your DOB.")
     .refine(date => new Date(date)< new Date(),"Date doesn't be in future")
     .refine(date => {
        const today=new Date();
        const userData=new Date(date);
        const age= today.getFullYear()-userData.getFullYear();
        const isBirthdayPassed = today.getMonth>userData.getMonth || today.getMonth === userData.getMonth && today.getDate > userData.getDate
        return isBirthdayPassed ? age>=5 : age-1 >=5
     },"Age must be 5 or above!."),

    age:z.string(),
    enrollmentDate:z.string().nonempty("Date is Required"),
    phoneNo:z.string().nonempty("Phone no Required"),
    course:z.string().nonempty("Must Select one Course"),
   photo:z.object().optional(),
    status:z.enum(["Active","Inactive"],"select status")
    
     
})



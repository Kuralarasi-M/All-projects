
import './App.css'
import StudentForm from './StudentForm'

function App() {
  

  return (
    <>
      <div>
        
        <StudentForm></StudentForm>
      </div>
       
    </>
  )
}

export default App

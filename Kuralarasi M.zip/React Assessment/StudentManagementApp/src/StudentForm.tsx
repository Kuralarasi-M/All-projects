import React, { useCallback, useEffect, useRef, useState } from 'react'
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import {useForm} from "react-hook-form";
import { schema } from './schema';
import { date, file, nullable, number, string, z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import FormLabel from 'react-bootstrap/esm/FormLabel';
import StudentTable from './StudentTable';
import { omit } from 'zod/v4-mini';
import NavBar from './NavBar';
import { FormControl } from 'react-bootstrap';

export type studentType= z.infer<typeof schema>;
  export type userType={
     id:number,
    name:string,
        email:string,
        age:string,
        enrollmentDate:string,
        dob:string;
        phoneNo:string,
        photo:undefined,
        status:string,
        course:string
  }
const StudentForm = () => {
  const [studentData,setStudentData] = useState<userType[]>([]);
  const [filterData,setFilterData] = useState<userType[]>([]);
 const [startDate,setStartDate] = useState("");
  const [endDate,setEndDate] = useState("");
   const [enrollStart,setEnrollStart] = useState("");
  const [enrollEnd,setenrollEnd] = useState("");
  const [nextId,setNextId] = useState(1);
   const [editId,setEditId] = useState<number| null>(null);
   const [studentName,setStudentName] = useState("");
  const {register,handleSubmit,formState:{errors},reset} = useForm<studentType>({
     resolver:zodResolver(schema),
     defaultValues:{
        name:"",
        email:"",
        age:"",
        enrollmentDate:"",
        phoneNo:"",
        photo:undefined,
        status:undefined,
        course:""
     }
  });

  const submitHandle = (data:userType) => {
   if(editId==null){
       const user={...data,id:nextId}
    setStudentData(prev => [...prev,user]);
     console.log(data);
     setNextId(prev => prev+1);
      reset();
   }
    else{
        
          setStudentData(prev => prev.map(a => (a.id ==editId ? {...a,...data,Id:editId} :a)));
          setEditId(null);
          reset();
      } 
    }
  
    useEffect(()=>{
     if(studentData.length>0){
      localStorage.setItem("users",JSON.stringify(studentData));
      localStorage.setItem("nextId",JSON.stringify(nextId))
     }
  },[studentData,nextId])

  useEffect(()=>{
       const user=localStorage.getItem("users");
       const id=localStorage.getItem("nextId")
       if (user != null) {
         setStudentData(JSON.parse(user))
  }
      
      if(id!=null){
        setNextId(JSON.parse(id))
      }
       
  },[])
  
  const updateStudent= useCallback(  
   (student:userType) => {
      setEditId(student.id);
      console.log(student);
      reset(student);
   },[studentData,setEditId])
  
   const deleteStudent= (student:userType) => {
      setStudentData(prev => prev.filter(s => s.id!=student.id))
   }
    const searchByName = ()=>{
        setFilterData(studentData)
        setStudentData(prev => prev.filter(s => s.name.includes(studentName)))
    }
    
    const resetData = () => {
       setStudentData(filterData)
    }

    const dobSearch = () => {
       setFilterData(studentData)
         const start=new Date(startDate);
         const end=new Date(endDate);
          setStudentData(prev => prev.filter(s => new Date(s.dob)> start && new Date(s.dob) < end))
    }
    const enrollSearch = () => {
       setFilterData(studentData)
         const start=new Date(enrollStart);
         const end=new Date(enrollEnd);
          setStudentData(prev => prev.filter(s => new Date(s.enrollmentDate)> start && new Date(s.enrollmentDate) < end))
    }
    const sortByName = () => {
      
      setFilterData(studentData)
       setStudentData(prev => prev.sort((a,b) => a.name.localeCompare(b.name)))
      
    }
    const sortByNameDes = () => {
     
       setFilterData(studentData)
       setStudentData(prev => prev.sort((a,b) => b.name.localeCompare(a.name)))
      
    }
     const sortByDOB = () => {
      
      setFilterData(studentData)
       setStudentData(prev => prev.sort((a,b) => a.dob.localeCompare(b.dob)))
      
    }
     const sortByDOBDes = () => {
      
      setFilterData(studentData)
       setStudentData(prev => prev.sort((a,b) => b.dob.localeCompare(a.dob)))
    
    }
     const sortByEnrollDate = () => {
      
      setFilterData(studentData)
       setStudentData(prev => prev.sort((a,b) => a.enrollmentDate.localeCompare(b.enrollmentDate)))
      
    }
     const sortByEnrollDateDes = () => {
      
      setFilterData(studentData)
       setStudentData(prev => prev.sort((a,b) => b.enrollmentDate.localeCompare(a.enrollmentDate)))
    
    }
  return (
   <div>
       <NavBar></NavBar>
       <div className='m-3'>
          <h1 className='text-center'>Student Dashboard</h1>
       </div>
        <div className=" mx-5 d-flex">
       <Form onSubmit={handleSubmit(submitHandle)} className='border p-5 w-25 m-auto' >
           <Form.Group className='m-1'>
               <Form.Label>Name</Form.Label>
                  <Form.Control type="text" {...register("name")} isInvalid={!!errors.name} />
                  <Form.Control.Feedback type="invalid">{errors.name?.message}</Form.Control.Feedback>
           </Form.Group>
           <Form.Group>
              <Form.Label>Email</Form.Label>
              <Form.Control type="email"  {...register("email")} isInvalid={!!errors.email}/>
              <Form.Control.Feedback type="invalid">{errors.email?.message}</Form.Control.Feedback>
           </Form.Group>
            <Form.Group>
              <Form.Label>DOB</Form.Label>
              <Form.Control type="date"  {...register("dob")} isInvalid={!!errors.dob}/>
              <Form.Control.Feedback type="invalid">{errors.dob?.message}</Form.Control.Feedback>
           </Form.Group>
            <Form.Group>
              <Form.Label>Course</Form.Label>
              <Form.Select {...register("course")} isInvalid={!!errors.course}>
                <option value="">---Select---</option>
                <option value="Bio-Maths">Bio-Maths</option>
                <option value="Computer-Maths">Computer-Maths</option>
                <option value="Commerce">Commerce</option>
                <option value="Pure-Science ">Pure-Science</option>
              </Form.Select>
              {errors.course && <small className='text-danger '>{errors.course.message}</small>}
           </Form.Group>
            <Form.Group>
              <Form.Label>EnrollmentDate</Form.Label>
              <Form.Control type="date"  {...register("enrollmentDate")} isInvalid={!!errors.enrollmentDate}/>
              <Form.Control.Feedback type="invalid">{errors.enrollmentDate?.message}</Form.Control.Feedback>
           </Form.Group>
           <Form.Group>
              <Form.Label>Phone Number</Form.Label>
              <Form.Control type="number"  {...register("phoneNo")} isInvalid={!!errors.phoneNo} />
              <Form.Control.Feedback type="invalid">{errors.phoneNo?.message}</Form.Control.Feedback>
           </Form.Group>
            {/* <Form.Group>
              <Form.Label>Status</Form.Label>
              
                <Form.Check type="radio" label="Active"  value="active" {...register("status")} isInvalid={!!errors.status} ></Form.Check>
               <Form.Check type="radio" label="Inactive"  value="Inactive" {...register("status")} isInvalid={!!errors.status} ></Form.Check>
            </Form.Group>
            <Form.Control.Feedback type="invalid">{errors.status?.message}</Form.Control.Feedback> */}
            <Form.Group className="mb-3">
           <Form.Label>Status</Form.Label>
           <Form.Check type="radio" value="Active" label="Active" {...register("status")}>
           </Form.Check>
           <Form.Check type="radio" value="Inactive" label="Inactive" {...register("status")} ></Form.Check>
          
           {errors.status && <p className="text-danger">{errors.status.message}</p>}
        </Form.Group>
           <Form.Group className="mb-3">
              <Form.Label>Photo</Form.Label>
              <Form.Control type="file"  {...register("photo")} isInvalid={!!errors.photo}/>
              {/* <Form.Control.Feedback type="invalid">{errors.photo?.message}</Form.Control.Feedback> */}
           </Form.Group>
           <Button type="submit">Submit</Button>
       </Form>
       <div>
          <div className='d-flex mx-2'>
              <div className='d-flex mx-2'>
               <Form.Control type="text" value={studentName} onChange={s => setStudentName(s.target.value)} placeholder='search by name' />
               <Button onClick={searchByName} className=' mx-2'>Search</Button>
               <Button onClick={resetData} className='bg-success mx-2'>Reset</Button>
              </div>
            <div className='d-flex flex-column mb-2'>
                <div>
                    <Button onClick={sortByName} className='bg-light text-dark '>sortBy Name</Button>
                    <Button onClick={sortByNameDes}  className='bg-light text-dark '>sortby NameDes</Button>
                    <Button onClick={sortByDOB} className='bg-light text-dark'>sortBy DOB</Button>
                    <Button onClick={sortByDOBDes} className='bg-light text-dark '>sortby DOBDes</Button>
                    <Button onClick={sortByEnrollDate } className='bg-light text-dark '>sortBy Enroll</Button>
                    <Button onClick={sortByEnrollDateDes } className='bg-light text-dark '>sortby EnrollDes</Button>
                </div>
                <div>
                     
                </div>
                 <div>
                     
                </div>
                 
            </div>
          </div>
          
         <div className='d-flex m-2'>
            <div className='border p-2 m-4 text-center'>
               <p>Filter by DOB</p>
                 <div  className='d-flex mx-2'>
                <Form.Control type="date" value={startDate} onChange={s => setStartDate(s.target.value)} placeholder='select Starting date' />
                <Form.Control type="date" value={endDate} onChange={s => setEndDate(s.target.value)} placeholder='select Ending date' />
                 <Button onClick={dobSearch} className=' mx-2'>Search</Button>
                 <Button onClick={resetData} className='bg-success mx-2'>Reset</Button>
            </div>
            </div>
           <div className='border p-2 m-4 text-center'>
               <p>Filter by Enrollment</p>
                <div  className='d-flex mx-2'>
                <Form.Control type="date" value={enrollStart} onChange={s => setEnrollStart(s.target.value)} placeholder='select Starting date' />
                <Form.Control type="date" value={enrollEnd} onChange={s => setenrollEnd(s.target.value)} placeholder='select Ending date' />
                 <Button onClick={enrollSearch} className=' mx-2'>Search</Button>
                 <Button onClick={resetData} className='bg-success mx-2'>Reset</Button>
            </div>
           </div>
            
         </div>
         <StudentTable mystudentData={studentData} updateStudent={updateStudent} deleteStudent={deleteStudent}></StudentTable>
       </div>
       
       
    </div>
   </div>
    
  )
}

export default StudentForm

import './App.css'
import Home from './Home/Home.tsx'

function App() {
  
  return (
    <>
      <Home></Home>
     
    </>
  )
}

export default App

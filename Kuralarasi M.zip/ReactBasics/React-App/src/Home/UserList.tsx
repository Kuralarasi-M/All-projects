import type{User} from './Home';

type Props= {
    users:User[];
    deleteUser:(DeleteUser:number) => void
    resetUser:(ResetUser:number) => void
}
function UserList({users,deleteUser,resetUser}:Props){
    
    return (
        <>
        <p>Registered User</p>
           <div>
               {users.length === 0 ? (
                  <p>No Data is Available</p> ) : (
                   users.map(user => !user.isDeleted && (
                   <div key={user.id} className='p-3 m-2 border rounded w-50 bg-primary text-white'>
                       <p>{user.id}</p>
                       <p>{user.name}</p>
                        <p>{user.email}</p>
                         <p>{user.password}</p>
                        <p>{user.location}</p>
                        <p>{user.phone}</p>
                    <div>
                    <button onClick={() => deleteUser(user.id)} className='bg-danger p-2 rounded'>Delete</button>
                    
                    
                </div>
            </div>
                )
           )
        )}
          </div>
     
                
            <p>Deleted User</p>
               <div>
               {users.length === 0 ? (
                  <p>No Data is Available</p> ) : (
                   users.map(user => user.isDeleted && (
                   <div key={user.id} className='p-3 m-2 border rounded w-50 bg-primary text-white'>
                       <p>{user.id}</p>
                       <p>{user.name}</p>
                        <p>{user.email}</p>
                         <p>{user.password}</p>
                        <p>{user.location}</p>
                        <p>{user.phone}</p>
                    <div>
                    <button onClick={() => resetUser(user.id)} className='bg-warning p-2 rounded'>Reset</button>
                    
                    
                </div>
            </div>
                )
           )
        )}
          </div>
              
        </>
    )
}

export default UserList;
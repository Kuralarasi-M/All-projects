// import { useState } from "react";
import { useState } from "react";
import ResForm from "./Form.tsx";
import UserList from "./UserList.tsx"
export type User={
   id:number,
   name:string,
   password:string,
   email:string,
   location:string,
   phone:number
   isDeleted:number
}
function Home(){
     const [nextId,setNextId] = useState(1);
     const [user, setUser] = useState<User[]>([]);
    const AddUser = (user:Omit<User,"id"|"isDeleted">) => {
       const newUser= {...user,id:nextId,isDeleted:0}
       setUser(prev => [...prev,newUser]) ;
       setNextId(prev=> prev+1)
    }
    const DeleteUser = (id: number) => {
    setUser(prev =>
        prev.map(user =>
            user.id === id ? { ...user, isDeleted: 1 } : user
        )
    );
    
  }
  const ResetUser = (id: number) => {
    setUser(prev =>
        prev.map(user =>
            user.id === id ? { ...user, isDeleted: 0} : user
        )
    )};
    return(
        <>
          <div className="d-flex">
            
              <div className="w-50">
                <div>
                  <ResForm AddUser={AddUser}></ResForm>
                </div>
                
              </div>
               <div className="w-50">
                
                 <div>
                    <UserList users={user} deleteUser={DeleteUser} resetUser={ResetUser}></UserList>
                    
                 </div>
           
              </div> 
            
              
          </div>
          
          {/* <h1>{count}</h1> 
          <button onClick={() => setCount(count+1)}>Add Count</button> */}
        </>
    )
        
}
export default Home;
import { useRef, useState } from "react";
import type { User } from "./Home";

type Props={
  AddUser: (user:Omit<User, "id" |"isDeleted">) => void;
}
// export type User={
//    name:string,
//    password:string,
//    email:string,
//    location:string,
//    phone:number
// }
function Form({AddUser}:Props) {
 
 
  const [name,setName] = useState("");
  const [email,setEmail] = useState("");
  const [phone,setPhone] = useState(0);
  const [password,setPassword] =useState("");
  const [location,setLocation] = useState("");
 
  
 
  const addContact = (e: React.FormEvent) => {
    e.preventDefault();
    

    if (!name || !email || !password || !location) {
        alert("Fill the form!.")
        return ;
    }
     AddUser({name,password,email,location,phone})
  };

  return (
    <div>
      <form
        onSubmit={addContact}
        className="border p-5 d-flex flex-column gap-3 w-50 justify-content-center align-items-center bg-primary text-white"
      >
        <h3>Registration Form</h3>

        <label>Name:</label>
        <input  type="text" className="form-control" onChange={e => setName(e.target.value)}/>
         <p ></p>
        <label>Email:</label>
        <input type="email" className="form-control" onChange={e  => setEmail( e.target.value)} />

        <label>Password:</label>
        <input type="password" className="form-control" onChange={e => setPassword( e.target.value)} />

        <label>Phone:</label>
        <input type="number" className="form-control" onChange={e => setPhone(Number(e.target.value))} />

        <label>Location:</label>
        <select value={location} className="form-select" onChange={e => setLocation(e.target.value)}>
          <option value="Chennai">Chennai</option>
          <option value="Coimbatore">Coimbatore</option>
          <option value="Perambalur">Perambalur</option>
          <option value="Kanchipuram">Kanchipuram</option>
        </select>

        <button type="submit" className="btn btn-primary mt-3 p-2 bg-success">
          Submit
        </button>
      </form>

      
      </div>
  );
}

export default Form;



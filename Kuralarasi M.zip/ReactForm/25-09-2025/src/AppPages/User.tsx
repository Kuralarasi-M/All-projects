import React from 'react'

const User = () => {
  return (
    <div>
       <h1>User</h1>
    </div>
  )
}

export default User

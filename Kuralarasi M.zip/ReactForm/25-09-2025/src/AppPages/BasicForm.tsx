

import { use, useEffect, useState, type FormEvent } from "react";
import Button from "react-bootstrap/Button";
import {unknown, z} from "zod";
import {Controller, useForm} from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import Form from "react-bootstrap/Form";
import schema from "../schema";
import { FormControl, FormGroup, Table } from "react-bootstrap";
import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";
import UserTable from "./UserTable";


export type UserDataType ={
  Id:number
  name: string;
    email: string;
    password: string;
    age: 0;
    country: string;
    skills: string[];
    dob: "";
    joiningPeriod: [Date | null, Date | null];
    phone?: 0;
    gender?:  "Male" | "Female" | "Other";
}

export type myFormData = z.infer<typeof schema>
const BasicForm = () => {
  const [userData,setUserData] = useState<UserDataType[]>([]);
  const [nextId,setNextId]= useState(1);
  const [editId,setEditId]= useState<number | null>(null);
  const {control,register,handleSubmit,formState : {errors},reset} = useForm<myFormData>({
    resolver:zodResolver(schema),
    defaultValues:{
      name:"",
      email:"",
      password:"",
      phone:undefined,
      age:0,
      country:"",
      skills:[],
      gender:undefined,
      dob:"",
      joiningPeriod: [null, null]
    }
  });
  const formSubmit = (data:myFormData)=> {
      if(editId==null){
           const user:UserDataType={...data,Id:nextId}
        setUserData(prev => [...prev,user])
        setNextId((prev) => prev + 1);
        reset();
      }
      else{
          setUserData(prev => prev.map(a => (a.Id ==editId ? {...a,...data,Id:editId} :a)));
          setEditId(null);
          reset();
      } 
   
  }
  useEffect(()=>{
     if(userData.length>0){
      localStorage.setItem("users",JSON.stringify(userData));
      localStorage.setItem("nextId",JSON.stringify(nextId))
     }
  },[userData,nextId])

  useEffect(()=>{
       const user=localStorage.getItem("users");
       const id=localStorage.getItem("nextId")
       if (user != null) {
         setUserData(JSON.parse(user))
  }
      
      if(id!=null){
        setNextId(JSON.parse(id))
      }
       
  },[])

  const updateUser = (user:UserDataType) => {
      setEditId(user.Id);
      reset({
    name: user.name,
    email: user.email,
    password: user.password,
    age: user.age,
    country: user.country,
    skills: user.skills,
    dob: user.dob,
    joiningPeriod: user.joiningPeriod,
    phone: user.phone,
    gender: user.gender as "Male" | "Female" | "Other" | undefined
  });
  }
  return (
    <div>
      <h1>Form</h1>
      <Form className='w-50 m-auto border p-5 rounded' onSubmit={handleSubmit(formSubmit)}>
        <Form.Group className='mb-2' controlId='name'>
            <Form.Label>Name </Form.Label>
             <Controller
                name="name"
                control={control}
                render={({field}) => (
                  <FormControl type="text" {...field} isInvalid={!!errors.name} />
                )}

             />
             <FormControl.Feedback type="invalid" >{errors.name?.message}</FormControl.Feedback>
        </Form.Group>
        <FormGroup>
          <Form.Label>Email</Form.Label>
          <FormControl type="email" {...register("email")} isInvalid={!!errors.email} />
          <Form.Control.Feedback type="invalid">{errors.email?.message}</Form.Control.Feedback>
        </FormGroup>
        
        <Form.Group>
            <Form.Label>Password</Form.Label>
            <Form.Control type="password" placeholder='Enter the Password' {...register("password")} isInvalid={!!errors.password}/>
            <Form.Control.Feedback type="invalid">{errors.password?.message}</Form.Control.Feedback>
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Phone</Form.Label>
          <Form.Control type="number" placeholder="enter your mobile no" {...register("phone",{ valueAsNumber: true })} isInvalid={!!errors.email} />
          <Form.Control.Feedback type="invalid">{errors.phone?.message}</Form.Control.Feedback>
        </Form.Group> 
        <Form.Group className="mb-3">
          <Form.Label>Age</Form.Label>
          <Form.Control type="number" {...register("age", { valueAsNumber: true })} isInvalid={!!errors.age} />
          <Form.Control.Feedback type="invalid">{errors.age?.message}</Form.Control.Feedback>
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Country</Form.Label>
          <Form.Select {...register("country")} isInvalid={!!errors.country}>
            <option value="">---Select Country---</option>
            <option value="India">India</option>
            <option value="USA">USA</option>
            <option value="France">France</option>
          </Form.Select>
          <Form.Control.Feedback type="invalid">{errors.country?.message}</Form.Control.Feedback>
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Skills</Form.Label>
          <Form.Select multiple {...register("skills")} isInvalid={!!errors.skills}>
             
             <option value="HTML">HTML</option>
             <option value="CSS">CSS</option>
             <option value="JS">JS</option>
          </Form.Select>
          <Form.Control.Feedback type="invalid">{errors.skills?.message}</Form.Control.Feedback>
        </Form.Group>
        <Form.Group className="mb-3">
           <Form.Label>Gender</Form.Label>
           <Form.Check type="radio" value="Male" label="Male" {...register("gender")}>
           </Form.Check>
           <Form.Check type="radio" value="Female" label="Female" {...register("gender")} ></Form.Check>
           <Form.Check type="radio" value="Other" label="Other" {...register("gender")} ></Form.Check>
           {errors.gender && <p className="text-danger">{errors.gender.message}</p>}
        </Form.Group>
        <Form.Label>DOB</Form.Label>
         <Controller
            name="dob"
            control={control}
            render={({ field }) => {
              const selectedDate = field.value ? new Date(field.value) : null;
              return(
            <DatePicker
                selected={selectedDate}
                onChange={(date: Date | null) => field.onChange(date)}
                dateFormat="yyyy-MM-dd"
                placeholderText="Select your Date of Birth"
                className="form-control" 
               
            />
              )
            }}
          
           />
           {errors.dob && <p className="text-danger">{errors.dob.message}</p>}
            <Controller
          name="joiningPeriod"
          control={control}
         
          render={({ field }) => (
            <DatePicker
              selectsRange
              startDate={field.value?.[0]}
              endDate={field.value?.[1]}
              onChange={(dates) => field.onChange(dates)}
              isClearable
              placeholderText="Select joining period"
              className="form-control"
            />
          )}
        />
        {errors.joiningPeriod && (
          <p className='text-danger'>{errors.joiningPeriod.message as string}</p>
        )}
        <Button type="submit">{editId != null ? "Update" : "Add User"}</Button>
      </Form>
      <ul>
        {userData && userData.map(a => 
            <div>
              <li>{a.name}</li>
             <li>{a.email}</li>
              <li>{a.password}</li>
              <li>{a.phone}</li>
              <li>{a.age}</li>
              <li>{a.country}</li>
              <li>{a.skills.join(',')}</li>
            </div>
          )}
         </ul>
        <UserTable myuserData={userData} updateUser={updateUser}></UserTable>
    </div>
  )
}

export default BasicForm

import React from 'react'
import { Button, Table } from 'react-bootstrap'
import type {  myFormData, UserDataType } from './BasicForm'

type Props={
  myuserData:UserDataType[],
  updateUser:(user:UserDataType)=> void
}
const UserTable = ({myuserData,updateUser}:Props) => {
  return (
    <div>
      <div>
            <Table>
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Password</th>
                  <th>Gender</th>
                    <th>Age</th>
                  <th>DOB</th>
                  <th>Skills</th>
                  <th>Country</th>
                  <th>Joining Date</th>
                  <th>Phone</th>
                  <td>Action</td>
                  
                </tr>
              </thead>
               <tbody>
  {myuserData.map((a, index) => (
    <tr key={index}>
      <td>{a.Id}</td>
      <td>{a.name}</td>
      <td>{a.email}</td>
      <td>{a.password}</td>
      <td>{a.gender ?? "-"}</td>
      <td>{a.age}</td>
    <td>{a.dob ? new Date(a.dob).toLocaleDateString() : "-"}</td>
     <td>{a.skills.join(", ")}</td>
      <td>{a.country}</td>
      <td>
  {a.joiningPeriod[0] ? new Date(a.joiningPeriod[0]).toLocaleDateString() : "-"}
  {" - "}
  {a.joiningPeriod[1] ? new Date(a.joiningPeriod[1]).toLocaleDateString() : "-"}
</td>

      <td>{a.phone ?? "-"}</td>
     <td>
      <Button className='bg-warning mx-2' onClick={() => updateUser(a)}>Update</Button>
      <Button className='bg-danger'>Delete</Button>
     </td>
    </tr>
    
  ))}
</tbody>

            </Table>
         </div>
    </div>
  )
}

export default UserTable


import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import Home from "./AppPages/Home";
import User from "./AppPages/User";
import Form from "./AppPages/BasicForm";
import About from "./AppPages/About";
import { Navbar } from 'react-bootstrap';
import NavBar from './NavBar';
function App() {
  

  return (
    <>
      <div>
        
       
        <NavBar></NavBar>
          <Routes>
              <Route path="/" element={<Home />}>Home</Route>
              <Route path="/user" element={<User />}>User</Route>
              <Route path="/form" element={<Form />}>Form</Route>
              <Route path="/about" element={<About />}>About</Route>
              <Route>About</Route>
          </Routes> 
    
          
      </div>
    </>
  )
}

export default App

import React from 'react'
import * as z from "zod"

const schema= z.object({
    name:z.string().nonempty("Name is Required!."),
    email:z.string().nonempty("Email is required!."),
    password:z.string().nonempty("Password is required!.")
    .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&*])(?=.*\d)[a-zA-Z\d@#$%^&*]{8,}$/,{message:"Password must have one capital,small,number,special character and length minimum 8."}),
    phone:z.number().optional(),
   age: z.number()
       .refine(val => !isNaN(val), { message: "Age is required" })
       .min(18, "Age must be 18 or above")
       .max(100, "Age must be less than 100").optional(),

    country:z.string().min(1,"Select your Country!."),
    skills:z.array(z.string()).min(1,"Select atleast one skill"),
    // gender: z.enum(["Male", "Female", "Other"])
    //      .refine(val => !!val, { message: "Please select your gender" }),
   
   gender: z.enum(["Male", "Female", "Other"]).optional()
       .refine(val => val !== undefined, { message: "Please select your gender" }),
   dob:z.string().optional(),
     joiningPeriod: z.tuple([z.date().nullable(), z.date().nullable()])
  .refine(([start, end]) => {

    if (!start || !end) return true; 
    return end >= start; 
  }, {
    message: "End date must be after start date",
    path: ["joiningPeriod"]
  })

  });




export default schema;
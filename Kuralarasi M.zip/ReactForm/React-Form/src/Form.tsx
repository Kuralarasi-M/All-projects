import React, { useState } from 'react'
import {useForm} from 'react-hook-form'
const Form = () => {
    const {register,handleSubmit,errors}= useForm()
    const[userInfo,setUserInfo] =useState();
     const [name,setName] = useState("");
     const[isFresher,setIsFresher] = useState(false);
    const[gender,setGender] = useState("");
    const[date,setDate]=useState("");
     const[skills,setSkills] = useState<{[key:string]:boolean}>({
      HTML:false,
      CSS:false,
      JS:false});
     const [department,setDepartment] = useState("");
     const onSubmit = (data) => {
         setUserInfo(data);
         console.log(data);
         
     }
    const handleFormSubmit = (e:React.FormEvent) => {
        e.preventDefault();
        console.log("name",{name});
        console.log("department",{department});
        
    }
     const handleChange =  (e: React.ChangeEvent<HTMLInputElement>) => {
         const skillName=e.target.name
         const isKnown= e.target.checked
         setSkills(skills => ({...skills,[skillName]:isKnown}))
     }
    
  return (
   
    <div>
      <pre>{JSON.stringify(userInfo,undefined,2)}</pre>
      <form onSubmit={handleSubmit(onsubmit)} className="d-flex flex-column w-50 m-auto border p-5 gap-3">
          <label>Enter your Name:
            <input type="text" value={name} onChange={e => setName(e.target.value)} ></input>
          </label>
          <div>
            <label>Department : </label>
            <select value={department} onChange={s => setDepartment(s.target.value)} ref={register}>
                <option value="HR">HR</option>
                <option value="Integration">Integration</option>
                <option value="Testing">Testing</option>
                <option value="Delevopment">Development</option>
            </select>
          </div>
          <label>Fresher :
            <input type="checkbox" checked={isFresher}  onChange={e => setIsFresher(e.target.checked)} ref={register}>
            </input>
          </label>
          <label>Skills :</label>
           
          <label>HTML:
            <input type="checkbox" name="HTML" checked={skills.HTML} value="fresher" onChange={handleChange} ref={register}>
            </input>
          </label>
          <label> CSS:
            <input type="checkbox"name="CSS" checked={skills.CSS} onChange={handleChange} ref={register}>
            </input>
          </label>
          <label>JS:
            <input type="checkbox" name="JS" checked={skills.JS} value="fresher" onChange={handleChange} ref={register}>
            </input>
          </label>
          <label>Gender:</label>
          <label>Male:
            <input type="radio" name="gender" value="male" checked={gender==="male"} onChange={(e) => setGender(e.target.value)} ref={register}></input>
          </label>
          <label>Female:
            <input type="radio" name="gender" value="female"  checked={gender==="female"} onChange={(e) => setGender(e.target.value)}></input>
          </label>
          <label>DOB:
            <input type="date" value={date} onChange={e => setDate(e.target.value)} ref={register}></input>
          </label>
          
          <input type="submit"></input>
          

      </form>
      <p>{name}</p>
      <p>{department}</p>
      <p>{isFresher ? "true" : "false"}</p>
      <p>Selected Skills:</p>
<ul>
  {Object.entries(skills)
    .filter(([skill, isChecked]) => isChecked)
    .map(([skill]) => (
      <li key={skill}>{skill}</li>
    ))}
</ul>
<p>{gender}</p>
<p>{date}</p>
    </div>
    
  )
}

export default Form

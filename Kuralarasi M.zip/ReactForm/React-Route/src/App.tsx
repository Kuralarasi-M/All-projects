import { BrowserRouter,Routes,Route } from 'react-router-dom'
import './App.css'
import Home from "./Pages/Home"
import User from './Pages/User'
import About from './Pages/About'
import NavBar from './NavBar'
import Users from './Pages/Users'
import Error from './Pages/Error'
function App() {
 

  return (
     <BrowserRouter>
         <NavBar />
         <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/user/:username" element={<Users />} />
            <Route path="user" element={<User/>} />
            <Route path="/about" element={<About />} />
            <Route path="*" element={<Error />} />
         </Routes>
     </BrowserRouter>
  )
}

export default App

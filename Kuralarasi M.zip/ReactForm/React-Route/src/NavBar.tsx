import React from 'react'
import { Container, Nav, Navbar } from 'react-bootstrap'
import { Link } from 'react-router-dom'

const NavBar = () => {
  return (
    <div>
        <Navbar bg="primary" data-bs-theme="dark" expand="lg">
      <Container>
        {/* Brand as Router Link */}
        <Navbar.Brand as={Link} to="/">
          MyApp
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Link  className="nav-link" to="/">Home</Link>
            <Link  className="nav-link" to="/user">User</Link>
            <Link className="nav-link" to="/about">About</Link>

            
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
    </div>
  )
}

export default NavBar



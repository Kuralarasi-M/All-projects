import React from 'react'
import { Table } from 'react-bootstrap'
import { useLocation, useParams } from 'react-router-dom'

const User = () => {
    const location = useLocation();
  // const userData: RegistrationFormData[] = location.state?.userData || [];
  return (
    <div>
        
    </div>
  )
}

export default User

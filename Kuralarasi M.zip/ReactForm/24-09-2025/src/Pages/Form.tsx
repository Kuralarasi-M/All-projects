import React, { useState } from 'react'
import {z}  from "zod"
import {Controller, useForm} from "react-hook-form";
import { zodResolver } from '@hookform/resolvers/zod/src/zod.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Table} from 'react-bootstrap';


 type RegistrationFormData = z.infer<typeof registerationSchema>;
  const registerationSchema = z.object({
     name:z.string()
     .nonempty("Name is required!.")
     .min(3,"Name must have atleast 3 characters."),


     email:z.string()
     .nonempty("Email is required!.")
     .regex(/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/,"Invalid Email."),


     password:z.string()
     .nonempty("Password is required!.")
     .min(8,"Password must have atleast 8 char-length."),

     gender:z.enum(["male","female"],"Select gender."),

     skills:z.array(z.string())
     .min(1,"Select minimum one."),

     dob:z.string().nonempty("Select your DOB.")
     .refine(date => new Date(date)< new Date(),"Date doesn't be in future")
     .refine(date => {
        const today=new Date();
        const userData=new Date(date);
        const age= today.getFullYear()-userData.getFullYear();
        const isBirthdayPassed = today.getMonth>userData.getMonth || today.getMonth === userData.getMonth && today.getDate > userData.getDate
        return isBirthdayPassed ? age>=18 : age-1 >=18
     },"Age must be 18 or above!."),

     isFresher:z.boolean().optional(),

    joiningPeriod: z.tuple([z.date().nullable(), z.date().nullable()])
  .refine(([start, end]) => {

    if (!start || !end) return true; 
    return end >= start; 
  }, {
    message: "End date must be after start date",
    path: ["joiningPeriod"]
  })

  });
const Form = () => {

  


  const {register,handleSubmit,control,formState :{errors},reset} =useForm<RegistrationFormData>({
    resolver:zodResolver(registerationSchema),
    defaultValues: {
        name:"",
        email:"",
        password:"",
        dob:"",
        skills: [], 
        gender:undefined,
       isFresher:false,
       joiningPeriod: [null, null]
  }
  });


  const [userData,setUserData] =useState<RegistrationFormData[]>([]);


  const formSubmit = (data:RegistrationFormData)=>{
     setUserData(prev => [...prev,data])
      console.log("data",data);
     
      reset();
      
  };

  
  return (
    
    <div>
      <h1 className='m-2 text-center text-primary'>Registration Form</h1>
       <form onSubmit={handleSubmit(formSubmit)} className='d-flex flex-column gap-3 w-25 m-auto border rounded p-5'>
           
            <Controller
                name="name"
                control={control}
                render={({field}) => (
                    <div>
                         <label>Name:
                     <input type="text" {...field}  className="form-control p-2 " />
                     </label>
                     {errors.name && <p className='text-danger'>{errors.name?.message}</p>}
                    </div>
                     
                )}
            />
            <Controller
                 name="email"
                 control={control}
                 
                 render={({field}) => (
                  <div>
                    <label>Email
                       <input type='email' {...field}  className="form-control p-2"/>
                    </label>
                    {errors.email && <p className='text-danger'>{errors.email?.message}</p>}
                  </div>

                 )}

             />
            
          
            
             <label>Password:
                <input type="password"  {...register("password")} className="form-control p-2" ></input>
                {errors.password && <p className='text-danger'>{errors.password.message}</p>}
            </label>

            
            <label>DOB:
               
            </label>
             <input type="date" {...register("dob")}></input>
                {errors.dob && <p className='text-danger'>{errors.dob.message}</p>}
            <label>Gender:</label>
            <div>
                
                <input type="radio" {...register("gender")} value="male"></input>
                <label className="p-1">Male</label>
                <input type="radio" {...register("gender")} value="female"></input>
                <label className="p-1">Female</label>
            </div>
             {errors.gender && <p className='text-danger'>{errors.gender.message}</p>}
            <label>Skills:</label>
            <div>
                <input type="checkbox"value="HTML" {...register("skills")}></input>
                <label className="p-1">HTML</label>
            </div>
            <div>
                <input type="checkbox"value="CSS" {...register("skills")}></input>
                <label className="p-1">CSS</label>
            </div>
            <div>
                <input type="checkbox"value="JS" {...register("skills")}></input>
                <label className="p-1">JS</label>
            </div>
            {errors.skills && <p className='text-danger'>{errors.skills.message}</p>}
            <div>
                 <label >isFresher:</label>
                <input type="checkbox" {...register("isFresher")} className='m-2'></input>
                
            </div>
            {errors.isFresher && <p className='text-danger'>{errors.isFresher.message}</p>}
             <label>Joining Period:</label>
         <Controller
          name="joiningPeriod"
          control={control}
         
          render={({ field }) => (
            <DatePicker
              selectsRange
              startDate={field.value?.[0]}
              endDate={field.value?.[1]}
              onChange={(dates) => field.onChange(dates)}
              isClearable
              placeholderText="Select joining period"
              className="form-control"
            />
          )}
        />
        {errors.joiningPeriod && (
          <p className='text-danger'>{errors.joiningPeriod.message as string}</p>
        )}
            <button type='submit' className='bg-success p-2 rounded'>Submit</button>
       </form>
        
        
         <div>
        <Table striped bordered hover variant="primary" className='w-75 m-auto'>
           <thead>
            <tr>
               <th>Name</th>
               <th>Email</th>
               <th>Password</th>
               <th>DOB</th>
               <th>Gender</th>
               <th>Skills</th>
               <th>IsFresher</th>
               <th>JoiningDate</th>
            </tr>
          
        </thead>
        <tbody>
            {userData.map((s,index) => 
                 <tr key={index}>
                <td>{s.name}</td>
                <td>{s.email}</td>
                <td>{s.password}</td>
                <td>{s.dob}</td>
                <td>{s.gender}</td>
                <td>{s.skills.join(',')}</td>
                <td>{s.isFresher?"yes":"no"}</td>
                <td>{s.joiningPeriod[0]?.toLocaleDateString()}-{s.joiningPeriod[1]?.toLocaleDateString()}</td>
            </tr>
            )}
            
        </tbody>
    </Table>
         </div>
      
     
    </div>
  )
}

export default Form


import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import Form from './Pages/Form'
import NavBar from './NavBar'
import Home from './Pages/Home'
import Users from './Pages/Users'
import About from './Pages/About'
import User from './Pages/User'
import Error from './Pages/Error'
function App() {


  return (
    <>
      <BrowserRouter>
         <NavBar />
         <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/form" element={<Form />} />
            <Route path="/user/:username" element={<Users />} />
            <Route path="user" element={<User/>} />
            <Route path="/about" element={<About />} />
            <Route path="*" element={<Error />} />
         </Routes>
     </BrowserRouter>
      {/* <div>
        <Form></Form>
      </div> */}
    </>
  )
}

export default App

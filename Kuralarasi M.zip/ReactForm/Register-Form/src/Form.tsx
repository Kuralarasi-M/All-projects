import React, { useState } from "react";
import { useForm } from "react-hook-form";

type FormData = {
  name: string;
  department: string;
  isFresher: boolean;
  skills: string[];
  gender: string;
  dob: string;
};

const Form = () => {
  const { register, handleSubmit, formState: { errors },reset } = useForm<FormData>();
  const [userInfo, setUserInfo] = useState<FormData[]>([]);

  const onSubmit = (data: FormData) => {
    setUserInfo(prev => [...prev,data]); 
    console.log("Submitted Data:", data);
     reset();
  };
  const validateDOB = (value: string) => {
    const today = new Date();
    const dob = new Date(value);

    if (dob > today) {
      return "DOB cannot be in the future";
    }

    // Calculate age
    const ageDiff = today.getTime() - dob.getTime();
    const ageDate = new Date(ageDiff);
    const age = Math.abs(ageDate.getUTCFullYear() - 1970);

    if (age < 18) {
      return "Your age must be Greater than 18";
    }

    return true;
  };
  return (
    <div>
   
      <h1 className="text-center m-5">Registeration Form</h1>
      <form onSubmit={handleSubmit(onSubmit)} className="d-flex flex-column w-25 m-auto border p-5 gap-3 rounded">

        <label>
          Name:
          <input type="text" {...register("name", { required: "Name is required" ,minLength:{value:3,message:"Name must be atleast 3 characters"}})} />
        </label>
        {errors.name && <p style={{ color: "red" }}>{errors.name.message}</p>}

        <label>
          Department:
          <select {...register("department", { required: "Select department" })}>
            <option value="">-- Select --</option>
            <option value="HR">HR</option>
            <option value="Integration">Integration</option>
            <option value="Testing">Testing</option>
            <option value="Development">Development</option>
          </select>
        </label>
        {errors.department && <p style={{ color: "red" }}>{errors.department.message}</p>}

        <label>
          Fresher:
          <input type="checkbox" {...register("isFresher")} />
        </label>

        <label>Skills:</label>
        <label><input type="checkbox" value="HTML" {...register("skills", { required: "Select at least one skill" })} /> HTML</label>
        <label><input type="checkbox" value="CSS" {...register("skills")} /> CSS</label>
        <label><input type="checkbox" value="JS" {...register("skills")} /> JS</label>
        {errors.skills && <p style={{ color: "red" }}>{errors.skills.message}</p>}

        <label>Gender:</label>
        <label><input type="radio" value="male" {...register("gender", { required: "Select gender" })} /> Male</label>
        <label><input type="radio" value="female" {...register("gender")} /> Female</label>
        {errors.gender && <p style={{ color: "red" }}>{errors.gender.message}</p>}

        <label>
          DOB:
          <input type="date" {...register("dob", { required: "DOB is required", validate: validateDOB })} />
        </label>
        {errors.dob && <p style={{ color: "red" }}>{errors.dob.message}</p>}

        <input type="submit" className="bg-success rounded"/>
      </form>
      <br></br>
      <div className="table-responsive w-75 m-auto">
           {userInfo && (
        <table className="table table-bordered table-striped table-hover table-responsive">
           <thead className="table-dark">
            <tr>
              <th>Name</th>
              <th>Department</th>
              <th>Fresher</th>
              <th>Skills</th>
              <th>Gender</th>
              <th>DOB</th>
            </tr>
          </thead>
          <tbody>
           
              {userInfo.map(user => 
                  <tr>
                    <td>{user.name}</td>
                    <td>{user.department}</td>
                    <td>{user.isFresher? "yes" : "no"}</td>
                    <td>{user.skills.join(',')}</td>
                    <td>{user.gender}</td>
                    <td>{user.dob}</td>
                  </tr>
               )}
              
           
          </tbody>
        </table>
      )}
      </div>
      
    </div>
  );
};

export default Form;

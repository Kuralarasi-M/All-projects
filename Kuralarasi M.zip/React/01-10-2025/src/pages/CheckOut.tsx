import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import type { AppDispatch, RootState } from '../store/store';
import { Button, Toast } from 'react-bootstrap';
import { addOrderItems, type OrderItem } from '../slices/orderSlice';
import { clearCartItem } from '../slices/cartItemSlice';


const CheckOut = () => {
  const dispatch = useDispatch<AppDispatch>();
  const products = useSelector((state: RootState) => state.CartItemInfo.cartItems);
  const totalPrice = products.reduce((acc, curr) => acc + curr.price * curr.quantity, 0);
  const [show, setShow] = useState(false);


  useEffect(() => {
    if (products.length > 0) {
      localStorage.setItem("cartItems", JSON.stringify(products));
    }
  }, [products]);
 
  const handleOrder = () => {
    setShow(!show)
    dispatch(addOrderItems(products))
    console.log(products);
    const existingOrders = JSON.parse(localStorage.getItem('orders') || '[]');
    dispatch(clearCartItem())
    localStorage.setItem("cartItems","");
    localStorage.setItem('orders', JSON.stringify([...existingOrders, { 
      OrderId: `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`, 
      Items: products, 
      Status: 'Shipping' 
    }]));
  }
  return (
    <div className='mt-5'>
      <div >
        <Toast
          onClose={() => setShow(false)}
          show={show}
          delay={3000}
          autohide
          style={{
            position: 'fixed',
            top: '500px',
            right: '100px',
            zIndex: 9999,
            height: '100px',
          }}
        >
          <Toast.Header className='bg-success text-white'>
            <strong className="me-auto">Success</strong>
            <small>Just now</small>
          </Toast.Header>
          <Toast.Body>Hello! Order Placed Successfully!</Toast.Body>
        </Toast>

      </div>
      <div className=' mt-3'>
        <div className="container my-4 w-50 border rounded p-3 text-center">
          <h4>Cart Summary</h4>
          <p>Total Items: {products.reduce((acc, item) => acc + item.quantity, 0)}</p>
          <p>
            Total Price: <strong>₹{totalPrice}</strong>
          </p>
          <Button variant="success" className="w-100" onClick={handleOrder}>
            Place Order
          </Button>
        </div>
        <div className="m-auto text-center"><h3>Cart Items</h3></div>
        <div className="container my-4">
          <div className="border rounded p-3 bg-light">
            {products.map((p) => (
              <div key={p.id} className="card mb-3 shadow-sm">
                <div className="row g-0 align-items-center">
                  
                  <div className="col-md-3 text-center">
                    <img
                      src={p.image}
                      alt={p.name}
                      className="img-fluid rounded"
                      style={{ maxWidth: '200px', objectFit: 'contain' }}
                    />
                  </div>

              
                  <div className="col-md-9">
                    <div className="card-body">
                      <h5 className="card-title">{p.name}</h5>
                      <p className="card-text">{p.description}</p>
                      <p className="card-text mb-1">Price: ₹ {p.price}</p>
                      <p className="card-text mb-1">Quantity: {p.quantity}</p>
                      <p className="card-text fw-bold">
                        SubTotal: ₹ {p.quantity * p.price}
                      </p>
                      <p className="card-text">Rating:  <i className="fa-solid fa-star text-warning"></i> {p.rating}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        

      </div>
    </div> 
)}

export default CheckOut;

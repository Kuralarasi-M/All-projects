import React, { useEffect, useState, useRef } from 'react';
import { Button, Card } from 'react-bootstrap';
import { useDispatch, useSelector } from 'react-redux';
import type { AppDispatch, RootState } from '../store/store';
import { setProducts, type Product } from '../slices/productSlice';
import '../App.css';
import { useNavigate } from 'react-router-dom';


const Home = () => { 
  const dispatch = useDispatch<AppDispatch>();
  const products = useSelector((state: RootState) => state.ProductInfo.Product);

 const navigate = useNavigate();

  useEffect(() => {
   const fetchData=async () => {
    try {
      const res = await fetch("http://localhost:3000/products?categoryId=6");
      const data: Product[] = await res.json();
      dispatch(setProducts(data));
    } catch (err) {
      console.error(err);
    }
   }
   fetchData();
  }, [dispatch]);

  const sliderRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: "left" | "right") => {
    if (sliderRef.current) {
      const scrollAmount = 300;
      sliderRef.current.scrollBy({ left: direction === "left" ? -scrollAmount : scrollAmount, behavior: "smooth" });
      console.log(sliderRef.current);
      
    }
  };
 const viewProducts = (productId: number) => {
    navigate(`/products/${productId}`); 
    
  };
 
  return (
    <div className='rounded'>
     
      <div>
        <img src="/images/banner.jpg" className='w-100 banner' alt="banner"/>
      </div>
     <h2 className='text-primary m-1'>Top Sales</h2>
    
      <div className="d-flex justify-content-between mt-3 mb-2">
        <Button onClick={() => scroll("left")} className="me-2">{"<"}</Button>
        <Button onClick={() => scroll("right")}> {">"} </Button>
      </div>

    
      <div ref={sliderRef} style={{
          display: "flex",
          overflowX: "auto",
          scrollBehavior: "smooth",
          gap: "20px",
          padding: "10px",
        }}
      >
        {products.map((product) => (
          <Card key={product.id} style={{ minWidth: "250px" }} className="shadow-lg p-3">
            <Card.Img
              variant="top"
              src={product.image}
              height={200}
              alt={product.name}
            />
            <Card.Body className="d-flex flex-column">
              <Card.Title>{product.name}</Card.Title>
              <Card.Text>{product.description}</Card.Text>
              <strong className="mb-2">₹{product.price}</strong>
              <strong className="mb-2">Rating : <i className="fa-solid fa-star text-warning"></i>{product.rating}</strong>
              <Button variant="primary" className="mt-auto" onClick={() => viewProducts(product.id)}>View Details</Button>
            </Card.Body>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default Home;

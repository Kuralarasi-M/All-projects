import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "react-bootstrap";
import "../App.css";
import { getProduct, type Product } from "../slices/productSlice";
import { useDispatch, useSelector } from "react-redux";
import type { AppDispatch, RootState } from "../store/store";
import { addCartItems } from "../slices/cartItemSlice";


const ProductDetails = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { id } = useParams<{ id: string }>();
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const product = useSelector(
    (state: RootState) => state.ProductInfo.selectedProduct
  );

  useEffect(() => {
    if (id) {
      const productId = Number(id); 
      fetch(`http://localhost:3000/products/${productId}`)
        .then((res) => {
          if (!res.ok) throw new Error("Failed to fetch product");
          return res.json();
        })
        .then((data: Product) => {
          dispatch(getProduct(data));
          setLoading(false);
        })
        .catch((err) => {
          console.error("Error fetching product:", err);
          dispatch(getProduct(null));
          setLoading(false);
        });
    }
  }, [id, dispatch]);


  if (loading) return <h3 className="text-center m-3">Loading...</h3>;

  if (!product)
    return <h3 className="text-center m-3">Product not found</h3>;

 
  const handleCart = () => {
    var loginUser=localStorage.getItem("loginUser");
       
    if(loginUser){
        dispatch(addCartItems(product));
        navigate('/cart');
    }
    else{
        navigate('/login');
    }
   
  };

  return (
    <div className="m-5 text-center">
      <div className="w-50 m-auto border p-5 rounded">
        <img
          src={product.image}
          alt={product.name}
          className="product-img"
        />
        <h2>{product.name}</h2>
        <p>{product.description}</p>
        <strong>₹{product.price}</strong>
        <p>Rating:<i className="fa-solid fa-star text-warning"></i> {product.rating}</p>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla
          dolorem qui tempore quam iure!
        </p>
        <Button className="m-2">Buy Now</Button>
        <Button className="m-2" onClick={handleCart}>
          Add to Cart
        </Button>
      </div>
    </div>
  );
};

export default ProductDetails;

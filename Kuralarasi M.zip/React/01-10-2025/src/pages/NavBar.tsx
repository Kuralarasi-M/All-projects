import React, { useEffect } from 'react'
import { Badge, Container, FormControl, Nav, Navbar, NavbarBrand } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { ShoppingCart } from 'lucide-react';
import type { AppDispatch, RootState } from '../store/store';
import { useDispatch, useSelector } from 'react-redux';
import { setCartItems } from '../slices/cartItemSlice';
const NavBar = () => {
  const dispatch = useDispatch<AppDispatch>();
  const cartItems = useSelector((state: RootState) => state.CartItemInfo.cartItems);
  const user=useSelector((state:RootState)=> state.LoginInfo.LoginData)
  
    useEffect(()=>{
      
      const data= localStorage.getItem("cartItems");
      if(data){
         dispatch(setCartItems(JSON.parse(data)));
      }
      
   },[dispatch])
  
  const totalItems = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  return (
    <div>
       <Navbar bg="primary" variant="primary" expand="lg">
      <Container>
       
        <NavbarBrand as={Link} to="/">MyApp</NavbarBrand>

        <Navbar.Toggle aria-controls="basic-navbar-nav" />
       
        <Navbar.Collapse id="basic-navbar-nav">
          
          <Nav className="ms-auto">
            <Nav.Link as={Link} to="/">Home</Nav.Link>
            <Nav.Link as={Link} to="/category">Category</Nav.Link>
            {!user && (<Nav.Link as={Link} to="/login">Login</Nav.Link>)}
            {user && <>
            <Nav.Link as={Link} to="/cart">
            <ShoppingCart size={24} />
            <Badge bg="warning" className="ms-1">{totalItems}</Badge>
            </Nav.Link>
           <Nav.Link as={Link} to="/profile">Profile</Nav.Link>
            </>}
          </Nav>
        </Navbar.Collapse>
      </Container>                
    </Navbar>
    </div>
  )
}

export default NavBar



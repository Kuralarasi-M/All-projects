import React, { useEffect, useState } from "react";
import { Tabs, Tab, Card, Row, Col, Button, FormLabel, FormControl, FormCheck, FormGroup } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { Form, useNavigate } from "react-router-dom";
import type { AppDispatch, RootState } from "../store/store";
import { setProducts } from "../slices/productSlice";
import { Controller } from "react-hook-form";

import '../App.css';
import FormRange from "react-bootstrap/esm/FormRange";
type Product = {
  id: number;
  name: string;
  description: string;
  price: number;
  rating:number,
  image: string;
  categoryId: number;
};

const categories = [
  { id: 0, name: "All" },
  { id: 1, name: "Electronics" },
  { id: 2, name: "Clothes" },
  { id: 3, name: "Footwear" },
  { id: 4, name: "Accessories" },
  { id: 5, name: "Home Appliances" },
  { id: 6, name: "Top Sales" },
];

const CategoryTabs = () => {
  const [activeTab, setActiveTab] = useState(categories[0].id);
 const [priceRange, setPriceRange] = useState([0, 60000]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [minRating, setMinRating] = useState<number[]>([]);
  const navigate = useNavigate();
  const handleAddToCart = (productId: number) => {
    navigate(`/products/${productId}`); 
    
  };

  const dispatch = useDispatch<AppDispatch>();
  const products = useSelector((state: RootState) => state.ProductInfo.Product);
  const fetchProducts = (categoryId: number) => {
    setLoading(true);
    if(categoryId==0){
      fetch(`http://localhost:3000/products`)
      .then((res) => res.json())
      .then((data: Product[]) => {
        
        dispatch(setProducts(data));
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
      
      return;
      
      
    }
    fetch(`http://localhost:3000/products?categoryId=${categoryId}`)
      .then((res) => res.json())
      .then((data: Product[]) => {
        
        dispatch(setProducts(data));
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchProducts(activeTab);
  }, [activeTab]);

  const handleChange = (rating:number,checked:boolean) => {
      if(checked){
        setMinRating([...minRating,rating])
      }
      else{
        setMinRating(minRating.filter((r) => r!==rating));
      }
  }

const filteredProducts = products.filter((p) => {
   const matchSearch = searchTerm? p.name.toLowerCase().includes(searchTerm.toLowerCase()):true;
   const matchCategory = (activeTab===0) ? true : activeTab===p.categoryId;
   const matchPrice = p.price >= priceRange[0] && p.price <= priceRange[1];
   const matchRating = minRating.length===0 ?true: minRating.some(r => p.rating>=r);
   return matchSearch && matchCategory && matchPrice && matchRating
});


  return (
     <div className="my-5">
  <Row>
    
    <Col md={3} xs={12} className="mb-4">
      <input
        type="text"
        placeholder="Search products..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="form-control"
      />
      <div>
        
        <Col md={3} xs={12} className="w-100 my-4">
          <FormLabel className="w-100">Price Range: ₹{priceRange[0]} - ₹{priceRange[1]}</FormLabel>
          <FormRange
            min={0}
            max={60000}
            value={priceRange[0]}
            onChange={(e) => setPriceRange([Number(e.target.value), priceRange[1]])}
            className="w-80"
          />
          <FormRange
            min={0}
            max={60000}
            value={priceRange[1]}
            onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
          />
        </Col>
        <Col md={2} xs={6} className="w-50 my-4">
           <FormLabel>Ratings</FormLabel>
          <FormCheck checked={minRating.includes(4)} label="4.0 & Above" onChange={(e) => handleChange(4,e.target.checked)} ></FormCheck>
          <FormCheck checked={minRating.includes(3)} label="3.0 & Above" onChange={(e) => handleChange(3,e.target.checked)} ></FormCheck> 
          <FormCheck checked={minRating.includes(2)} label="2.0 & Above" onChange={(e) => handleChange(2,e.target.checked)} ></FormCheck>
        </Col>
      </div>
    </Col>

  
    <Col md={9} xs={12}>
      <Tabs
        activeKey={activeTab}
        onSelect={(k) => setActiveTab(Number(k))}
        id="category-tabs"
        className="mb-3"
      >
        {categories.map((cat) => (
          <Tab eventKey={cat.id} title={cat.name} key={cat.id}>
            {loading ? (
              <h2 className="mt-3">Loading...</h2>
            ) : filteredProducts.length === 0 ? (
              <h2 className="mt-3">No products found</h2>
            ) : (
              <Row className="mt-3">
                {filteredProducts.map((p) => (
                  <Col key={p.id} md={3} className="mb-3">
                    <Card className="h-100">
                      <Card.Img
                        variant="top"
                        src={p.image}
                        loading="lazy"
                        className="catPhoto"
                        height={200}
                      />
                      <Card.Body className="d-flex flex-column">
                        <Card.Title>{p.name}</Card.Title>
                        <Card.Text>{p.description}</Card.Text>
                         <Card.Text>Rating : <i className="fa-solid fa-star text-warning"></i> {p.rating}</Card.Text>
                        
                        <strong className="mb-2">₹{p.price}</strong>
                        <Button
                          variant="primary"
                          className="mt-auto"
                          onClick={() => handleAddToCart(p.id)}
                        >
                          View Details
                        </Button>
                      </Card.Body>
                    </Card>
                  </Col>
                ))}
              </Row>
            )}
          </Tab>
        ))}
      </Tabs>
    </Col>
  </Row>
</div>

  );
};

export default CategoryTabs;


import { useDispatch, useSelector } from 'react-redux'
import React, { useEffect, useState } from 'react';
import { Offcanvas, Nav, Button, Tab, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';

import type { AppDispatch, RootState } from '../store/store';

import { removeLogin } from '../slices/loginSlice';
import { useNavigate } from 'react-router-dom';
import type { CartItem } from '../slices/cartItemSlice';
import { setOrderedItems } from '../slices/orderSlice';
const Profile = () => {
  const navigate=useNavigate();
    const dispatch = useDispatch<AppDispatch>();
    const handleLogOut= () => {
          dispatch(removeLogin());
          localStorage.setItem("loginUser","");
          navigate("/");
    }
  const handleProducts = (productId:number) => {
       navigate(`/products/${productId}`); 
  }
   useEffect(()=>{
      
      const data= localStorage.getItem("orders");
      if(data){
         dispatch(setOrderedItems(JSON.parse(data)));
      }
  
   },[dispatch])
  const user= useSelector((state:RootState) => state.LoginInfo.LoginData)
  const orders = useSelector((state: RootState) => state.OrderInfo.OrderedItems|| []); 
  console.log(orders);
  const calculateTotal = (items: CartItem[]) =>
    items.reduce((acc, item) => acc + item.price * item.quantity, 0);
  
  return (
    <Tab.Container id="profile-tabs" defaultActiveKey="user">
      <Row>
        <Col sm={3}>
          <Nav variant="pills" className="flex-column">
            <Nav.Item>
              <Nav.Link eventKey="user">User Info</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="orders">Orders</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="logout">Logout</Nav.Link>
            </Nav.Item>
          </Nav>
        </Col>

        <Col sm={9}>
          <Tab.Content>
         
            <Tab.Pane eventKey="user">
              <h3>User Information</h3>
              {user ? (
                <div>
                  <p>Name: {user.name}</p>
                  <p>Email: {user.email}</p>
                </div>
              ) : (
                <p>No user logged in.</p>
              )}
            </Tab.Pane>

          
            <Tab.Pane eventKey="orders">
              <div>
      <h3>My Orders</h3>
      {orders.length === 0 ? (
        <p>No orders yet.</p>
      ) : (
        <ul className="list-group">
          {orders.map((order) => (
            <li key={order.OrderId} className="list-group-item mb-2">
              <p><strong>Order ID:</strong> {order.OrderId}</p>
              <p><strong>Status:</strong> {order.Status}</p>
              <p><strong>Total:</strong> ₹{calculateTotal(order.Items)}</p>
              <ul>
                {order.Items.map((item) => (
                  <li key={item.id} className='border rounded my-3 p-2 hover-item' onClick={() => handleProducts(item.id)}>
                    <img src={item.image} width={100} height={100} className='rounded mx-2'></img>
                    {item.name}  x  { item.quantity} = ₹{item.price * item.quantity}
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      )}
    </div>
              
            </Tab.Pane>

        
            <Tab.Pane eventKey="logout">
              <h3>Logout</h3>
              <Button variant="danger" onClick={handleLogOut}>
                Logout
              </Button>
            </Tab.Pane>
          </Tab.Content>
        </Col>
      </Row>
    </Tab.Container>
  )
}

export default Profile

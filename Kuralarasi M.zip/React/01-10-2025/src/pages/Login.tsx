import React, { useEffect, useState } from 'react'
import '../App.css';
import { Button, Form, FormControl, FormGroup, FormLabel } from 'react-bootstrap';
import schema from './schema';
import type z from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import type { AppDispatch, RootState } from '../store/store';
import { useDispatch, useSelector } from 'react-redux';
import { addUser,fetchUsers, type User } from '../slices/authenticationlice';
import { useNavigate } from 'react-router-dom';
import { setLogin } from '../slices/loginSlice';


export type UserData = z.infer<typeof schema>

const Login = () => {
  const [action,setAction] = useState("Login");
   const dispatch = useDispatch<AppDispatch>();
  const {users,loading}= useSelector((state: RootState) => state.UserInfo);
  const navigate= useNavigate();
  const {register,handleSubmit,formState : {errors},setError,reset} = useForm<UserData>({
    resolver:zodResolver(schema),
    defaultValues:{
      name:"",
      email:"",
      password:""
    }
  });
  
  useEffect(() => {
  dispatch(fetchUsers());
}, [dispatch]);

  const formSubmit = async (data: UserData) => {

  if (action === "Sign Up" && !data.name) {
    alert("Please enter a name for sign up");
    return;
  }
  if (action === "Sign Up") {
    console.log("register");
    
    await dispatch(addUser(data));
    await dispatch(fetchUsers()); 
    localStorage.setItem("loginUser",JSON.stringify(data));
      dispatch(setLogin(data));
      navigate("/");
    reset();
  } else {
    
    const existingUser = users.find(u => u.email === data.email);

    if (!existingUser) {
      alert("User not found. Please Sign Up first.");
      setAction("Sign Up");
      return;
    }
     
    if (existingUser.password === data.password) {
      alert(`Welcome ${existingUser.name}`);
      localStorage.setItem("loginUser",JSON.stringify(existingUser));
      dispatch(setLogin(existingUser));
      navigate("/");
    } else {
       setError("password", {type: "manual", message: "Incorrect password"});
       
    }
  }
};


   
  return (
    <div className='m-5'>
      <Form className='w-25 p-5 m-auto border rounded shadow-lg' onSubmit={handleSubmit(formSubmit)}>
         <div className='w-100 border border-primary my-3 bg-primary rounded'>
               <Button type="button" className='w-50' onClick={() => setAction("Sign Up")} style={{ backgroundColor: action === "Sign Up" ? "blue" : "gray" }}
>Sign Up</Button>
                <Button type="button" className='w-50' onClick={() => setAction("Login")}  style={{ backgroundColor: action !== "Sign Up" ? "blue" : "gray" }}>Login</Button>
            </div>
      
          {action === "Sign Up" && (
  <FormGroup className='mb-3'>
    <FormLabel>Name</FormLabel>
    <FormControl type="text" {...register("name")} isInvalid={!!errors.name}/>
    <FormControl.Feedback type='invalid'>{errors.name?.message}</FormControl.Feedback>
  </FormGroup>
)}

            <FormGroup className='mb-3'>
           <FormLabel>Email</FormLabel>
                <FormControl type="email"  {...register("email")} className="form-control p-2" isInvalid={!!errors.email}/>
                 <FormControl.Feedback type='invalid'>{errors.email?.message}</FormControl.Feedback>
            </FormGroup>
          <FormGroup className='mb-3'>
           <FormLabel>Password</FormLabel>
                <FormControl type="password"  {...register("password")} className="form-control p-2" isInvalid={!!errors.password}/>
                 <FormControl.Feedback type='invalid'>{errors.password?.message}</FormControl.Feedback>
            </FormGroup>
            <Button type="submit" className='m-4' disabled={loading}> {action} </Button>

           
            
      </Form>
     
    </div>
  )
}

export default Login

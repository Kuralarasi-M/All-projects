import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import type { AppDispatch, RootState } from "../store/store";
import { Button, Card, Row, Col } from "react-bootstrap";
import { addCartItems, removeCartItem, decreaseCartItem, setCartItems } from "../slices/cartItemSlice";
import { useNavigate } from "react-router-dom";

const Cart = () => {
  const dispatch = useDispatch<AppDispatch>();
  const products = useSelector((state: RootState) => state.CartItemInfo.cartItems);
 const totalPrice = products.reduce((acc, curr) => acc + curr.price * curr.quantity, 0);
 const navigate= useNavigate();

useEffect(() => {
  if (products.length > 0) {
    localStorage.setItem("cartItems", JSON.stringify(products));
  }
}, [products]);


  useEffect(()=>{
    
    const data= localStorage.getItem("cartItems");
    if(data){
       dispatch(setCartItems(JSON.parse(data)));
    }

 },[dispatch])
  const handleOrder = () =>{
      navigate('/checkout');
  }
  
  return (
    <div className="d-flex m-3">
     
      <div className="w-75">
        <Row>
          {products.map((product) => (
            <Col md={4} key={product.id} className="mb-3">
              <Card className="shadow-lg h-100">
                <Card.Img
                  variant="top"
                  src={product.image}
                  height={200}
                  alt={product.name}
                />
                <Card.Body className="d-flex flex-column">
                  <Card.Title>{product.name}</Card.Title>
                  <Card.Text>{product.description}</Card.Text>
                  <strong className="mb-2">₹{product.price}</strong>
                  <strong className="mb-2">Rating : <i className="fa-solid fa-star text-warning"></i> {product.rating}</strong>
                  <p>Quantity: {product.quantity}</p>
                  <div className="d-flex justify-content-between mt-auto">
                    <Button
                      variant="secondary"
                      onClick={() => dispatch(decreaseCartItem(product.id))}
                    >
                      -
                    </Button>
                    <Button
                      variant="danger"
                      onClick={() => dispatch(removeCartItem(product.id))}
                    >
                      Remove
                    </Button>
                    <Button
                      variant="success"
                      onClick={() => dispatch(addCartItems(product))}
                    >
                      +
                    </Button>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </div>

      
      <div className="w-25 border rounded p-3 ms-3">
        <h4>Cart Summary</h4>
        <p>Total Items: {products.reduce((acc, item) => acc + item.quantity, 0)}</p>
        <p>
          Total Price: <strong>₹{totalPrice}</strong>
        </p>
       
        <Button variant="success" className="w-100" onClick={handleOrder}>
          CheckOut
        </Button>
      </div>
    </div>
  );
};

export default Cart;

import {configureStore} from "@reduxjs/toolkit";

import productReducer from "../slices/productSlice";
import cartReducer  from "../slices/cartItemSlice";
import  AuthenReducer from "../slices/authenticationlice";
import  LoginReducer from "../slices/loginSlice";
import  OrderReducer from "../slices/orderSlice";
const store = configureStore({
    reducer:{
        ProductInfo:productReducer,
        CartItemInfo:cartReducer,
        UserInfo:AuthenReducer,
        LoginInfo:LoginReducer,
        OrderInfo:OrderReducer
    },
   
        

})
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export default store;

import { Route, Routes } from 'react-router-dom'
import './App.css'
import Home from './pages/Home'
import Category from './pages/Category'
import Order from './pages/Cart'
import Account from './pages/Profile'
import NavBar from './pages/NavBar'
import ProductDetails from './pages/ProductDetails'
import NotFound from './pages/NotFound'
import CheckOut from './pages/CheckOut'
import Login from './pages/Login'
import ProtectedRoute from './pages/ProtectedRoute'
import Profile from './pages/Profile'
import { useEffect } from 'react'
import { setLogin } from './slices/loginSlice'
import { useDispatch } from 'react-redux'
import type { AppDispatch } from './store/store'

function App() {
 const dispatch = useDispatch<AppDispatch>();
 useEffect(()=>{
      const data = localStorage.getItem("loginUser");
  if (data) {
    const parsedData = JSON.parse(data);
    dispatch(setLogin(parsedData));
  }
  },[])
  return (
    <>
    <NavBar></NavBar>
    
      <Routes>
         <Route path='/' element={<Home />}  ></Route>
         <Route path='/category' element={<Category />}></Route>
         <Route path='/profile' element={<Profile />}></Route>
         <Route path='/cart' element={<ProtectedRoute>
          <Order />
          </ProtectedRoute>}></Route>
         <Route path="/products/:id/" element={<ProductDetails />} />
         <Route path="/checkout" element={<CheckOut/>}></Route>
         <Route path="/login" element={<Login />}></Route>
         <Route path='*' element={<NotFound />}></Route>
      </Routes>
    </>
  )
}

export default App



import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import React from 'react'
import type { User } from './authenticationlice';

interface LoginState{
    LoginData:User | null;
}
const initialState :LoginState = {
    LoginData: null
};
export const loginSlice= createSlice({
    name:'loginData',
    initialState,
    reducers:{
        setLogin:(state,action:PayloadAction<User>) => {
            state.LoginData = action.payload;
        },
        removeLogin:(state)=> {
            state.LoginData=null;
        }
    }
})

export const { setLogin, removeLogin } = loginSlice.actions;
export default loginSlice.reducer;

import { createSlice, type PayloadAction } from "@reduxjs/toolkit";

export interface Product {
  rating: number;
  id: number;
  name: string;
  description: string;
  image: string;
  price: number;
  categoryId: number;
}

interface ProductState {
  Product: Product[];
  selectedProduct: Product | null;
}

const initialState: ProductState = {
  Product: [],
  selectedProduct: null,
};

export const productSlice = createSlice({
  name: "Products",
  initialState,
  reducers: {
    setProducts: (state, action: PayloadAction<Product[]>) => {
      state.Product = action.payload;
    },
    getProduct: (state, action: PayloadAction<Product | null>) => {
      
      state.selectedProduct = action.payload;
    },
  },
});

export const { setProducts, getProduct } = productSlice.actions;
export default productSlice.reducer;

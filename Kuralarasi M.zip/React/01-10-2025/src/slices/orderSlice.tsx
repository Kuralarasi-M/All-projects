import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import {setCartItems, type CartItem} from "./cartItemSlice";

export interface OrderItem {
    OrderId:string,
    Status:string,
    Items:CartItem[]
}
interface OrderState{
    OrderedItems:OrderItem[];
}

const initialState:OrderState={
    OrderedItems:[]
}

const OrderId = () => `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
export const orderSlice = createSlice({
    name:"orderedItems",
    initialState,
    reducers:{
        addOrderItems:(state,action:PayloadAction<CartItem[]>) => {
           
        const newOrder: OrderItem = {
        OrderId: OrderId(),
        Items:action.payload.map(item => ({ ...item })),
        Status: 'Shipping',
      };

      state.OrderedItems.push(newOrder);
            
        },
        setOrderedItems:(state,action:PayloadAction<OrderItem[]>) => {
             state.OrderedItems=action.payload
        },
        removeOrderItem:(state,action:PayloadAction<string>) => {
            state.OrderedItems.filter(r => r.OrderId==action.payload)
        }
    }
})

export const {addOrderItems,removeOrderItem,setOrderedItems} = orderSlice.actions;
export default orderSlice.reducer;
import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { Product } from "./productSlice";



export interface CartItem extends Product {
  quantity: number;
}

interface CartState {
  cartItems: CartItem[];
}

const initialState: CartState = {
  cartItems: [],
};

export const cartSlice = createSlice({
    name:"cartItems",
    initialState,
    reducers:{
        addCartItems: (state, action: PayloadAction<Product>) => {
            const existingItem = state.cartItems.find(item => item.id === action.payload.id);
            if (existingItem) {
                existingItem.quantity += 1; 
            } else {
                state.cartItems.push({ ...action.payload, quantity: 1 }); 
             }
        },
        removeCartItem: (state, action: PayloadAction<number>) => {
            state.cartItems = state.cartItems.filter(item => item.id !== action.payload);
        },
        decreaseCartItem: (state, action: PayloadAction<number>) => {
            const item = state.cartItems.find(i => i.id === action.payload);
            if (item) {
                if (item.quantity > 1) {
                    item.quantity -= 1;
                } else {
                    state.cartItems = state.cartItems.filter(i => i.id !== action.payload);
                }
            }
        },
        setCartItems:(state,action:PayloadAction<CartItem[]>) => {
            state.cartItems=action.payload;
        },
        clearCartItem:(state)=>{
            state.cartItems=[];
        }
    },
    
});

export const {addCartItems,removeCartItem,decreaseCartItem,setCartItems,clearCartItem} = cartSlice.actions;
export default cartSlice.reducer;
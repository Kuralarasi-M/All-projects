
import { Route, Routes } from 'react-router-dom'
import './App.css'
import RegisterForm from './common/components/RegisterForm'
import DemoForm from './common/components/DemoForm'
import { Navbar } from 'react-bootstrap'

function App() {


  return (
    <>
    <Navbar></Navbar>
      <Routes>
        <Route path="/" element={<DemoForm />}></Route>
        <Route path="/dashboard" element={<RegisterForm />}></Route>
      </Routes>
    </>
  )
}

export default App

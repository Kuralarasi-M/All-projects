import z from 'zod'

const schema = z.object({
    id:z.coerce.number().optional(),
     name:z.string().nonempty("Name is Required").regex(/^[a-zA-Z_ ]+$/,"Only letters allowed").min(3,"minimum 3v letters required")
     .max(30,"Maximum 30 letters allowed"),
     email:z.string().nonempty("Email is Required").email("Invalid email format"),
    salary:z.coerce.number().min(10000,"Salary must be greater than 10k").max(100000,"Salary must be less than 1 lakh.")
    .refine(data => !isNaN(data),{message:"Salary is Required"}),
    
     phone: z.string().regex(/^\+?[1-9]\d{9,15}$/,"invalid phone no").optional(),

     dob:z.string().nonempty("DOB is Required"),
     age:z.coerce.string(),
     hireDate:z.string(),
     state:z.string().min(1,"Select 1 state"),
     hobbies:z.array(z.string()).min(1,"atleast select one hobby"),
     photo:z.string().optional(),
   
   
     gender:z.enum(["Male","Female","Others"]).optional()
     .refine(value => value!==undefined,{message:"Select your Gender"}),
     joiningPeriod: z.tuple([z.date().nullable(), z.date().nullable()])
  .refine(([start, end]) => {
    if (!start || !end) return true; 
    return end >= start;          
  }, {
    message: "End date must be after start date",
    path: ["joiningPeriod"],   
  }),


     
})


export default schema;
import z from "zod";
const loginSchema = z.object({
    email:z.string().nonempty("email is required").email("Invalid email"),
    password:z.string().nonempty("password is required").regex(/^(?=.*[a-z])(?=.*[0-9])(?=.*[!@~#$%^&*+_=\-])[A-Za-z0-9~!@#$%^&*()\-=`,.]{8,}$/),

});

export default loginSchema;

    
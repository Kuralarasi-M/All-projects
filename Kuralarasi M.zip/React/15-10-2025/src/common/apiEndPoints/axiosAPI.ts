import axios from "axios"
import { useNavigate } from "react-router-dom";

const axiosInstance = axios.create({
    baseURL:"http://localhost:5050/api/Authentication",
    headers:{
        "Content-Type":"application/json",
        "Accept":"application/json"
    },
});

axiosInstance.interceptors.request.use(
    (config) => {
        const token= localStorage.getItem("refreshToken");
        if(token){
           config.headers['Authorization']=`Bearer ${token}`
        }
        return config;
    },
    error => {
        return Promise.reject(error)
    }
)

const navigate=useNavigate()
axiosInstance.interceptors.response.use(
    response => response,
    async error => {
        const originalRequest=error.config;
        if(originalRequest.url=='/refresh'){
            localStorage.removeItem("refreshToken")
            localStorage.removeItem("accessToken")
             navigate("/")
             return Promise.reject.apply(error)
        }
        if(error.response.status === 401 && !originalRequest._retry){
            originalRequest._retry=true;
            const refreshToken = localStorage.getItem("refreshToken")
            try{
                var tokenResponse=await axiosInstance.post(
                    "Authentication/login",{}
                )
                const newAccessToken = localStorage.setItem("accessToken",tokenResponse.data.accessToken);
                const newRefreshToken = localStorage.setItem("refreshToken",tokenResponse.data.refreshToken);
                originalRequest.headers.Authentication= `Bearer ${newAccessToken}`;
                return axiosInstance(originalRequest);
            }
            catch(err){
                localStorage.removeItem("accessToken");
                localStorage.removeItem("refreshToken");
                navigate("/")
                return Promise.reject(error);
            }
        }
        return Promise.reject(error)
    }

)
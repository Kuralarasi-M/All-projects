import React, { useState } from "react";
import { Button, Form, Table } from "react-bootstrap";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import loginSchema from "../schema/loginSchema";
import type { z } from "zod";

export type LoginData = z.infer<typeof loginSchema>;

const DemoForm = () => {
  const { register, handleSubmit, formState: { errors }, reset } = useForm<LoginData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: ""
    }
  });

  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState("");
  const navigate = useNavigate();

  const formSubmit = async (data: LoginData) => {
    try {
      setLoading(true);
      const res = await axios.post("http://localhost:5050/api/Authentication/login", data);
      const { accessToken, refreshToken } = res.data;

      localStorage.setItem("accessToken", accessToken);
      localStorage.setItem("refreshToken", refreshToken);

      console.log(res.data);
      navigate("/dashboard");
    } catch (err: any) {
      if (err.response?.status === 401) {
        setApiError("Invalid credentials");
      } else {
        setApiError("Something went wrong. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <Form onSubmit={handleSubmit(formSubmit)}>
        {/* Email */}
        <Form.Group className="mb-3" controlId="email">
          <Form.Label>Email</Form.Label>
          <Form.Control
            type="email"
            isInvalid={!!errors.email}
            {...register("email")}
          />
          <Form.Control.Feedback type="invalid">
            {errors.email?.message}
          </Form.Control.Feedback>
        </Form.Group>

        {/* Password */}
        <Form.Group className="mb-3" controlId="password">
          <Form.Label>Password</Form.Label>
          <Form.Control
            type="password"
            isInvalid={!!errors.password}
            {...register("password")}
          />
          <Form.Control.Feedback type="invalid">
            {errors.password?.message}
          </Form.Control.Feedback>
        </Form.Group>

        {/* API error */}
        {apiError && <p style={{ color: "red" }}>{apiError}</p>}

        <Button type="submit" disabled={loading}>
          {loading ? "Logging in..." : "Login"}
        </Button>
      </Form>

      {/* Example Table */}
      <Table striped bordered hover className="mt-4">
        <thead>
          <tr>
            <th>Email</th>
            <th>Password</th>
          </tr>
        </thead>
        <tbody>
          {/* Example static data, you can map your state */}
          <tr>
            <td>example@email.com</td>
            <td>********</td>
          </tr>
        </tbody>
      </Table>
    </div>
  );
};

export default DemoForm;

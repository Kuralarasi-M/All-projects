import React, { useState } from 'react'
import {Button, Form, FormControl, FormGroup, FormLabel, Table} from 'react-bootstrap'
import { Controller, useForm, Watch } from 'react-hook-form'
import {unknown, z} from "zod";
import schema from '../schema/formSchema';
import { zodResolver } from '@hookform/resolvers/zod';
import DatePicker from "react-datepicker";
export type EmployeeData= z.infer<typeof schema>
const RegisterForm = () => {
  const {register,control,formState:{errors},handleSubmit,reset,watch,setValue} = useForm<EmployeeData>({
    resolver:zodResolver(schema),
    defaultValues:{
      name:"",
      email:"",
      salary:0,
      dob:"",
      age:"",
      hireDate:"",
      state:"",
      hobbies:[],
      gender:undefined,
      phone:"",
      joiningPeriod:[null,null],
      photo:undefined ,
    }

  })
  const today=new Date();
  const [formData,setFormData] = useState<EmployeeData[]>([]);
  const formSubmit = (data:EmployeeData) => {
      setFormData([data]);
      reset();
  }
const handleFileToBase64 = (
  e: React.ChangeEvent<HTMLInputElement>,
  onChange: (value: string) => void
) => {
  const file = e.target.files?.[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onloadend = () => {
    const base64 = reader.result?.toString() || "";
    onChange(base64); 
  };
  reader.readAsDataURL(file);
};


  return (
    <div>
      <Form onSubmit={handleSubmit(formSubmit)} className='w-50 m-auto p-5 border rounded'>
        <FormGroup>
           <Form.Label>Name</Form.Label>
           <FormControl type="text" {...register("name")} isInvalid={!!errors.name} />
           <FormControl.Feedback type="invalid" >{errors.name?.message}</FormControl.Feedback>
        </FormGroup>
        <FormGroup>
           <Form.Label>Email</Form.Label>
           <FormControl type="text" {...register("email")} isInvalid={!!errors.email} />
           <FormControl.Feedback type="invalid" >{errors.email?.message}</FormControl.Feedback>
        </FormGroup>
        <FormGroup>
           <Form.Label>Salary</Form.Label>
           <FormControl type="number" {...register("salary")} isInvalid={!!errors.salary} />
           <FormControl.Feedback type="invalid" >{errors.salary?.message}</FormControl.Feedback>
        </FormGroup>
        <FormGroup>
           <Form.Label>Phone</Form.Label>
           <FormControl type="number" {...register("phone")} isInvalid={!!errors.phone} />
           <FormControl.Feedback type="invalid" >{errors.phone?.message}</FormControl.Feedback>
        </FormGroup>
        <FormGroup>
           <Form.Label>DOB</Form.Label>
           <FormControl type="date" {...register("dob")} isInvalid={!!errors.dob} />
           <FormControl.Feedback type="invalid" >{errors.dob?.message}</FormControl.Feedback>
        </FormGroup>
         <FormGroup>
           <Form.Label>Age</Form.Label>
           <FormControl type="text" {...register("age")} isInvalid={!!errors.age} />
           <FormControl.Feedback type="invalid" >{errors.age?.message}</FormControl.Feedback>
        </FormGroup>
        <FormGroup>
           <Form.Label>hireDate</Form.Label>
           <FormControl type="date" {...register("hireDate")} isInvalid={!!errors.age} />
           <FormControl.Feedback type="invalid" >{errors.hireDate?.message}</FormControl.Feedback>
        </FormGroup>
        <FormGroup>
           <Form.Label>State</Form.Label>
          <Controller
            name="state"
            control={control}
            render={({field}) => (
              <Form.Select {...field} isInvalid={!!errors.state}>
                <option value="Tamilnadu">Tamilnadu</option>
                <option value="Kerala">Kerala</option>
                <option value="Karnataka">Karnataka</option>
                <option value="Andra">Andra</option>
              </Form.Select>
            )}
         
          />

          <FormControl.Feedback>{errors.state?.message}</FormControl.Feedback>
        </FormGroup>
        <FormGroup >
          <Form.Label>Hobbies</Form.Label>
          <Form.Check {...register("hobbies")} label="Signing"  value="Signing" id="Siginig"></Form.Check>
          <Form.Check {...register("hobbies")} label="Dancing" value="Dancing" id="Dancing"></Form.Check>
          <Form.Check {...register("hobbies")} label="Reading Books" value="Reading Books" id="Reading"></Form.Check>
           <FormControl.Feedback type="invalid">{errors.hobbies?.message}</FormControl.Feedback>
        </FormGroup>
        <FormGroup>
          <FormLabel>Gender</FormLabel>
             <Form.Check type="radio" {...register("gender")} label="Male" value="Male" checked={watch("gender")=="Male"} isInvalid={!!errors.gender}></Form.Check>
              <Form.Check type="radio" {...register("gender")} label="Female" value="Female" checked={watch("gender")=="Female"}  isInvalid={!!errors.gender}></Form.Check>
           <FormControl.Feedback type="invalid">{errors.gender?.message}</FormControl.Feedback>
        </FormGroup>
        <FormGroup>
          <FormLabel>Photo</FormLabel>
        <Controller
  name="photo"
  control={control}
  render={({ field: { onChange }, fieldState: { error } }) => (
    <FormGroup>
      <FormLabel>Photo</FormLabel>
      <FormControl
        type="file"
        accept="image/*"
        isInvalid={!!error}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          handleFileToBase64(e, onChange)
        }
      />
      <FormControl.Feedback type="invalid">{error?.message}</FormControl.Feedback>
    </FormGroup>
  )}
/>
          <FormControl.Feedback type="invalid">{errors.photo?.message}</FormControl.Feedback> 
        </FormGroup>
         <Controller
           name="joiningPeriod"
           control={control}
           render={({field}) => (
            <DatePicker
                selectsRange
                startDate={field.value[0] ?? null}
                endDate={field.value[1] ?? null}
               onChange={(dates: [Date | null, Date | null]) => field.onChange(dates)} 
                isClearable
                placeholderText='Select Joining Period'
                className='form-control'
            />
           )}
           />
           
           {errors.joiningPeriod && (
              <p className='text-danger'>{errors.joiningPeriod.message}</p>
            )}
          <FormControl type="file"></FormControl>
         <Button type='submit'>Submit</Button>
      </Form>
      <div>
         
      </div>
      
    </div>
  )
}

export default RegisterForm

import axios from "axios";
import { config } from "zod";
const baseURL="https://localhost:44362/api"
const axiosInstance = axios.create({
    baseURL,
    headers:{
        "Content-Type":"application/json",
        "Accept":"application/json"
    }
});

axiosInstance.interceptors.request.use(
    (config) => {
        const token= localStorage.getItem("accessToken");
        if(token){
            config.headers.Authorization=`Bearer ${token}`;
        }
        return config;
    },
    (error) =>  Promise.reject(error)
)

axiosInstance.interceptors.response.use(
    response => response ,
    async (error) => {
        const originalURL = error.config;
        if(error.response?.status === 401 && !originalURL._retry){
            originalURL._retry = true;
              if(originalURL.url.includes('/Account/Login')){
                   return Promise.reject(error);
              }
            try{
               const refreshToken = localStorage.getItem("refreshToken");
               if(!refreshToken){
                  localStorage.removeItem('accessToken');
                  localStorage.removeItem('refreshToken');
                  window.location.href='/';
                   return Promise.reject(error);
               }
               const response= await axios.post(`${baseURL}/Account/Refresh`,{refreshToken})
               const accessToken=response.data.accessToken;
               const newRefreshToken=response.data.refreshToken;
               localStorage.setItem("accessToken",accessToken)
              localStorage.setItem("refreshToken",newRefreshToken)
              originalURL.headers.Authorization=`Bearer ${accessToken}`
              return axiosInstance(originalURL);
            }
            catch(refreshError){
                 localStorage.removeItem('accessToken');
                  localStorage.removeItem('refreshToken');
                 
                  window.location.href='/login';
                  return Promise.reject(error);
            }
        }
        return Promise.reject(error);
    }
)


export default axiosInstance;

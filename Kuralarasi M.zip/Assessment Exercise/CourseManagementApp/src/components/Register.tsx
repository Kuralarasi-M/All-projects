import React from 'react'

const Register = () => {
  return (
    <div>
      
    </div>
  )
}

export default Register

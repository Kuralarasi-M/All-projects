import { Navigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode";

interface DecodedToken {
  isAdmin?: boolean | string;
}

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles: ("admin" | "user")[];
}

 const ProtectedRoute = ({ children, allowedRoles }: ProtectedRouteProps) => {
  const token = localStorage.getItem("accessToken");

  if (!token) {
    return <Navigate to="/" replace />;
  }

  try {
    const decoded: DecodedToken = jwtDecode(token);
    const role = decoded.isAdmin === true || decoded.isAdmin === "True" ? "admin" : "user";

    // Check role access
    if (!allowedRoles.includes(role)) {
      return <Navigate to="/" replace />;
    }

    return <>{children}</>;
  } catch (err) {
    console.error("Invalid token:", err);
    return <Navigate to="/" replace />;
  }
}

export default ProtectedRoute;
import React, { useCallback, useEffect, useState } from 'react'
import { Button, FormControl, FormGroup, FormLabel, FormSelect, Table } from 'react-bootstrap'
import { Form } from 'react-router-dom'
import employeeSchema from '../slices/employeeSchema'
import type z from 'zod'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { array, unknown } from 'zod'
import type { isValid } from 'zod/v3'
import axios from 'axios'
import { useDispatch, useSelector } from 'react-redux'
import type { AppDispatch, RootState } from '../store/store'
import type { DepartmentType } from '../slices/employeeSlice'

type EmployeeDataType = z.infer<typeof employeeSchema>

const EmployeeForm = () => {
  const [department, setDepartment] = useState<DepartmentType[]>([]);
  const [department, setDepartment] = useState<DepartmentType[]>([]);
  const dispatch = useDispatch<AppDispatch>();
  let departmentinfo = useSelector((state: RootState) => state.departmentInfo.Department);


  console.log(departmentinfo);

  useEffect(() => {
    const data = useCallback(async () => {
      const response = await axios.get('https://localhost:7023/api/Employee/Departments');
      const dept: DepartmentType[] = await response.data;
      setDepartment(dept);


    }, []);
    data();



  }, [dispatch])

  const { register, control, reset, watch, handleSubmit, setValue, formState: { errors } } = useForm<EmployeeDataType>({
    resolver: zodResolver(employeeSchema),
    defaultValues: {
      employeeId: "",
      firstName: "",
      middleName: "",
      lastName: "",
      email: "",
      phoneNumber: "",
      department: "",
      role: "",
      location: "",
      experience: 0,
      JoiningDate: "",
      CTC: 0
    }
  })
  const salaryCTC = watch("CTC");
  useEffect(() => {

  }, [salaryCTC])

  const formSubmit = (data: EmployeeDataType) => {
    console.log(data);
    const response = axios.post('https://localhost:7023/api/Employee', { data });
    reset()
  }
  return (
    <div className='d-flex'>
      <div className='w-50'>
        <Form onSubmit={handleSubmit(formSubmit)}>
          <div className='d-flex mb-2'>
            <FormGroup>
              <FormLabel>First Name</FormLabel>
              <FormControl type="text" {...register("firstName")} isInvalid={!!errors.firstName} className='form-control' />
              <FormControl.Feedback>{errors.firstName?.message}</FormControl.Feedback>
            </FormGroup>
            <FormGroup>
              <FormLabel>Middle Name</FormLabel>
              <FormControl type="text" {...register("middleName")} isInvalid={!!errors.middleName} className='form-control' />
              <FormControl.Feedback>{errors.middleName?.message}</FormControl.Feedback>
            </FormGroup>
          </div>
          <div className='d-flex mb-2'>
            <FormGroup>
              <FormLabel>Last Name</FormLabel>
              <FormControl type="text" {...register("lastName")} isInvalid={!!errors.lastName} className='form-control' />
              <FormControl.Feedback>{errors.lastName?.message}</FormControl.Feedback>
            </FormGroup>
            <FormGroup>
              <FormLabel>Email</FormLabel>
              <FormControl type="text" {...register("email")} isInvalid={!!errors.email} className='form-control' />
              <FormControl.Feedback>{errors.email?.message}</FormControl.Feedback>
            </FormGroup>
          </div>
          <div className='d-flex mb-2'>
            <FormGroup>
              <FormLabel>Phone Number</FormLabel>
              <FormControl type="text" {...register("phoneNumber")} isInvalid={!!errors.phoneNumber} className='form-control' />
              <FormControl.Feedback>{errors.phoneNumber?.message}</FormControl.Feedback>
            </FormGroup>
            <FormGroup>
              <FormLabel>Department</FormLabel>
              <FormSelect {...register("department")} isInvalid={!!errors.department}>
                <option value="">---Select---</option>
                <option value="HR">HR</option>
                <option value="IT">IT</option>
                <option value="Finance">Finance</option>
                <option value="Marketing">Marketing</option>
              </FormSelect>
              {errors.department && <small className='text-danger '>{errors.department.message}</small>}
            </FormGroup>

          </div>
          <div className='d-flex mb-2'>
            <FormGroup>
              <FormLabel>Roles</FormLabel>
              <FormSelect {...register("role")} isInvalid={!!errors.role}>
                <option value="">---Select---</option>
                <option value="Developer">Developer</option>
                <option value="Tester">Tester</option>
                <option value="DevOps">DevOps</option>
                <option value="Recuiter">Recuiter</option>
                <option value="Payroll Executive">Payroll Executive</option>
              </FormSelect>
              {errors && <small className='text-danger '>{errors.role?.message}</small>}
            </FormGroup>
            <FormGroup>
              <FormLabel>Location</FormLabel>
              <FormSelect {...register("location")} isInvalid={!!errors.location}>
                <option value="">---Select---</option>
                <option value="Chennai">Chennai</option>
                <option value="Pune">Pune</option>
                <option value="Hyderabad">Hyderabad</option>
                <option value="Delhi">Delhi</option>
              </FormSelect>

              {errors && <small className='text-danger '>{errors.role?.message}</small>}
            </FormGroup>
          </div>
          <div className='d-flex mb-2'>
            <FormGroup>
              <FormLabel>Experience</FormLabel>
              <FormControl type="number" {...register('experience')} isInvalid={!!errors.experience} />
              <FormControl.Feedback type="invalid">{errors.experience?.message}</FormControl.Feedback>
            </FormGroup>
            <FormGroup>
              <FormLabel>Joining Date</FormLabel>
              <FormControl type="date" {...register('JoiningDate')} isInvalid={!!errors.JoiningDate} />
              <FormControl.Feedback type="invalid">{errors.JoiningDate?.message}</FormControl.Feedback>
            </FormGroup>
          </div>
          <div className='d-flex mb-2'>
            <FormGroup>
              <FormLabel>CTC</FormLabel>
              <FormControl type="number" {...register('CTC')} isInvalid={!!errors.CTC} />
              <FormControl.Feedback type="invalid">{errors.CTC?.message}</FormControl.Feedback>
            </FormGroup>
          </div>
          <Button type='submit'>Submit</Button>
          <p>Monthly Salary Breakdown</p>
          <Table>
            <thead>
              <tr>
                <th></th>
                <th></th>
              </tr>

            </thead>
          </Table>
        </Form>
      </div>
      <div className='w-50'>

      </div>
    </div>
  )
}

export default EmployeeForm

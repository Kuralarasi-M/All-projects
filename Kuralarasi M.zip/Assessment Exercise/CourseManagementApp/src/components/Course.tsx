import React from 'react'
import CourseForm from './CourseForm'
import CourseTable from './CourseTable'

const Course = () => {
  return (
     <div className='d-flex my-5'>
            <div className='w-50 px-5'><CourseForm /></div>
            <div className='w-50'><CourseTable /></div>
        </div>
  )
}

export default Course

import React from 'react'

const AdminDashBoard = () => {
  return (
    <div>
      <h1>Welcome Admin!.</h1>
    </div>
  )
}

export default AdminDashBoard

import React from 'react'

const UserDashBoard = () => {
  return (
    <div>
      <h1>Welcome User!.</h1>
    </div>
  )
}

export default UserDashBoard

import React, { useEffect } from 'react';
import courseSchema from '../schema/courseSchema';
import type z from 'zod';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button, Form, FormControl, FormGroup, FormLabel } from 'react-bootstrap';
import type { AppDispatch, RootState } from '../store/store';
import { addCourse, fetchCourse, updateCourse } from '../slices/courseSlice';

export type CourseData = z.infer<typeof courseSchema>;

const CourseForm = () => {
  const dispatch = useDispatch<AppDispatch>();
  const selectedCourseData = useSelector((state: RootState) => state.courseInfo.selectedCourse);


  const { register,
    reset,
    formState: { errors },
    handleSubmit,
  } = useForm<CourseData>({
    resolver: zodResolver(courseSchema),
    defaultValues: {
      id: 0,
      name: '',
      durationInMonths: 1,
      minimumRequiredAge: 15,
      startDate: '',
    },
  });

  useEffect(() => {
    if (selectedCourseData) {
      reset(selectedCourseData);
    }
  }, [selectedCourseData, reset]);

  const formSubmit = async (data: CourseData) => {
    const payload = {
      ...data,
      startDate: new Date(data.startDate).toISOString().split('T')[0],
    };

    try {
      if (data.id && data.id > 0) {
        await dispatch(updateCourse(payload)).unwrap();
        console.log('Updated');
      } else {
        await dispatch(addCourse(payload)).unwrap();
        console.log('Added');
      }
       dispatch(fetchCourse());
      reset({
        id: 0,
        name: '',
        durationInMonths: 1,
        minimumRequiredAge: 15,
        startDate: '',
      });
    } catch (err) {
      console.error('Error:', err);
    }
  };

  return (
    <div>
      <Form onSubmit={handleSubmit(formSubmit)}>
        <FormGroup>
          <FormLabel>Name</FormLabel>
          <FormControl type="text" {...register('name')} isInvalid={!!errors.name} />
          <FormControl.Feedback type="invalid">{errors.name?.message}</FormControl.Feedback>
        </FormGroup>

        <FormGroup>
          <FormLabel>Duration In Months</FormLabel>
          <FormControl
            type="number"
            {...register('durationInMonths')}
            isInvalid={!!errors.durationInMonths}
          />
          <FormControl.Feedback type="invalid">
            {errors.durationInMonths?.message}
          </FormControl.Feedback>
        </FormGroup>
        
        <FormGroup>
          <FormLabel>Start Date</FormLabel>
          <FormControl type="date" {...register('startDate')} isInvalid={!!errors.startDate} />
          <FormControl.Feedback type="invalid">{errors.startDate?.message}</FormControl.Feedback>
        </FormGroup>

        <FormGroup>
          <FormLabel>Minimum Required Age</FormLabel>
          <FormControl
            type="number"
            {...register('minimumRequiredAge')}
            isInvalid={!!errors.minimumRequiredAge}
          />
          <FormControl.Feedback type="invalid">
            {errors.minimumRequiredAge?.message}
          </FormControl.Feedback>
        </FormGroup>

        <Button type="submit" className="mt-3">
          {selectedCourseData ? 'Update' : 'Add'}
        </Button>
      </Form>
    </div>
  );
};

export default CourseForm;

import React, { useEffect, useState } from 'react';
import { Button, Table, Spinner, FormControl } from 'react-bootstrap';
import { useDispatch, useSelector } from 'react-redux';
import type { AppDispatch, RootState } from '../store/store';
import { fetchCourse, deleteCourse } from '../slices/courseSlice';

import { selectedCourse } from '../slices/courseSlice';
import type { CourseData } from './CourseForm';

const CourseTable = () => {
  const dispatch = useDispatch<AppDispatch>();
  let course = useSelector((state: RootState) => state.courseInfo.course);
  const [filteredData,setFilteredData] = useState<CourseData[]>([]);
  const [search,setSearch] = useState("");
  useEffect(() => {
  setFilteredData(course);
}, [course]);

  const handleSearch =  (value:string) => {
        setSearch(value);
       const data= course.filter(a => a.name.toLowerCase().includes(value.toLowerCase()));
      console.log(value+"value");

      
      setFilteredData(data);
       console.log("reached");
       
  }
  useEffect(() => {
   dispatch(fetchCourse());
  }, [dispatch]);


  const handleEdit = (course: CourseData) => {
    dispatch(selectedCourse(course)); 
  };

 
  const handleDelete = (id: number | undefined) => {
    if(id){
       dispatch(deleteCourse(id));
    }
    
  };

  

  return (
    <div>
      <h4>Courses</h4>
      <FormControl placeholder='search here' type="text" className='form-control border rounded my-3' onChange={(e)=>handleSearch(e.target.value)}></FormControl>
      <Table striped bordered hover responsive>
        <thead>
          <tr>
            <th>ID</th>
            <th>Course Name</th>
            <th>Duration (Months)</th>
            <th>Minimum Age</th>
            <th>Start Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredData && filteredData.length>0 ? filteredData.map((c) => (
            <tr key={c.id}>
              <td>{c.id}</td>
              <td>{c.name}</td>
              <td>{c.durationInMonths}</td>
              <td>{c.minimumRequiredAge}</td>
              <td>{new Date(c.startDate).toLocaleDateString()}</td>
              <td>
                <Button
                  variant="warning"
                  size="sm"
                  className="me-2"
                  onClick={() => handleEdit(c)}
                >
                  Edit
                </Button>
                <Button
                  variant="danger"
                  size="sm"
                  onClick={() => handleDelete(c.id)}
                >
                  Delete
                </Button>
              </td>
            </tr>
          )) : <tr>
            <td colSpan={6}>No Data Available</td></tr>}
        </tbody>
      </Table>
    </div>
  );
};

export default CourseTable;

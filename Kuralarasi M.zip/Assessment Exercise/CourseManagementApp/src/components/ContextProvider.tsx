import React, { createContext, useContext, useEffect, useState } from "react";
import { jwtDecode } from "jwt-decode";

interface DecodedToken {
  isAdmin?: boolean | string;
}

interface AuthContextType {
  role: string | null;
  login: (token: string, refreshToken: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType>({
  role: null,
  login: () => {},
  logout: () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRole] = useState<string | null>(null);

  const decodeRole = (token: string): string | null => {
    try {
      const decoded: DecodedToken = jwtDecode(token);
      return decoded.isAdmin === true || decoded.isAdmin === "True" ? "admin" : "user";
    } catch {
      return null;
    }
  };

  const login = (token: string, refreshToken: string) => {
    localStorage.setItem("accessToken", token);
    localStorage.setItem("refreshToken", refreshToken);
    setRole(decodeRole(token));
  };

  const logout = () => {
    localStorage.removeItem("accessToken");
    localStorage.removeItem("refreshToken");
    setRole(null);
  };

  useEffect(() => {
    const token = localStorage.getItem("accessToken");
    if (token) {
      setRole(decodeRole(token));
    }
  }, []);

  return (
    <AuthContext.Provider value={{ role, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);

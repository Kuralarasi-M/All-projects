import { Button, Form, FormControl, FormGroup, FormLabel } from "react-bootstrap"
import schema from '../schema/register'
import type z from 'zod'
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import axiosInstance from '../api/appAPI';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './ContextProvider';
import { jwtDecode } from 'jwt-decode';


type LoginType = z.infer<typeof schema>;

const Login = () => {
  const navigate = useNavigate();
  const { login } = useAuth(); 
  const { register, formState: { errors }, handleSubmit } = useForm<LoginType>({
    resolver: zodResolver(schema),
    defaultValues: {
      email: "",
      password: ""
    }
  });

  const formSubmit = async (data: LoginType) => {

    try {
      const res = await axiosInstance.post("/Account/Login", data);
      const { accessToken, refreshToken } = res.data;
      login(accessToken, refreshToken); 
      const decoded:any =  jwtDecode(accessToken);
      const isAdmin=decoded.isAdmin === true || decoded.isAdmin === 'True';
      if(isAdmin){
         navigate("/admin/dashboard"); 
         return;
      }
      else{
         navigate("/user/dashboard"); 

      }
      
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  return (
    <div className='mt-5'>
      <div className='w-50 m-auto'>
        <Form className='border rounded p-5' onSubmit={handleSubmit(formSubmit)}>
          <FormGroup className='mb-2'>
            <FormLabel>Email</FormLabel>
            <FormControl {...register("email")} type="email" isInvalid={!!errors.email} />
            <FormControl.Feedback type='invalid'>{errors.email?.message}</FormControl.Feedback>
          </FormGroup>

          <FormGroup className='mb-2'>
            <FormLabel>Password</FormLabel>
            <FormControl {...register("password")} type="password" isInvalid={!!errors.password} />
            <FormControl.Feedback type='invalid'>{errors.password?.message}</FormControl.Feedback>
          </FormGroup>

          <Button type="submit">Login</Button>
        </Form>
      </div>
    </div>
  );
};

export default Login;

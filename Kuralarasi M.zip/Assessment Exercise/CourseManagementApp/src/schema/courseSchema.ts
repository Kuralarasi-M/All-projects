import z from 'zod';
const courseSchema = z.object({
    id:z.coerce.number().default(0).optional(),
    name:z.string().nonempty("Name is Required").min(2,"minimum 2 letters required").max(30,"maximum 30 letters required"),
    durationInMonths:z.coerce.number().min(1,"minimum 1 month").max(24,"maximum 24 month"),
   startDate:z.string().nonempty("Start Date is Required"), 
    minimumRequiredAge:z.coerce.number().min(15,"Age must be altleast  15 above.").max(100,"Age must be maximum 100")
})

export default courseSchema;

  
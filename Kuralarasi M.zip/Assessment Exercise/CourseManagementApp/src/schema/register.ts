import z from 'zod';

const schema = z.object({
    email:z.string().nonempty("Email is required!.").email("Invalid Email").min(8,"minimum 8 characters required!").max(40,"maximum 40 cgharacters required!."),
    password:z.string().nonempty("Password is Required!").min(6,"minimum 6 characters required!").max(15,"maximum 15 cgharacters required!.")
})

export default schema;
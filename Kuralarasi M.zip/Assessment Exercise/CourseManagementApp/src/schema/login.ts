import z from 'zod';
const registerSchema =  z.object({
    name:z.string().nonempty("Name is Required").min(3,"minimum 3 letters required").max(8,"maximum 8 letters required"),
    email:z.string().nonempty("Email is required!.").email("Invalid Email").min(8,"minimum 8 characters required!").max(30,"maximum 30 cgharacters required!."),
    password:z.string().nonempty("Password is Required!").min(6,"minimum 6 characters required!").max(15,"maximum 15 cgharacters required!.")
})
export default registerSchema;
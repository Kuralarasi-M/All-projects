import { createAsyncThunk, createSlice, type PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";

export interface DepartmentType {
    DepartmentId: string,
    DepartmentName: string
};
interface DepartmentState {
    Department: DepartmentType[],

}
const initialState: DepartmentState = {
    Department: [],

}




const departmentSlice = createSlice({
    name: 'Department',
    initialState,
    reducers: {
        setDepartments: (state, action: PayloadAction<DepartmentType[]>) => {
            state.Department = action.payload;
        },
    },

})

export default departmentSlice.reducer;
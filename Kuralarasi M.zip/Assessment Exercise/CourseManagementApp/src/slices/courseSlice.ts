import axiosInstance from "../api/appAPI";
import type { CourseData } from "../components/CourseForm";
import { createSlice, createAsyncThunk, type PayloadAction } from '@reduxjs/toolkit';
interface CourseState {
    course:CourseData[],
    loading:boolean,
    error:string | null,
    selectedCourse:CourseData | null
}

const initialState:CourseState = {
    course : [],
    loading:false,
    error:null,
    selectedCourse: null,
}

export const fetchCourse = createAsyncThunk('/fetch/course',async ()=>{
     const res= await axiosInstance.get('/Course/GetCourses');
     return res.data as CourseData[]
})
export const addCourse = createAsyncThunk('/add/course',async(course:CourseData) => {
    const res = await axiosInstance.post('/Course/Add',course);
    return res.data as CourseData
})
export const updateCourse = createAsyncThunk('/update/course',async(course:CourseData) => {
    const res=await axiosInstance.put('/Course/Edit',course);
    return res.data as CourseData
})
export const deleteCourse = createAsyncThunk('/delete/course',async(id:number)=>{
    await axiosInstance.delete(`/Course/Delete/${id}`);
    return id;
})
const courseSlice = createSlice({
    name:'course',
    initialState,
    reducers:{
        selectedCourse:(state,action:PayloadAction<CourseData>) =>{
              state.selectedCourse=action.payload;
        } 
    },
    extraReducers(builder) {
        builder.addCase(fetchCourse.pending, (state) => { state.loading = true; state.error = null; })
        .addCase(fetchCourse.fulfilled,(state,action:PayloadAction<CourseData[]>) => {
              state.course=action.payload;
              state.loading=false;
        })
        .addCase(fetchCourse.rejected,(state) => {state.error="Fail to Fetch";state.loading=false})

        .addCase(addCourse.fulfilled,(state,action:PayloadAction<CourseData>) => {state.course.push(action.payload)})
        .addCase(updateCourse.fulfilled, (state, action: PayloadAction<CourseData>) => {
        state.course = state.course.map(c => c.id === action.payload.id ? action.payload : c);
      })
      .addCase(deleteCourse.fulfilled, (state, action: PayloadAction<number>) => {
        state.course = state.course.filter(c => c.id !== action.payload);
      });
    },
})
export const { selectedCourse } = courseSlice.actions;
export default courseSlice.reducer;
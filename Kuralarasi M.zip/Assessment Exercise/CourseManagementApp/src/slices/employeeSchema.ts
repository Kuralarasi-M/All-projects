
import z from 'zod';

const employeeSchema = z.object({
    employeeId:z.string().optional(),
    firstName:z.string().nonempty("First name is required!.").min(3,"Minimum 3 letters required!.")
    .max(30,"Maximum 30 letters only allowed"),
    middleName:z.string().min(3,"Minimum 3 letters required!.").max(30,"Maximum 30 letters only allowed").optional(),
    lastName:z.string().nonempty("Last name is required!.").min(3,"Minimum 3 letters required!.")
    .max(30,"Maximum 30 letters only allowed"),
    email:z.string().nonempty("Email is required!.").email("Invalid Email").min(8,"minimum 8 letters reuired!.")
    .max(40,"Maximum 40 letters only allowed"),
    phoneNumber:z.string().nonempty("Phone no is required").min(10,"Invalid Mobile no.").max(14,"Invalid mobile no.")
    .regex(/^[0-9\-+ ]+$/,"Enter Phone-number in correct Format."),
    department:z.string().nonempty("Select your Department."),
    role:z.string().nonempty("Select your Role."),
    location:z.string().nonempty("Select your Location."),
    experience:z.coerce.number().min(0,"Experience must be in Positive")
    .max(30,"Maximum 30 years Experience only Allowed.").default(0),
    JoiningDate:z.string(),
    CTC:z.coerce.number().min(100000,"CTC minimum 1 Lakh is allowed").max(2000000,"Maximum 20 Lakh CTC is Allowed!.")
})

export default employeeSchema;

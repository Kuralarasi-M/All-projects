import {Routes, Route } from "react-router-dom";
import NavBar from "./components/NavBar";
import Login from "./components/Login";
import About from "./components/About";
import ProtectedRoute from "./components/ProtectedRoute";
import AdminDashBoard from "./components/AdminDashBoard";
import UserDashBoard from "./components/UserDashBoard";
import UserList from "./components/UserList";
import Home from "./components/Home";
import Course from "./components/Course";
import EmployeeForm from "./components/EmployeeForm";


const App = () => {
  return (
    <>
    <EmployeeForm></EmployeeForm>
    {/* <NavBar />
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/about" element={<About />} />
        <Route path="/home" element={<Home/>} /> */}
        {/* Admin routes */}
        {/* <Route
          path="/admin/dashboard"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <AdminDashBoard />
            </ProtectedRoute>
          }
        />
         <Route
          path="/admin/course"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <Course />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/users"
          element={
            <ProtectedRoute allowedRoles={["admin"]}>
              <UserList />
            </ProtectedRoute>
          }
        /> */}

        {/* User routes */}
        {/* <Route
          path="/user/dashboard"
          element={
            <ProtectedRoute allowedRoles={["user"]}>
              <UserDashBoard />
            </ProtectedRoute>
          }
        />
      </Routes> */}
    </>
      
  
  );
}

export default App;

import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Table } from 'react-bootstrap'
import type { userType } from './StudentForm'

type Props={
  mystudentData:userType[],
 updateStudent:(user:userType)=> void
 deleteStudent:(user:userType) => void
}

const StudentTable = ({mystudentData,updateStudent,deleteStudent}:Props) => {
  return (
    <div className=" mx-2">
        <Table className="table table-bordered table-striped table-hover table-responsive " variant="primary">
            <thead >
                 <tr>
                    <th>Id</th>
                    <th>Photo</th>
                   <th>Name
                    </th>
                    <th>Email</th> 
                    <th>DOB</th>
                    
                    <th>Age</th>
                     <th>Course</th>
                    <th>EnrollmentDate</th>
                    <th>Status</th>
                    <th>PhoneNo</th>
                    <th>Action</th>
                 </tr>
            </thead>
            <tbody>
                
                {mystudentData.length>0 ? (mystudentData.map((s,index) => (
                    <tr key={index}>
                        <td>{s.id}</td>
                        <td>{s.photo && <a href={s.photo} download={s.name}>
                            <img src={s.photo} alt={s.name} width={100} className='rounded'/>
                            </a> }</td>

                        <td>{s.name}</td>
                        <td>{s.email}</td>
                        <td>{s.dob}</td>
                        <td>{s.age}</td>
                        <td>{s.course}</td>
                        <td>{s.enrollmentDate}</td>
                        <td>{s.status}</td>
                        <td>{s.phoneNo}</td>
                        
                        <td>
                            <Button onClick={() => updateStudent(s) } className='m-1 bg-warning'>Update</Button>
                            <Button onClick={() => deleteStudent(s)} className='m-1 bg-danger'>Delete</Button>
                        </td>
                    </tr>
                ))) : (
                     <tr>
                        <td colSpan={10}>
                            <p className='text-center'>No data found</p>
                        </td>
                     </tr>
                )

            
                    
                }
            </tbody>
        </Table>
    </div>
  )
}

export default StudentTable

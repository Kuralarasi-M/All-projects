import React, { useEffect, useRef, useState } from 'react'
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { useForm, type SubmitHandler } from "react-hook-form";
import { schema } from './schema/schema';
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

import StudentTable from './StudentTable';

import NavBar from './NavBar';
import { Modal } from 'react-bootstrap';


export type studentType = z.infer<typeof schema>;
export type userType = {
  id: number,
  name: string,
  email: string,
  age: string,
  enrollmentDate: string,
  dob: string;
  phoneNo: string,
  photo?: string,
  status: "Active" | "Inactive",
  course: string
}
const StudentForm = () => {
  const [studentData, setStudentData] = useState<userType[]>([]);
  const [filterData, setFilterData] = useState<userType[]>([]);

  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const [enrollStart, setEnrollStart] = useState("");
  const [enrollEnd, setenrollEnd] = useState("");

  const [nextId, setNextId] = useState(1);
  const [editId, setEditId] = useState<number | null>(null);
  const [studentName, setStudentName] = useState("");

  const [preview, setPreview] = useState<string | undefined>("");

  const [existingPhoto, setExistingPhoto] = useState<string | undefined>("");
  const [isDirty, setIsDirty] = useState(false);

  const [showModal, setShowModal] = useState(false);

  const { register, handleSubmit, formState: { errors }, reset, watch, setError, setFocus, setValue } =
    useForm<studentType>({
      resolver: zodResolver(schema),
      defaultValues: {
        name: "",
        email: "",
        dob: "",
        enrollmentDate: "",
        phoneNo: "",
        course: "",
        status: undefined,
        photo: ""
      }
    });


  const fileInput = watch("photo");
  useEffect(() => {
    if (fileInput && fileInput.length > 0 && fileInput[0] instanceof Blob) {
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result as string);
      reader.readAsDataURL(fileInput[0]);
    }
  }, [fileInput]);

  const submitHandle:SubmitHandler<userType> = (data: userType) => {

    if (studentData.some(s => s.email === data.email && s.id !== editId)) {
      setError("email", { type: "manual", message: "Email must be unique" });
      setFocus("email");
      return;
    }

    const photoBase64 = preview || existingPhoto;

    if (!photoBase64 && editId == null) {
      setError("photo", { type: "manual", message: "You must upload a photo" });


      return;
    }

    const user: userType = {
      ...data,
      id: editId ?? nextId,
      photo: photoBase64,
    };




    if (editId == null) {
      setStudentData(prev => [...prev, user]);
      setNextId(prev => prev + 1);

      setPreview("");
      setExistingPhoto("");

    } else {

      setStudentData(prev => prev.map(a => (a.id === editId ? user : a)));
      setEditId(null);
      setPreview("");
      setExistingPhoto("");
    }
    reset({
      name: "",
      email: "",
      age: "",
      dob: "",
      enrollmentDate: "",
      phoneNo: "",
      photo: undefined,
      status: undefined,
      course: "",
    });

    setPreview("");
    setExistingPhoto("");

  };


  useEffect(() => {
    if (studentData.length > 0) {
      localStorage.setItem("users", JSON.stringify(studentData));
      localStorage.setItem("nextId", JSON.stringify(nextId))
    }
  }, [studentData, nextId])

  useEffect(() => {
    const subscription = watch((value) => {
      const { photo, status, ...rest } = value;
      localStorage.setItem("studentForm", JSON.stringify(rest));
    });
    return () => subscription.unsubscribe();
  }, [watch]);

  useEffect(() => {
    const user = localStorage.getItem("users");
    const id = localStorage.getItem("nextId")
    if (user != null) {
      setStudentData(JSON.parse(user))
    }

    if (id != null) {
      setNextId(JSON.parse(id))
    }

  }, [])
  const dob = watch("dob");
  useEffect(() => {
    const subscription = watch((value) => {
      const { photo, status, ...rest } = value;
      localStorage.setItem("studentForm", JSON.stringify(rest));

      const hasData = Object.values(rest).some(v => v !== "" && v !== null && v !== undefined);
      setIsDirty(hasData);
    });
    return () => subscription.unsubscribe();
  }, [watch]);


  const watchedForm = watch();

  useEffect(() => {
    const hasChanges = Object.values(watchedForm).some(
      val => val !== "" && val !== undefined && val !== null
    );
    setIsDirty(hasChanges);
  }, [watchedForm]);

  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (!isDirty) return;

      e.preventDefault();
      e.returnValue = "";


      setShowModal(true);
    };

    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [isDirty]);


  useEffect(() => {
    if (dob) {
      const today = new Date();
      const userDOB = new Date(dob);

      let age = today.getFullYear() - userDOB.getFullYear();

      const isBirthdayPassed =
        today.getMonth() > userDOB.getMonth() ||
        (today.getMonth() === userDOB.getMonth() && today.getDate() >= userDOB.getDate());

      const userAge = isBirthdayPassed ? age.toString() : (age - 1).toString();

      setValue("age", userAge);
    }
  }, [dob, setValue]);



  const updateStudent = (student: userType) => {
    setEditId(student.id);
    setExistingPhoto(student.photo);
    reset({
      ...student,
      photo: undefined,
    });
    setPreview(student.photo || "");
  }

  const deleteStudent = (student: userType) => {
    if (window.confirm(`Do you want to delete ${student.name} record?`)) {
      setStudentData(prev => prev.filter(s => s.id != student.id))

    }
  }

  const searchByName = () => {
    setFilterData(studentData)
    if (studentName) {
      setStudentData(prev => prev.filter(s => s.name.toLowerCase().includes(studentName.toLowerCase())))
    }


  }

  const handlePhotoPreview = (files?: FileList | null) => {
    if (files && files.length > 0) {
      const reader = new FileReader();
      reader.onload = () => setPreview(reader.result as string);
      reader.readAsDataURL(files[0]);
    } else {
      setPreview("");
    }
  };
  const handleResetClick = () => {
    if (isDirty) {

      setShowModal(true);
    } else {

      reset({
        name: "",
        email: "",
        age: "",
        dob: "",
        enrollmentDate: "",
        phoneNo: "",
        photo: "",
        status: "Active",
        course: "",
      });
      setPreview("");
      setExistingPhoto("");
      setStudentData(filterData);
    }
  };
  const resetData = () => {
    setStudentData(filterData)
  }

  const dobSearch = () => {
    setFilterData(studentData)
    const start = new Date(startDate);
    const end = new Date(endDate);
    console.log(start);

    if (!isNaN(start.getDate()) && !isNaN(end.getDate())) {
      setStudentData(prev => prev.filter(s => new Date(s.dob) > start && new Date(s.dob) < end))
    }

  }
  const enrollSearch = () => {
    setFilterData(studentData)
    const start = new Date(enrollStart);
    const end = new Date(enrollEnd);
    if (!isNaN(start.getDate()) && !isNaN(end.getDate())) {
      setStudentData(prev => prev.filter(s => new Date(s.enrollmentDate) > start && new Date(s.enrollmentDate) < end))
    }
  }

  const handleSort = (value: string) => {
    switch (value) {
      case "nameAsc":
        setFilterData(studentData)
        setStudentData(prev => [...prev].sort((a, b) => a.name.localeCompare(b.name)))
        break;
      case "nameDesc":
        setFilterData(studentData)
        setStudentData(prev => [...prev].sort((a, b) => b.name.localeCompare(a.name)))
        break;
      case "dobAsc":
        setFilterData(studentData)
        setStudentData(prev => [...prev].sort((a, b) => a.dob.localeCompare(b.dob)))
        break;
      case "dobDesc":
        setFilterData(studentData)
        setStudentData(prev => [...prev].sort((a, b) => b.dob.localeCompare(a.dob)))
        break;
      case "enrollAsc":
        setFilterData(studentData)
        setStudentData(prev => [...prev].sort((a, b) => a.enrollmentDate.localeCompare(b.enrollmentDate)))
        break;
      case "enrollDesc":
        setFilterData(studentData)
        setStudentData(prev => [...prev].sort((a, b) => b.enrollmentDate.localeCompare(a.enrollmentDate)))
        break;
      default:
        break;
    }

  }
  return (
    <div>

      <div className='m-3'>
        <h1 className='text-center'>Student Dashboard</h1>
        {/* <Button onClick={handleResetClick} className='bg-success mx-2'>Reset</Button> */}
      </div>
      <div className=" m-5">


        <Form onSubmit={handleSubmit(submitHandle)} className='border p-5 w-25 m-auto rounded' >
          <Form.Group className='m-1'>
            <Form.Label>Name</Form.Label>
            <Form.Control type="text" {...register("name")} isInvalid={!!errors.name} />
            <Form.Control.Feedback type="invalid">{errors.name?.message}</Form.Control.Feedback>
          </Form.Group>
          <Form.Group>
            <Form.Label>Email</Form.Label>
            <Form.Control type="email"  {...register("email")} isInvalid={!!errors.email} />
            <Form.Control.Feedback type="invalid">{errors.email?.message}</Form.Control.Feedback>
          </Form.Group>
          <Form.Group>
            <Form.Label>DOB</Form.Label>
            <Form.Control type="date"  {...register("dob")} isInvalid={!!errors.dob} />
            <Form.Control.Feedback type="invalid">{errors.dob?.message}</Form.Control.Feedback>
          </Form.Group>
          <Form.Group>
            <Form.Label>Age</Form.Label>
            <Form.Control type="number" disabled {...register("age")}></Form.Control>
          </Form.Group>
          <Form.Group>
            <Form.Label>Course</Form.Label>
            <Form.Select {...register("course")} isInvalid={!!errors.course}>
              <option value="">---Select---</option>
              <option value="Bio-Maths">Bio-Maths</option>
              <option value="Computer-Maths">Computer-Maths</option>
              <option value="Commerce">Commerce</option>
              <option value="Pure-Science ">Pure-Science</option>
            </Form.Select>
            {errors.course && <small className='text-danger '>{errors.course.message}</small>}
          </Form.Group>
          <Form.Group>
            <Form.Label>EnrollmentDate</Form.Label>
            <Form.Control type="date"  {...register("enrollmentDate")} isInvalid={!!errors.enrollmentDate} />
            <Form.Control.Feedback type="invalid">{errors.enrollmentDate?.message}</Form.Control.Feedback>
          </Form.Group>
          <Form.Group>
            <Form.Label>Phone Number</Form.Label>
            <Form.Control type="number"  {...register("phoneNo")} isInvalid={!!errors.phoneNo} />
            <Form.Control.Feedback type="invalid">{errors.phoneNo?.message}</Form.Control.Feedback>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Status</Form.Label>
            <Form.Check type="radio" value="Active" label="Active" {...register("status")} checked={watch("status") === "Active"}>
            </Form.Check>
            <Form.Check type="radio" value="Inactive" label="Inactive" {...register("status")} checked={watch("status") === "Inactive"}></Form.Check>

            {errors.status && <p className="text-danger">{errors.status.message}</p>}
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label>Photo</Form.Label>
            <Form.Control type="file" accept="image/*" {...register("photo")} onChange={(e) => handlePhotoPreview((e.target as HTMLInputElement).files)}
              isInvalid={!!errors.photo}
            />
            {preview && (
              <img src={preview} alt="Preview" width={150} className="mt-2" />
            )}
            {errors.photo?.message && (
              <p className="text-danger">{errors.photo.message}</p>
            )}


          </Form.Group>

          <Button type="submit">{editId ? "Update Student" : "Add Student"}</Button>
        </Form>
        <div>
          <div className='d-flex m-5'>
            <div className='d-flex mx-2'>
              <Form.Control type="text" value={studentName} onChange={s => setStudentName(s.target.value)} placeholder='search by name' />
              <Button onClick={searchByName} className=' mx-2'>Search</Button>
              <Button onClick={resetData} className='bg-success mx-2'>Reset</Button>
            </div>
            <div className='d-flex flex-column mb-2'>
              <div>
                <Form.Select onChange={e => handleSort(e.target.value)}>
                  <option value="">Sort By</option>
                  <option value="nameAsc">Name Ascending</option>
                  <option value="nameDesc">Name Descending</option>
                  <option value="dobAsc">DOB Ascending</option>
                  <option value="dobDesc">DOB Descending</option>
                  <option value="enrollAsc">Enrollment Date Ascending</option>
                  <option value="enrollDesc">Enrollment Date Descending</option>

                </Form.Select>

              </div>

            </div>
          </div>

          <div className='d-flex m-2'>
            <div className='border p-2 m-4 text-center'>
              <p>Filter by DOB</p>
              <div className='d-flex mx-2'>
                <Form.Control type="date" value={startDate} onChange={s => setStartDate(s.target.value)} placeholder='select Starting date' />
                <Form.Control type="date" value={endDate} onChange={s => setEndDate(s.target.value)} placeholder='select Ending date' />
                <Button onClick={dobSearch} className=' mx-2'>Search</Button>
                <Button onClick={resetData} className='bg-success mx-2'>Reset</Button>
              </div>
            </div>
            <div className='border p-2 m-4 text-center'>
              <p>Filter by Enrollment</p>
              <div className='d-flex mx-2'>
                <Form.Control type="date" value={enrollStart} onChange={s => setEnrollStart(s.target.value)} placeholder='select Starting date' />
                <Form.Control type="date" value={enrollEnd} onChange={s => setenrollEnd(s.target.value)} placeholder='select Ending date' />
                <Button onClick={enrollSearch} className=' mx-2'>Search</Button>
                <Button onClick={resetData} className='bg-success mx-2'>Reset</Button>
              </div>
            </div>

          </div>
          <StudentTable mystudentData={studentData} updateStudent={updateStudent} deleteStudent={deleteStudent}></StudentTable>
        </div>
        {isDirty && showModal && (
          <div className="modal-overlay">
            <div className="modal-content p-4">
              <h5>Do you want to add or discard the form changes?</h5>
              <div className="mt-3 d-flex justify-content-end gap-2">
                <Button
                  onClick={() => {
                    // Trigger form submission
                    handleSubmit(submitHandle);
                    setShowModal(false);
                  }}
                >
                  Add
                </Button>
                <Button variant="secondary" onClick={() => {
                  reset({
                    name: "",
                    email: "",
                    age: "",
                    dob: "",
                    enrollmentDate: "",
                    phoneNo: "",
                    photo: undefined,
                    status: undefined,
                    course: "",
                  });
                  setPreview("");
                  setExistingPhoto("");
                  setIsDirty(false);
                  setShowModal(false);
                  localStorage.removeItem("studentForm");
                  setStudentData(filterData); // optional, reset table view
                }}>Discard</Button>
              </div>
            </div>
          </div>
        )}

        <Modal show={showModal} onHide={() => setShowModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>Unsaved Changes</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            You have unsaved changes. Do you want to save or discard them?
          </Modal.Body>
          <Modal.Footer>
            <Button
              variant="secondary"
              onClick={() => {
                // Discard changes
                localStorage.removeItem("studentForm"); // clear saved form
                setShowModal(false);
              }}
            >
              Discard
            </Button>
            <Button
              variant="primary"
              onClick={() => {
                // Save form data to localStorage
                localStorage.setItem(
                  "studentForm",
                  JSON.stringify({ formData: watchedForm, savedEditId: editId })
                );
                setShowModal(false);
              }}
            >
              Save
            </Button>
          </Modal.Footer>
        </Modal>

      </div>
    </div>

  )
}

export default StudentForm



import { Route, Routes } from 'react-router-dom'
import './App.css'
import StudentForm, { type userType } from './StudentForm'

import StudentTable from './StudentTable'
import NavBar from './NavBar'

function App() {
  

  return (
    <>
      <div>
        <NavBar></NavBar>
       
        <StudentForm></StudentForm>
        
      </div>
       
    </>
  )
}

export default App

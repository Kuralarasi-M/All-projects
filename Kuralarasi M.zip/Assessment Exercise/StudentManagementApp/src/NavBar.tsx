import React from 'react'
import { Container, Nav ,Navbar, NavbarBrand, NavbarCollapse, NavbarToggle} from 'react-bootstrap'

const NavBar = () => {
  return (
    <div>
       <Navbar bg="dark" variant="dark" expand="lg">
      <Container>
        {/* Brand on the left */}
        <NavbarBrand>Student Management App</NavbarBrand>

        <NavbarToggle aria-controls="basic-navbar-nav" />
        <NavbarCollapse id="basic-navbar-nav">
          {/* Menu on the right */}
          <Nav className="ms-auto">
            <Nav.Link>Home</Nav.Link>
            <Nav.Link>Form</Nav.Link>
            <Nav.Link >User</Nav.Link>
            <Nav.Link >About</Nav.Link>
          </Nav>
        </NavbarCollapse>
      </Container>
    </Navbar>
    </div>
  )
}

export default NavBar

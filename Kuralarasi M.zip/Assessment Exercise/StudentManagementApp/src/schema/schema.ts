import { z } from "zod";

export const schema = z.object({
  name: z
    .string()
    .nonempty("Name is Required!.")
    .min(3, "Minimum 3 characters Required")
    .regex(/^[a-zA-Z ]{3,}$/, "Only characters allowed"),

  email: z.string().nonempty("Email is Required"),

  dob: z
    .string()
    .nonempty("Select your DOB.")
    .refine((date) => new Date(date) < new Date(), "Date can't be in the future")
    .refine((date) => {
      const today = new Date();
      const userDOB = new Date(date);

      const age = today.getFullYear() - userDOB.getFullYear();

      const isBirthdayPassed =
        today.getMonth() > userDOB.getMonth() ||
        (today.getMonth() === userDOB.getMonth() &&
          today.getDate() >= userDOB.getDate());

      const finalAge = isBirthdayPassed ? age : age - 1;

      return finalAge >= 5;
    }, "Age must be 5 or above!."),

  age: z.string(),

  enrollmentDate: z.string().nonempty("Date is Required"),

  phoneNo: z.string().nonempty("Phone no Required"),

  course: z.string().nonempty("Must Select one Course"),
 photo: z.any().optional(),

  status: z.enum(["Active", "Inactive"], {
   message: "Select status",
  }),
});





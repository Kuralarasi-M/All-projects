import React from 'react';

type Props = {
  name: string;
  
};

const Item: React.FC<Props> = ({ name}) => {
  return <div onClick={() => (name)}>{name}</div>;
};

export default Item;

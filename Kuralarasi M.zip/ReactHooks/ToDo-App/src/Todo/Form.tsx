import { useEffect, useState,useRef } from "react";
import type { ToDoType } from "./ToDo";
import React from "react";

type Props = {
  addOrUpdateTodo: (todo: Omit<ToDoType, "id">, id?: number) => void;
  editingTodo: ToDoType | null;
};


const Form = ({ addOrUpdateTodo, editingTodo }: Props) => {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState(1);
  const [isCompleted, setIsCompleted] = useState(false);
  const [error, setError] = useState("");
  const inputRef = useRef<HTMLInputElement | null>(null);
console.log("form Child Rendering");
useEffect(() => {
  if (editingTodo) {
    setName(editingTodo.name);
    setDescription(editingTodo.description);
    setPriority(editingTodo.priority);
    setIsCompleted(editingTodo.isCompleted);
  }
}, [editingTodo]);
useEffect(() => {
  inputRef.current?.focus();
}, []);

const handleSubmit = (e: React.FormEvent) => {
  e.preventDefault();

  if (name.trim() === "") {
    setError("Name is required");
    inputRef.current?.focus();
    return;
  }

  setError("");

  addOrUpdateTodo({ name, description, priority, isCompleted }, editingTodo?.id);

  setName("");
  setDescription("");
  setPriority(1);
  setIsCompleted(false);
};

  return (
    <form onSubmit={handleSubmit} className="d-flex flex-column w-50 p-5 border bgcolor">
      <label>Name:</label>
      <input type="text"  value={name} ref={inputRef} onChange={e => setName(e.target.value)} />
       {error && <p style={{ color: "red", fontSize: "0.9rem" }}>{error}</p>}
      <label>Description:</label>
      <input type="text" value={description} onChange={e => setDescription(e.target.value)} />

      <label>Priority:</label>
      <input type="number"value={priority} onChange={e => setPriority(Number(e.target.value))} />

      <label>Is Completed:</label>
      <div className="m-2">
        <input type="radio" name="isCompleted" value="true" checked={isCompleted} onChange={() => setIsCompleted(true)} /> True
        <input type="radio" name="isCompleted" value="false" checked={!isCompleted} onChange={() => setIsCompleted(false)} /> False
      </div>
      
      <button type="submit">{editingTodo ? "Update" : "Add"} Todo</button>
    </form>
  );
};

export default React.memo(Form);

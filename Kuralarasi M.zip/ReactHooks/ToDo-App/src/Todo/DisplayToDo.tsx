import React from "react";
import type { ToDoType } from "./ToDo";

type Props = {
  todos: ToDoType[];
  deleteTodo: (id: number) => void;
  editTodo: (id: number) => void;
};

const DisplayToDo = ({ todos, deleteTodo, editTodo }: Props) => {
  console.log("Display Child Rendering");
  return (
    <div>
      {todos.map(todo => (
        <div key={todo.id} className="border w-80 m-auto p-3 mb-2 bgcolor">
          <p>Id: {todo.id}</p>
          <p>Name: {todo.name}</p>
          <p>Description: {todo.description}</p>
          <p>Priority: {todo.priority}</p>
          <p>Completed: {todo.isCompleted ? "Yes" : "No"}</p>
          <button onClick={() => deleteTodo(todo.id)}>Delete</button>
          <button onClick={() => editTodo(todo.id)}>Edit</button>
        </div>
      ))}
    </div>
  );
};

export default React.memo(DisplayToDo);

import {useState} from 'react';

import useTheme from './CustomHook';

const   Theme = ()=>{
    
    
    const {themeColor,switchTheme}= useTheme();
     
    
    return (
        <>
      
         <div style={themeColor} className="setWidth">
          
          <button onClick={switchTheme}>Theme Switch</button>
          <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Alias laboriosam velit sunt, numquam vero temporibus, soluta odio totam, rerum ratione impedit voluptatem assumenda dolor. Quasi unde reprehenderit repellat laboriosam vitae!</p>
         </div>
       
        </>
    )
}
export default Theme;
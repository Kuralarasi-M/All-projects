import { useCallback, useState ,useMemo, useRef,useEffect} from "react"
import AddToDo from "./DisplayToDo"; 
import Form from "./Form";
export type ToDoType = {
   id: number; 
  name: string;
  description: string;
  priority: number;
  isCompleted: boolean;
};
const  ToDo = () =>{
const [count, setcount] = useState(1);
const [todos, setTodos] = useState<ToDoType[]>([]); 
const [editingTodo, setEditingTodo] = useState<ToDoType | null>(null);
  const editCountRef = useRef(0);
const [nextId, setNextId] = useState(1);
  useEffect(() => {
    if (todos.length > 0) { 
      localStorage.setItem("todos", JSON.stringify(todos));
    }
  }, [todos]);

useEffect(() => {
    const savedTodos = localStorage.getItem("todos");
    if (savedTodos) {
      setTodos(JSON.parse(savedTodos));
    }
  }, []);
  const addOrUpdateTodo = useCallback(
  (todo: Omit<ToDoType, "id">, id?: number) => {
    if (id != null) {
    
      setTodos(prev => prev.map(t => (t.id === id ? { ...t, ...todo, id } : t)));
       editCountRef.current += 1;
      setEditingTodo(null);
    } else {
     
      const newTodo = { ...todo, id: nextId };
      setTodos(prev => [...prev, newTodo]);
      setNextId(prev => prev + 1); 
    }
  },
  [nextId]
);

     console.log("Rendering");
     
     const deleteTodo = useCallback((id: number) => {
         
         setTodos(prev => prev.filter(todo => todo.id !== id));
        
  }, []);
     const editTodo = useCallback((id: number) => {
    const todo = todos.find(t => t.id === id);
    
    
    if (todo) setEditingTodo(todo);
 
  }, [todos]);
   const { completedCount, pendingCount } = useMemo(() => {
    const completed = todos.filter(todo => todo.isCompleted).length;
    const pending = todos.length - completed;
    return { completedCount: completed, pendingCount: pending };
  }, [todos]);

    return(
       <div className="container mt-5">
        <div className="row">
           <div className="col-6">
               <p>{count}</p>
               <button onClick={()=> setcount(a => a+1)}>Add Count</button>
               <Form addOrUpdateTodo={addOrUpdateTodo} editingTodo={editingTodo}></Form>
               
           </div>
          <div className="col-6"> 
              <div>Completed Count : {completedCount} |  Pending Count : {pendingCount} |  Editing Count : {editCountRef.current}</div>
               
               <AddToDo todos={todos} deleteTodo={deleteTodo} editTodo={editTodo} />

          </div>
            
        </div>
        
     

          
      </div>
    )
    
}
export default ToDo;


import { useRef, useState } from "react";

function UserInput(){
    const nameRef=useRef<HTMLInputElement | null>(null);
    const Count=useRef<number>(0);
    const [name,setName]=useState("");
    const inputFocus = () =>{
        nameRef.current?.focus();
        nameRef.current?.value;
         
       
        
    }
    
     Count.current++;
    console.log("with re-render");
    return(
        <div>
          <label>Input :  </label>
           <input  ref={nameRef}></input>
            <button onClick={inputFocus}>Input Focus</button>
            <br></br>
            <label>Name : </label>
            <input type="text" onChange={(e) => setName(e.target.value)}></input>
            <button onClick={()=> setName(name)}>Add Name</button>
           <p>Count : {Count.current}</p>
        </div>
      
    )
}
export default UserInput;
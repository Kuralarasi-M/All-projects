import {useState,useEffect} from 'react';



const   useCustomTheme = ()=>{
  
    let color="white";
    const getStoredTheme = () => {
        try{
            return localStorage.getItem("theme") || color
        }
        catch{
            return color
        }
    }
    const [theme,setTheme]= useState(getStoredTheme);
     const themeColor={
    background: (theme=="white")?"black":"white",
    color:(theme=="white")?"white":"black"
   } 
    useEffect(() => {
    localStorage.setItem("theme", theme);
  }, [theme]);
    const switchTheme = () => {
       return setTheme(() => theme=="white"?"black":"white");
    }
    return (
         {color,themeColor,switchTheme}
    )
}
export default useCustomTheme;

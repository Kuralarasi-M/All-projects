import React from "react";
import { useState } from "react";

const callbackFunction = () => {
     const [count,setCount] = useState(0);
    console.log("Rendering");
    return(
      <>
        <div>{count}</div>
        <button onClick={() => {setCount(a => a+1)}}>AddCount</button>
         <Child></Child>
        </>
    )
}

export default callbackFunction;
2

const Child=React.memo(() => {
   
    console.log("Child Rendering")
    const list : number[] = [1,2,3,4,5,6,7,8,9,10]
    return (
        
        <div>
              
                {list.map((i)=> (
                    <div className="m-2 p-2 border w-25 text-center bgcolor">{i}</div>
                ))}
             
             
           </div>
    )
});
import React from "react";
import { useCallback, useMemo, useState } from "react";

function ArrayItems(){
    const [userInput,setUserInput]=useState(990);
    const inputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
            setUserInput(Number(e.target.value));
    };
    
    const List:number[] = Array.from({ length: 1000 }, (_, i) => i + 1);

    const filteredArray =useMemo(() => {
      return  List.filter((num) => num>userInput)
    },[userInput]);

    const addSome = useCallback(() => {
        console.log("function call")
    },[])

    // const addSome = () => {
    //     console.log("no usecall")
    // }

    return(
        <div>
           <input type="number" onChange={inputChange}></input>
          {/* <Sample addSome={addSome}/> */}
           {filteredArray.map((num) => (
               <p key={num}>{num}</p>
           ))}
        </div>
        
    )
}
export default ArrayItems;


// const Sample = React.memo(({addSome}:{addSome : () => void}) => {

//     console.log("yes")

//     return <button onClick={addSome}>sdf</button>
// })




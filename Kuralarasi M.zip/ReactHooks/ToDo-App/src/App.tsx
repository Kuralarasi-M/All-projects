import './App.css';
import ArrayItems from './Todo/ArrayItems';
import ToDo from './Todo/ToDo';
import { useState } from 'react';
import UserInput from './Todo/UserInput';
import Theme from './Todo/Theme';
import CallBack from './Todo/Callback';
type TabType = "home" | "theme" |"callBack"| "hooks";

function App() {
  const [activeTab, setActiveTab] = useState<TabType>("home");
   return (
    <>
      
      <nav className="menubar">
        <ul>
          <li><button onClick={() => setActiveTab("home")}>Home</button></li>
          <li><button onClick={() => setActiveTab("theme")}>Theme</button></li>
          <li><button onClick={() => setActiveTab("hooks")}>Hooks Demo</button></li>
          <li><button onClick={() => setActiveTab("callBack")}>CallBack</button></li>
        </ul>
        
      </nav>

   
      <div className="p-6">
        {activeTab === "home" && (
          <>
           <ToDo />
          </>
        )}

        {activeTab === "theme" && (
          <>
          <Theme></Theme>
          </>
        )}

        {activeTab === "hooks" && (
          <>
            <h2 className="text-xl font-bold"></h2>
              <UserInput />
             <ArrayItems />
           </>
        )}
         {activeTab === "callBack" && (
          <>
            <CallBack></CallBack>
          </>
        )}
      </div>
    </>
  );
}

export default App;

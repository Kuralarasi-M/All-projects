import {useState,useRef,useEffect} from 'react'
import './App.css'

type Signin = {
  id: number;
  email: string;
  password: string;
  isDeleted:boolean;
};
function App() {
     const [num,setNum] = useState(100);
     const [name,setName] = useState("");
     const [refName,setRefName]= useState("");
     const inputRef=useRef<HTMLInputElement | null>(null);
     const [email,setEmail] = useState("");
    const [password,setPassword] = useState("");
   
     const [signin,setSignin]= useState<Signin[]>([]);
     const FormSubmit= (a:React.FormEvent) => {
          a.preventDefault();
          
        if (!email || !password) return;
          const newSigin: Signin={id: Date.now(),email,password,isDeleted:false}
          setSignin([...signin,newSigin])

          setEmail("");
          setPassword("");
     }

      const display = () => {
        const  inputname=inputRef.current?.value || "";
        console.log(inputname);
        setRefName(inputname);
      }
      useEffect (()=>{
       console.log("React useEffect");
    
       return() =>{
          
          console.log("Memory Cleaned"+num);
       }
       
     },[num])
    function AddFun(){
        setNum((a) =>  a+1);      
    }
    const handleDelete = (index: number) => {
    setSignin(
      signin.map((item, i) =>
        i === index ? { ...item, isDeleted: true } : item
      )
    );
  };
    const handleRestore = (index: number) => {
    setSignin(
      signin.map((item, i) =>
        i === index ? { ...item, isDeleted: false } : item
      )
    );
  };

   return(
    <>
    <form className='form1' onSubmit={FormSubmit}>
      <label>Email</label>
      <fieldset>
        
         <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}></input>
       <label>Password</label>
       <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}></input>
       <button type="submit">Submit</button>
      </fieldset>
       
           </form>
     <input type="text" onChange={(event) => setName(event.target.value)}></input>
     <input ref={inputRef}></input>
     <button onClick={display}>ShowName</button>
     <p>{refName}</p>
     <p>My name is {name}</p>
       <p>{num}</p>
       <button onClick={AddFun}>Add</button>
    <h2>Active Users</h2>
      <table border={1}>
        <thead>
          <tr>
            <th>Id</th>
            <th>Email</th>
            <th>Password</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {signin
            .filter((u) => !u.isDeleted)
            .map((u, index) => (
              <tr key={u.id}>
                <td>{u.id}</td>
                <td>{u.email}</td>
                <td>{u.password}</td>
                <td>
                  <button onClick={() => handleDelete(index)}>Delete</button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>

      <h2>Deleted Users</h2>
      <table border={1}>
        <thead>
          <tr>
            <th>Id</th>
            <th>Email</th>
            <th>Password</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {signin
            .filter((u) => u.isDeleted)
            .map((u, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{u.email}</td>
                <td>{u.password}</td>
                <td>
                  <button onClick={() => handleRestore(index)}>Restore</button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </>
   )
  
}

export default App

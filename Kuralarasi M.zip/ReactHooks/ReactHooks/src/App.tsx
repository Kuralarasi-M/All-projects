
import './App.css'
import { useCallback,useState,useEffect } from 'react';

function App() {
  const [num,setNum] = useState(0);
  
  const [theme,setTheme] =useState(false);
 const getItems =() => {
  return [num+1,num+2,num+3]
 }
  const themeSwitch =() => {
    console.log("theme switch");
    return setTheme(b => !b)
  }
  const  bgtheme ={
    background:theme ? "blue" : "yellow",
     color:theme?"white":"black"
  }
  return (
    
    <>
     <div style={bgtheme}>
         <input onChange={(e) => setNum(parseInt(e.target.value))} type="number"></input>
        <p>{num}</p>
        <button onClick={themeSwitch}>Theme</button>
        
     </div>
        
    </>
  )
}

export default App

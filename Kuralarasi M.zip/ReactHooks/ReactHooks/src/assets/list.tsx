import {  useEffect, useState} from 'react';
import getItems from 'App.tsx'
const List=({getItems}) => { 
     const [items,setItems] = useState([])
     useEffect(()=> {
        setItems(getItems())
     },[getItems])
    return (
       <div>{items.map((item,index) => (
          <p key={index}>{item}</p>
       ))} </div>
    )
}
export default List;
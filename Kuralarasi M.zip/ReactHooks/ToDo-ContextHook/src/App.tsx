
import { Route, Routes } from 'react-router-dom'
import './App.css'
import Todo from './todoComponents/Todo'
import TodoForm from './todoComponents/TodoForm'
import Home from './todoComponents/Home'
import NavBar from './todoComponents/NavBar'
import About from './todoComponents/About'
import { TodoProvider } from './todoComponents/TodoContext'

function App() {


  return (
    <>
    <NavBar></NavBar>
      <Routes>
      <Route path="/home" element={<Home />} />

   
      <Route path="/todo" element={
        <TodoProvider>
            <Todo />
          </TodoProvider>
        }
      />
      <Route
        path="/todoform"
        element={
          <TodoProvider>
            <TodoForm />
          </TodoProvider>
        }
      />
      <Route path="/about" element={<About />} />
    </Routes>
      
    </>
  )
}

export default App

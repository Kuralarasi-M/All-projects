import React, { createContext, useContext, useState } from "react";

import schema from "./schema";         // default export for schema
import type { todoType } from "./schema";
interface TodoContextType {
  todos: todoType[];
  addTodo: (todo: todoType) => void;
  updateTodo: (todo: todoType) => void;
  deleteTodo: (id: number) => void;
  setEditId: (id:number | null) => void;
  editId:number | null;
  }

const TodoContext = createContext<TodoContextType | undefined>(undefined);

export const TodoProvider = ({ children }: { children: React.ReactNode }) => {
  const [todos, setTodos] = useState<todoType[]>([]);
  const [nextId, setNextId] = useState(1);
  const [editId,setEditId] = useState<number | null>(null);
  const addTodo = (todo: todoType) => {
    const todoWithId = { ...todo, id: nextId };
    setTodos(prev => [...prev, todoWithId]);
    setNextId(prev => prev + 1);
  };

  const updateTodo = (todo: todoType) => {
    if (!todo.id) return;
    setEditId(todo.id)
    setTodos(prev => prev.map(t => (t.id === todo.id ? todo : t)));
  };

  const deleteTodo = (id: number) => {
    setTodos(prev => prev.filter(t => t.id !== id));
  };

  return (
    <TodoContext.Provider value={{ todos,setEditId, addTodo, updateTodo, deleteTodo,editId }}>
      {children}
    </TodoContext.Provider>
  );
};

export const useTodos = () => {
  const context = useContext(TodoContext);
  if (!context) throw new Error("useTodos must be used within TodoProvider");
  return context;
};

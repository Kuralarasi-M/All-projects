import React from "react";
import { useTodos } from "./TodoContext";



export default function TodoList() {
  const { todos, deleteTodo,updateTodo} = useTodos();


  return (
    <div>
      {todos.length === 0 ? (
        <p className="text-center">No todos available</p>
      ) : (
        todos.map(todo => (
          <div
            key={todo.id}
            className="border w-80 m-auto p-3 mb-2"
            style={{ backgroundColor: "#f7f7f7", borderRadius: "5px" }}
          >
            <p><strong>Id:</strong> {todo.id}</p>
            <p><strong>Name:</strong> {todo.name}</p>
            <p><strong>Description:</strong> {todo.description}</p>
            <p><strong>Priority:</strong> {todo.priority}</p>
            <p><strong>Completed:</strong> {todo.isCompleted ? "Yes" : "No"}</p>
            <div className="d-flex gap-2">
              <button
                className="btn btn-primary btn-sm"
                onClick={() => updateTodo(todo)}
              >
                Edit
              </button>
              <button
                className="btn btn-danger btn-sm"
                onClick={() => deleteTodo(todo.id!)}
              >
                Delete
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

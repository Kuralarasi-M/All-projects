import { z } from "zod";

export const schema = z.object({
  id: z.number().optional(),
  name: z.string().nonempty("Name is required!").min(3, "Name must be at least 3 chars"),
  description: z.string().nonempty("Description is required!"),
  priority: z.string().nonempty("Priority must be selected"),
  isCompleted: z.boolean().optional(),
});

export type todoType = z.infer<typeof schema>;
export default schema;



import React, { useState } from "react";
import { TodoProvider } from "./TodoContext";

import TodoForm from "./TodoForm";
import TodoList from "./TodoList";

export default function Todo() {
 

  // const handleEdit = (id: number) => {
  //   setEditId(id);
  // };

  return (
    <TodoProvider>
      <div className="container mt-4">
        <h1 className="mb-4">Todo App</h1>
        <TodoForm  />
        <TodoList  />
      </div>
    </TodoProvider>
  );
}

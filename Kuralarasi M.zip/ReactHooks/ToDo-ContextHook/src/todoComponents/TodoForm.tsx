import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

import schema from "./schema";        
import type { todoType } from "./schema";
import { useTodos } from "./TodoContext";
import { Button, Form } from "react-bootstrap";



export default function TodoForm() {
  const { addTodo, updateTodo, todos,setEditId ,editId} = useTodos();

  const { register, handleSubmit, reset, formState: { errors }, setValue } = useForm<todoType>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", description: "", priority: "", isCompleted: false },
  });

  const onSubmit = (data: todoType) => {
    console.log(editId);
    
    if (editId !== null) {
      updateTodo({ ...data, id: editId });
      setEditId(null);
      
    } else {
      addTodo(data);
    }
    reset();
    
  };
  
  useEffect(() => {
    if (editId !== null) {
      const todo = todos.find(t => t.id === editId);
      if (todo) {
        setValue("name", todo.name);
        setValue("description", todo.description);
        setValue("priority", todo.priority);
        setValue("isCompleted", todo.isCompleted || false);
      }
    }
  }, [editId, setValue, todos]);

  return (
    <div>
       <h2 className="m-5 text-center text-primary">ToDo Application</h2>
        <Form onSubmit={handleSubmit(onSubmit)} className="m-auto w-75 border rounded p-5">
      <Form.Group className="mb-2">
        <Form.Label>Name</Form.Label>
        <Form.Control type="text" {...register("name")} isInvalid={!!errors.name} />
        <Form.Control.Feedback type="invalid">{errors.name?.message}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-2">
        <Form.Label>Description</Form.Label>
        <Form.Control as="textarea" {...register("description")} isInvalid={!!errors.description} />
        <Form.Control.Feedback type="invalid">{errors.description?.message}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-2">
        <Form.Label>Priority</Form.Label>
        <Form.Select {...register("priority")} isInvalid={!!errors.priority}>
          <option value="">Select Priority</option>
          <option value="Low">Low</option>
          <option value="Medium">Medium</option>
          <option value="High">High</option>
        </Form.Select>
        <Form.Control.Feedback type="invalid">{errors.priority?.message}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Check type="checkbox" label="Completed" {...register("isCompleted")} />
      </Form.Group>

      <Button type="submit">{editId !== null ? "Update Todo" : "Add Todo"}</Button>
    </Form>
    </div>
    
  );
}

﻿namespace CodeFirstA.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateFeatures : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.Employees", name: "Salary", newName: "DeptId");
            AlterColumn("dbo.Employees", "Email", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Employees", "Email", c => c.String());
            RenameColumn(table: "dbo.Employees", name: "DeptId", newName: "Salary");
        }
    }
}

﻿using System.Linq;
using System;
using System.Configuration;
using System.Data.Entity;
namespace CodeFirst
{
  

    public class Post
    {
        public static string constr = ConfigurationManager.ConnectionStrings["TableDBContext"].ConnectionString;
        public int Id { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public int Salary { get; set; }
        public string Email {  get; set; }   
    }

    public class TableDBContext : DbContext{
        public TableDBContext() : base("TableDBContext") {
            Database.SetInitializer(new DropCreateDatabaseIfModelChanges<TableDBContext>());
        }

        public DbSet<Post> Posts { get; set; }

    }
    internal class CodeFirst
    {
      
        static void Main(string[] args)
        {
        Console.WriteLine("Hello, World!");
            //using (var db = new TableDBContext())
            //{
            //    var post = new Post { Name = "Emma", Department = "HR", Salary = 60000 };
            //    db.Posts.Add(post);
            //    db.SaveChanges();

            //    Console.WriteLine("Post table created and record inserted!");
            //}
            using (var db = new TableDBContext())
            {
                var post = db.Posts.Where(p => p.Department == "IT");

                foreach (var item in post.ToList())
                {
                    Console.WriteLine($"Name: { item.Name} - Id: {item.Id}");

                }
                Console.WriteLine(post.GetType());
               

                

                

            }
            
        }
    }
}

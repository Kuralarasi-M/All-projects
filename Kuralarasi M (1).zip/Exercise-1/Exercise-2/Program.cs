﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Configuration;
public class Student
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string Mobile {  get; set; }
    public string DepartmentName { get; set; }
}
class Program
{
   private static readonly InputValidation object1 = new InputValidation();
   private static readonly string connectionString = ConfigurationManager.ConnectionStrings["StudentDB"].ConnectionString;

    static void Main()
    {

        try
        {
           
            Console.WriteLine("Menu:\n1  --- Insert Data\n2 --- Update Data  \n3 --- Show All Data\n4 --- Delete Data\n5 --- DepartmentStudents");
           
            InputValidation object1 = new InputValidation();
            int a = object1.option();

            switch (a)
            {
                case 1:
                    Insert();
                    break;
                case 2:
                    Update();
                    break;
                case 3:
                    ShowAll();
                    break;
                case 4:
                    Delete();
                    break;
                case 5:
                    DepartmentStudent();
                    break;
            }
            
        }
        catch (Exception ex)
        {
            //Console.WriteLine("Error occur at Main");
            Console.WriteLine(ex);
            Console.WriteLine(ex.ToString());
            Console.ReadKey();
        }
    }
    static void Insert()
    {
        try
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //InputValidation object1 = new InputValidation();
                int userid = object1.Idvalidation(connectionString);
                string name = object1.NameValidation();

                string email = object1.EmailValidation(connectionString);

                string phoneno = object1.MobileValidation();
                string query = "insert into Student(Id,Name,Email,Mobile) values (@id,@name,@email,@phoneno)";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", userid);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@phoneno", phoneno);
                    con.Open();

                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Inserted Data Successfully");
                }


            }

        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        ShowAll();

    }
    static int UserExist()
    {

        Console.Write("Enter your Id : ");
        string id = Console.ReadLine();
        Boolean isExist = false;
        int userId = 0;
        using (SqlConnection con = new SqlConnection(connectionString))
        {


            con.Open();
            string query = "select Id from student";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            try
            {
                while (reader.Read())
                {
                    if (id == (Convert.ToString(reader["Id"])))
                    {
                        userId = Convert.ToInt32(reader["Id"]);
                        isExist = true;
                        break;
                    }

                }
                if (!isExist)
                {
                    Console.WriteLine("UserId is not Exist");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        return userId;
    }
    static void Update()
    {
        
        int userId = UserExist();
        if (userId > 0)
        {
            Console.WriteLine("Menu :\n1 --- Update Name\n2 --- Update Email \n3 --- Update Mobile \n4 --- Exit");
            int option = object1.option();
            switch (option)
            {
                case 1:
                    string name = object1.NameValidation();
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        con.Open();
                        string query = $"update student set Name=@name where Id=@id";
                        SqlCommand com = new SqlCommand(query, con);
                        com.Parameters.AddWithValue("@id", userId);
                        com.Parameters.AddWithValue("@name", name);
                        int row = com.ExecuteNonQuery();
                        if (row > 0)
                        {
                            Console.WriteLine("Updated Successfully");
                            ShowAll();
                        }
                        else
                        {
                            Console.WriteLine("No record found");
                        }
                    }

                    break;
                case 2:

                    string email = object1.EmailValidation(connectionString);
                    using (SqlConnection con1 = new SqlConnection(connectionString))
                    {
                        con1.Open();
                        string query = "update student set Email=@email where Id=@userId";
                        SqlCommand command = new SqlCommand(query, con1);
                        command.Parameters.AddWithValue("@email", email);
                        command.Parameters.AddWithValue("@userId", userId);
                        int row = command.ExecuteNonQuery();
                        if (row > 0)
                        {
                            Console.WriteLine("Updated Successfully.");
                            ShowAll();
                        }


                    }

                    break;
                case 3:
                    string mobile = object1.MobileValidation();
                    using (SqlConnection con2 = new SqlConnection(connectionString))
                    {
                        con2.Open();
                        string query = "update student set Mobile=@mobile where Id=@userId";
                        SqlCommand com = new SqlCommand(query, con2);
                        com.Parameters.AddWithValue("@mobile", mobile);
                        com.Parameters.AddWithValue("@userId", userId);
                        int row = com.ExecuteNonQuery();
                        if (row > 0)
                        {
                            Console.WriteLine("Updated Successfully.");
                            ShowAll();
                        }
                    }
                    break;
                case 4:
                    break;
                default:
                    Console.WriteLine("Invalid Option.");
                    break;
            }

        }


    }
    static void Delete()
    {
        //InputValidation object1 = new InputValidation();
        int userId = UserExist();
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            con.Open();
            string query = "delete from student where Id=@userId";
            SqlCommand com = new SqlCommand(query, con);
            com.Parameters.AddWithValue("@userId", userId);
            int row = com.ExecuteNonQuery();
            if (row > 0)
            {
                Console.WriteLine("Data Deleted Successfully");
                ShowAll();
            }
        }

    }
    static void DepartmentStudent()
    {
        //InputValidation object1 = new InputValidation();
        //Console.WriteLine("Enter DepartmentId : ");

        int Id = object1.option();
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("StudentDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@DepartmentId", Id);
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Console.WriteLine("|{0,-20}|{1,-20}|{2,-40}|{3,-20}|{4,-20}|", reader["Id"], reader["Name"], reader["Email"], reader["Mobile"], reader["DepartmentName"]);
                }
            }


        }
      
    }
    static List<Student> StudentClass(string connectionString)
    {
        List<Student> students = new List<Student>();
        using (SqlConnection con=new SqlConnection(connectionString))
        {
            con.Open();
            string query = "select s.Id,s.Name,s.Email,s.Mobile,d.DepartmentName from student s inner join department d on d.DepartmentId=s.DepartmentId";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
          
            while (reader.Read())
            {
                students.Add(new Student
                {
                    Id = (int)reader["Id"],
                    Name = reader["Name"].ToString(),
                    Email = reader["Email"].ToString(),
                    Mobile = reader["Mobile"].ToString(),
                    DepartmentName = reader["DepartmentName"].ToString()

                });

            }
        }
        return students;
    }
    static void ShowAll()
    {
        // Normal Way to get the data from DB
       /* using (SqlConnection con = new SqlConnection(connectionString))
        {
            string selectquery = "select s.Id,s.Name,s.Email,s.Mobile,d.DepartmentName from student s inner join department d on d.DepartmentId=s.DepartmentId";
            using (SqlCommand selque = new SqlCommand(selectquery, con))
            {
                con.Open();
                Console.WriteLine(new string('-', 126));
                Console.WriteLine("|{0,-20}|{1,-20}|{2,-40}|{3,-20}|{4,-20}|", "UserId", "Name", "Email", "Mobile", "DepartmentName");
                Console.WriteLine(new string('-', 126));
                SqlDataReader reader = selque.ExecuteReader();
                while (reader.Read())
                {
                    Console.WriteLine("|{0,-20}|{1,-20}|{2,-40}|{3,-20}|{4,-20}|", reader["Id"], reader["Name"], reader["Email"], reader["Mobile"], reader["DepartmentName"]);
                }
                Console.WriteLine(new string('-', 126));
            }
        }*/
        // Access SP and display the Details.
        using (SqlConnection con = new SqlConnection(connectionString))
        {

            SqlCommand cmd = new SqlCommand("Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            Console.WriteLine("\nStudent Table:");
            Console.WriteLine(new string('-', 105));
            Console.WriteLine("|{0,-20}|{1,-20}|{2,-40}|{3,-20}|", "UserId", "Name", "Email", "Mobile");
            Console.WriteLine(new string('-', 105));
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                
               
                while (reader.Read())
                {
                    Console.WriteLine("|{0,-20}|{1,-20}|{2,-40}|{3,-20}|", reader["Id"], reader["Name"], reader["Email"], reader["Mobile"]);
                }
                Console.WriteLine(new string('-', 105));
                if (reader.NextResult())
                {
                    Console.WriteLine("\nDepartment Table:");
                    Console.WriteLine(new string('-', 43));
                    while (reader.Read())
                    {
                        Console.WriteLine("|{0,-20}|{1,-20}|", reader["DepartmentId"], reader["DepartmentName"]);
                    }
                    Console.WriteLine(new string('-', 43));
                }
            }

        }
        // Store the Data in List of Objects and Display It.
        List<Student> students=StudentClass(connectionString);
        Console.WriteLine("Student Details from Student class!.");
        Console.WriteLine(new string('-', 126));
        Console.WriteLine("|{0,-20}|{1,-20}|{2,-40}|{3,-20}|{4,-20}|", "StudentId", "Name", "Email", "Mobile","Department");
        Console.WriteLine(new string('-', 126));
        foreach (var student in students)
        {
            Console.WriteLine("|{0,-20}|{1,-20}|{2,-40}|{3,-20}|{4,-20}|", student.Id,student.Name, student.Email, student.Mobile, student.DepartmentName);
        }
        Console.WriteLine(new string('-', 126));
    }



}
public class InputValidation
{
    public int option()
    {
        int a = 0;
        try
        {
            Console.Write("Enter your Option : ");
            Boolean isValid = false;

            while (!isValid)
            {

                string str = Console.ReadLine();
                if (int.TryParse(str, out a) && a > 0 && a < 7)
                {
                    isValid = true;

                }
                else
                {
                    Console.Write("Enter the correct option between (1 - 4) : ");
                }
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        return a;
    }
    public string NameValidation()
    {
        string name = "";
        Boolean isValid = false;
        string pattern = @"^[A-Za-z\s]+$";
        Console.Write("Enter the Name : ");
        while (!isValid)
        {
            String str = Console.ReadLine();
            if (Regex.IsMatch(str, pattern))
            {
                isValid = true;
                name = str;
            }
            else
            {
                Console.Write("Enter your correct name : ");
            }
        }
        return name;
    }
    public int Idvalidation(string connectionString)
    {
        Console.Write("Enter the UserId : ");
        int num = 0;
        Boolean isValid = false;
        while (!isValid)
        {
            string str = Console.ReadLine();
            if (int.TryParse(str, out num))
            {
                isValid = true;
            }
            else
            {
                Console.Write("Enter the Id in numbers : ");
            }

        }
        return num;
    }

    public string EmailValidation(string connectionString)
    {
        string email = "";
        bool isValid = false;
        string pattern = @"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?:\.[A-Za-z]{2,})*$";

        while (!isValid)
        {
            Console.Write("Enter your EmailId: ");
            string str = Console.ReadLine().Trim();


            if (!Regex.IsMatch(str, pattern))
            {
                Console.WriteLine("Invalid format. Example: abc123@gmail.com");
                continue;
            }


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT COUNT(*) FROM student WHERE LOWER(Email) = @Email";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Email", str.ToLower());
                    int count = Convert.ToInt32(cmd.ExecuteScalar());

                    if (count > 0)
                    {
                        Console.WriteLine("Email already exists. Try another one.");
                        continue;
                    }
                }
            }


            isValid = true;
            email = str;
        }

        return email;
    }


    public string MobileValidation()
    {
        string mobile = "";
        Boolean isValid = false;
        string pattern = @"^[0-9-]+$";
        Console.Write("Enter your MobileNo : ");
        while (!isValid)
        {
            String str = Console.ReadLine();
            if (Regex.IsMatch(str, pattern))
            {
                isValid = true;
                mobile = str;
            }
            else
            {
                Console.Write("Enter your correct mobileno : ");
            }
        }
        return mobile;
    }
}

